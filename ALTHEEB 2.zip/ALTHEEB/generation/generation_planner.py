from __future__ import annotations

from typing import Any, Dict


class GenerationPlanner:
    def __init__(self):
        pass

    def build(
        self,
        report: Dict[str, Any],
        knowledge_context: Dict[str, Any],
        scene_graph: Dict[str, Any],
        brain_state: Dict[str, Any]
    ) -> Dict[str, Any]:
        camera_hint = dict(brain_state.get("camera_hint", {}))
        target_cell = str(scene_graph.get("zones", {}).get("target_primary_cell", ""))
        dominant_relation = str(knowledge_context.get("dominant_relation", "unknown"))
        dominant_pattern = str(knowledge_context.get("dominant_pattern", "unknown"))
        phase = str(brain_state.get("scene_phase", "monitor"))

        mode = "storyboard_frame"
        if phase in {"pressure", "alert"}:
            mode = "cinematic_reconstruction"

        prompt = (
            f"surveillance-derived cinematic scene, "
            f"phase={phase}, "
            f"dominant_relation={dominant_relation}, "
            f"dominant_pattern={dominant_pattern}, "
            f"target_cell={target_cell}, "
            f"shot_type={camera_hint.get('shot_type', 'wide')}, "
            f"camera_angle={camera_hint.get('camera_angle', 'eye_level')}, "
            f"focus_mode={camera_hint.get('focus_mode', 'scene_overview')}, "
            f"lighting={camera_hint.get('lighting_hint', 'neutral lighting')}"
        )

        negative_prompt = (
            "low detail, random composition, floating limbs, broken perspective, "
            "extra people, unreadable subject hierarchy, chaotic background"
        )

        return {
            "generation_version": "v1",
            "mode": mode,
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "shot_plan": {
                "shot_type": camera_hint.get("shot_type", "wide"),
                "camera_angle": camera_hint.get("camera_angle", "eye_level"),
                "focus_mode": camera_hint.get("focus_mode", "scene_overview"),
                "lighting_hint": camera_hint.get("lighting_hint", "neutral lighting")
            },
            "control_hints": {
                "target_primary_cell": target_cell,
                "neighbor_cells": list(scene_graph.get("zones", {}).get("neighbor_cells", [])),
                "nodes_count": len(scene_graph.get("nodes", [])),
                "edges_count": len(scene_graph.get("edges", []))
            },
            "source_summary": {
                "video_id": str(report.get("video_id", "")),
                "qqss_events_count": int(report.get("qqss_events_count", 0)),
                "qqss_bridge_events_count": int(report.get("qqss_bridge_events_count", 0))
            }
        }