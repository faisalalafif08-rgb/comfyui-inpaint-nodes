from pathlib import Path
from typing import List
from core.utils import write_json

def generate_manifest(
    video_id: str,
    video_info: dict,
    scenes: List,
    clips: List,
    images: List,
    indices_dir: Path,
) -> Path:
    manifest = {
        "video_id": video_id,
        "video_info": video_info,
        "scenes_count": len(scenes),
        "clips_count": len(clips),
        "images_count": len(images),
        "scenes": [s.__dict__ for s in scenes],
        "clips": [c.__dict__ for c in clips],
        "images": [i.__dict__ for i in images],
    }
    out_path = indices_dir / f"{video_id}_render_manifest.json"
    write_json(out_path, manifest)
    return out_path
