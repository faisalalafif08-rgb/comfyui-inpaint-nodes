import shutil
from pathlib import Path
from typing import List
from core.models import Keyframe, FaceObservation, ImageRecord
from core.utils import make_stable_id

def export_images(
    keyframes: List[Keyframe],
    faces: List[FaceObservation],
    workspace_dir: str,
    video_id: str,
) -> List[ImageRecord]:
    images: List[ImageRecord] = []
    img_dir = Path(workspace_dir) / video_id / "images"
    img_dir.mkdir(parents=True, exist_ok=True)

    # copy keyframes
    for kf in keyframes:
        src = Path(kf.image_path)
        if not src.exists():
            continue
        dst = img_dir / f"keyframe_{kf.keyframe_id}.jpg"
        shutil.copy2(src, dst)
        images.append(ImageRecord(
            image_id=make_stable_id("img", video_id, kf.keyframe_id),
            source_type="keyframe",
            source_id=kf.keyframe_id,
            output_path=str(dst),
        ))

    # copy first N faces as baseline (replace with per-person selection later)
    for face in faces[:5]:
        src = Path(face.crop_path)
        if not src.exists():
            continue
        dst = img_dir / f"face_{face.face_obs_id}.jpg"
        shutil.copy2(src, dst)
        images.append(ImageRecord(
            image_id=make_stable_id("img", video_id, face.face_obs_id),
            source_type="face",
            source_id=face.face_obs_id,
            output_path=str(dst),
        ))

    return images
