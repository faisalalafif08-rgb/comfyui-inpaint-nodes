import subprocess
from pathlib import Path
from typing import List
from core.models import SceneRecord, ClipRecord
from core.utils import make_stable_id

def build_clips(
    scenes: List[SceneRecord],
    video_path: str,
    workspace_dir: str,
    video_id: str,
    ffmpeg_path: str = "ffmpeg",
) -> List[ClipRecord]:
    clips: List[ClipRecord] = []
    clip_dir = Path(workspace_dir) / video_id / "clips"
    clip_dir.mkdir(parents=True, exist_ok=True)

    for scene in scenes:
        out_path = clip_dir / f"clip_{scene.scene_id}.mp4"
        cmd = [
            ffmpeg_path,
            "-i", video_path,
            "-ss", str(scene.start_sec),
            "-to", str(scene.end_sec),
            "-c", "copy",
            "-y", str(out_path)
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            clips.append(ClipRecord(
                clip_id=make_stable_id("clip", video_id, scene.scene_id),
                video_id=video_id,
                scene_id=scene.scene_id,
                start_sec=float(scene.start_sec),
                end_sec=float(scene.end_sec),
                output_path=str(out_path),
            ))
        except subprocess.CalledProcessError as e:
            # Keep going; clip export is optional
            pass

    return clips
