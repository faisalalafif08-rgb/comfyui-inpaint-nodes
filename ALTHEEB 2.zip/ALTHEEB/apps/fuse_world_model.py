from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from brain.brain_v2 import BrainV2
from generation.generation_planner import GenerationPlanner
from knowledge.knowledge_engine import KnowledgeEngine
from scene.scene_graph_builder import SceneGraphBuilder


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")

    report = load_json(report_path)
    outputs = dict(report.get("outputs", {}))

    qqss_target_json = Path(outputs["qqss_target_json"])
    qqss_events_json = Path(outputs["qqss_events_json"])
    qqss_summary_json = Path(outputs["qqss_summary_json"])

    if not qqss_target_json.exists():
        raise FileNotFoundError(f"QQSS_TARGET_NOT_FOUND: {qqss_target_json}")
    if not qqss_events_json.exists():
        raise FileNotFoundError(f"QQSS_EVENTS_NOT_FOUND: {qqss_events_json}")
    if not qqss_summary_json.exists():
        raise FileNotFoundError(f"QQSS_SUMMARY_NOT_FOUND: {qqss_summary_json}")

    qqss_scenes_json = Path(outputs.get("qqss_scenes_json", ""))
    qqss_scenes = []
    if str(qqss_scenes_json) and qqss_scenes_json.exists():
        qqss_scenes = load_json(qqss_scenes_json)

    qqss_target = load_json(qqss_target_json)
    qqss_events = load_json(qqss_events_json)
    qqss_summary = load_json(qqss_summary_json)

    video_id = str(report["video_id"])
    indices_dir = report_path.parent

    knowledge_context_json = indices_dir / f"{video_id}_knowledge_context.json"
    scene_graph_json = indices_dir / f"{video_id}_scene_graph.json"
    brain_state_json = indices_dir / f"{video_id}_brain_state.json"
    generation_plan_json = indices_dir / f"{video_id}_generation_plan.json"

    knowledge_engine = KnowledgeEngine()
    scene_graph_builder = SceneGraphBuilder()
    brain = BrainV2()
    planner = GenerationPlanner()

    knowledge_context = knowledge_engine.analyze(
        report=report,
        qqss_target=qqss_target,
        qqss_events=qqss_events,
        qqss_summary=qqss_summary,
        qqss_scenes=qqss_scenes
    )

    scene_graph = scene_graph_builder.build(
        report=report,
        qqss_target=qqss_target,
        qqss_events=qqss_events
    )

    brain_state = brain.reason(
        report=report,
        knowledge_context=knowledge_context,
        scene_graph=scene_graph
    )

    generation_plan = planner.build(
        report=report,
        knowledge_context=knowledge_context,
        scene_graph=scene_graph,
        brain_state=brain_state
    )

    write_json(knowledge_context_json, knowledge_context)
    write_json(scene_graph_json, scene_graph)
    write_json(brain_state_json, brain_state)
    write_json(generation_plan_json, generation_plan)

    report["knowledge_ready"] = True
    report["brain_v2_ready"] = True
    report["scene_graph_ready"] = True
    report["generation_plan_ready"] = True
    report["outputs"]["knowledge_context_json"] = str(knowledge_context_json)
    report["outputs"]["scene_graph_json"] = str(scene_graph_json)
    report["outputs"]["brain_state_json"] = str(brain_state_json)
    report["outputs"]["generation_plan_json"] = str(generation_plan_json)
    write_json(report_path, report)

    print("=== WORLD MODEL FUSED ===")
    print(f"video_id: {video_id}")
    print(f"knowledge_context_json: {knowledge_context_json}")
    print(f"scene_graph_json: {scene_graph_json}")
    print(f"brain_state_json: {brain_state_json}")
    print(f"generation_plan_json: {generation_plan_json}")
    print(f"report_json_updated: {report_path}")


if __name__ == "__main__":
    main()