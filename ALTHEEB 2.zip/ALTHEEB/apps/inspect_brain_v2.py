from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")

    report = load_json(report_path)
    outputs = report.get("outputs", {})

    brain_state_path = Path(outputs["brain_state_v2_json"])
    knowledge_path = Path(outputs["knowledge_summary_json"])
    generation_path = Path(outputs["generation_plan_json"])
    plausibility_path = Path(outputs["world_plausibility_json"])

    brain_state = load_json(brain_state_path)
    knowledge = load_json(knowledge_path)
    generation = load_json(generation_path)
    plausibility = load_json(plausibility_path)

    print("=== BRAIN V2 INSPECT ===")
    print(f"video_id: {report.get('video_id')}")
    print(f"phase: {brain_state.get('scene_phase')}")
    print(f"action: {brain_state.get('action')}")
    print(f"attention: {brain_state.get('attention_level')}")
    print(f"severity: {brain_state.get('severity')}")
    print(f"plausibility: {plausibility.get('score')} ({plausibility.get('status')})")
    print(f"dominant_relation: {knowledge.get('dominant_relation')}")
    print(f"dominant_pattern: {knowledge.get('dominant_pattern')}")
    print(f"shot_hint: {brain_state.get('shot_hint')}")
    print(f"camera_hint: {brain_state.get('camera_hint')}")
    print("")
    print("prompt_text:")
    print(generation.get("prompt_text", ""))


if __name__ == "__main__":
    main()