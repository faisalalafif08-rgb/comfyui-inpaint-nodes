from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: python .\\apps\\export_summary.py <report_json> <output_txt>")
        return 1

    report_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2])

    if not report_path.exists():
        print(f"Report not found: {report_path}")
        return 1

    data = json.loads(report_path.read_text(encoding="utf-8"))

    lines = []
    lines.append("ALTHEEB SUMMARY")
    lines.append("=" * 40)
    for key in [
        "video_id",
        "frames_count",
        "faces_count",
        "objects_count",
        "tracks_count",
        "identity_events_count",
        "events_count",
        "scenes_count",
        "scenes_valid_count",
        "scenes_invalid_count",
        "best_face_available",
        "gait_available",
        "decisions_count",
    ]:
        lines.append(f"{key}: {data.get(key)}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Summary exported to: {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())