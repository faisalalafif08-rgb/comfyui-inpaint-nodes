from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene-graph", required=True)
    args = parser.parse_args()

    path = Path(args.scene_graph)
    if not path.exists():
        raise FileNotFoundError(f"SCENE_GRAPH_NOT_FOUND: {path}")

    data = load_json(path)

    print("=== SCENE GRAPH INSPECT ===")
    print(f"video_id: {data.get('video_id')}")
    print(f"scene_phase: {data.get('scene_phase')}")
    print(f"attention_level: {data.get('attention_level')}")
    print(f"severity: {data.get('severity')}")
    print(f"action: {data.get('action')}")
    print(f"subjects_count: {len(data.get('subjects', []))}")
    print(f"relations_count: {len(data.get('relations', []))}")
    print(f"top_tags: {data.get('knowledge', {}).get('top_tags', [])}")
    print("generation:")
    print(json.dumps(data.get("generation", {}), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()