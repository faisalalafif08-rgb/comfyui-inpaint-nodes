from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python .\\apps\\inspect_run.py <report_json>")
        return 1

    report_path = Path(sys.argv[1])
    if not report_path.exists():
        print(f"Report not found: {report_path}")
        return 1

    data = json.loads(report_path.read_text(encoding="utf-8"))
    print("=== ALTHEEB RUN INSPECT ===")
    for k, v in data.items():
        if k == "outputs":
            print("outputs:")
            for ok, ov in v.items():
                print(f"  {ok}: {ov}")
        else:
            print(f"{k}: {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())