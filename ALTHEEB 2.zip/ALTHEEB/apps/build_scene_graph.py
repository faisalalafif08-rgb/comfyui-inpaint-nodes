from __future__ import annotations

import argparse
import json
from pathlib import Path

from scene.scene_graph_builder import build_scene_graph_from_report


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    report_path = Path(args.report)
    scene_graph = build_scene_graph_from_report(report_path=report_path)

    video_id = str(scene_graph["video_id"])
    out_path = report_path.parent / f"{video_id}_scene_graph.json"
    write_json(out_path, scene_graph)

    report = json.loads(report_path.read_text(encoding="utf-8"))
    report["scene_graph_ready"] = True
    report.setdefault("outputs", {})
    report["outputs"]["scene_graph_json"] = str(out_path)
    write_json(report_path, report)

    print("=== SCENE GRAPH BUILT ===")
    print(f"video_id: {video_id}")
    print(f"scene_phase: {scene_graph['scene_phase']}")
    print(f"attention_level: {scene_graph['attention_level']}")
    print(f"severity: {scene_graph['severity']}")
    print(f"action: {scene_graph['action']}")
    print(f"scene_graph_json: {out_path}")
    print(f"report_json_updated: {report_path}")


if __name__ == "__main__":
    main()