from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List

from core.models import EventRecord
from scene.qqss_brain_reasoner import QQSSBrainReasoner
from scene.qqss_scene_builder import QQSSSceneBuilder


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def event_from_dict(item: Dict) -> EventRecord:
    return EventRecord(
        event_id=str(item["event_id"]),
        video_id=str(item["video_id"]),
        start_time=float(item["start_time"]),
        end_time=float(item["end_time"]),
        frame_start_id=int(item["frame_start_id"]),
        frame_end_id=int(item["frame_end_id"]),
        event_type=str(item["event_type"]),
        faces_count=int(item.get("faces_count", 0)),
        objects_count=int(item.get("objects_count", 0)),
        max_motion_score=float(item.get("max_motion_score", 0.0)),
        confidence=float(item.get("confidence", 0.0)),
        notes=str(item.get("notes", "")),
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")

    report = load_json(report_path)
    outputs = report.get("outputs", {})

    qqss_summary_json = Path(outputs["qqss_summary_json"])
    qqss_bridge_events_json = Path(outputs["qqss_bridge_events_json"])

    if not qqss_summary_json.exists():
        raise FileNotFoundError(f"QQSS_SUMMARY_NOT_FOUND: {qqss_summary_json}")
    if not qqss_bridge_events_json.exists():
        raise FileNotFoundError(f"QQSS_BRIDGE_EVENTS_NOT_FOUND: {qqss_bridge_events_json}")

    qqss_summary = load_json(qqss_summary_json)
    qqss_bridge_events = [event_from_dict(x) for x in load_json(qqss_bridge_events_json)]

    video_id = str(report["video_id"])
    indices_dir = report_path.parent

    qqss_scenes_json = indices_dir / f"{video_id}_qqss_scenes.json"
    qqss_brain_decisions_json = indices_dir / f"{video_id}_qqss_brain_decisions.json"

    scene_builder = QQSSSceneBuilder()
    brain_reasoner = QQSSBrainReasoner()

    qqss_scenes = scene_builder.build(video_id=video_id, qqss_bridge_events=qqss_bridge_events)
    qqss_brain_decisions = brain_reasoner.build(
        video_id=video_id,
        qqss_summary=qqss_summary,
        qqss_bridge_events=qqss_bridge_events,
    )

    write_json(qqss_scenes_json, [asdict(x) for x in qqss_scenes])
    write_json(qqss_brain_decisions_json, [asdict(x) for x in qqss_brain_decisions])

    report["qqss_scenes_count"] = len(qqss_scenes)
    report["qqss_brain_decisions_count"] = len(qqss_brain_decisions)
    report.setdefault("outputs", {})
    report["outputs"]["qqss_scenes_json"] = str(qqss_scenes_json)
    report["outputs"]["qqss_brain_decisions_json"] = str(qqss_brain_decisions_json)

    write_json(report_path, report)

    print("=== QQSS SCENE/BRAIN FUSED ===")
    print(f"video_id: {video_id}")
    print(f"qqss_scenes_count: {len(qqss_scenes)}")
    print(f"qqss_brain_decisions_count: {len(qqss_brain_decisions)}")
    print(f"qqss_scenes_json: {qqss_scenes_json}")
    print(f"qqss_brain_decisions_json: {qqss_brain_decisions_json}")
    print(f"report_json_updated: {report_path}")


if __name__ == "__main__":
    main()