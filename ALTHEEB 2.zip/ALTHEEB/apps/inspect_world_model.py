from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")

    report = load_json(report_path)
    outputs = report.get("outputs", {})

    knowledge_path = Path(outputs["knowledge_context_json"])
    graph_path = Path(outputs["scene_graph_json"])
    brain_path = Path(outputs["brain_state_json"])
    gen_path = Path(outputs["generation_plan_json"])

    knowledge = load_json(knowledge_path)
    graph = load_json(graph_path)
    brain = load_json(brain_path)
    gen = load_json(gen_path)

    print("=== WORLD MODEL INSPECT ===")
    print(f"video_id: {report.get('video_id')}")
    print(f"scene_phase: {brain.get('scene_phase')}")
    print(f"action: {brain.get('action')}")
    print(f"attention_level: {brain.get('attention_level')}")
    print(f"dominant_relation: {knowledge.get('dominant_relation')}")
    print(f"dominant_pattern: {knowledge.get('dominant_pattern')}")
    print(f"anomalies_count: {len(knowledge.get('anomalies', []))}")
    print(f"nodes_count: {len(graph.get('nodes', []))}")
    print(f"edges_count: {len(graph.get('edges', []))}")
    print(f"generation_mode: {gen.get('mode')}")
    print(f"shot_type: {gen.get('shot_plan', {}).get('shot_type')}")
    print(f"target_primary_cell: {gen.get('control_hints', {}).get('target_primary_cell')}")


if __name__ == "__main__":
    main()