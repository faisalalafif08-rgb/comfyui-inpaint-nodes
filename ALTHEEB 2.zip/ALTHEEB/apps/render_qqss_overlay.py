from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2

from qqss.grid_mapper import GridMapper
from qqss.grid_renderer import render_grid_overlay


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def pick_frame(frames, frame_id: int):
    if frame_id >= 0:
        for item in frames:
            if int(item.get("frame_id", -1)) == frame_id:
                return item
        raise RuntimeError(f"FRAME_ID_NOT_FOUND: {frame_id}")

    if not frames:
        raise RuntimeError("NO_FRAMES_IN_FRAMES_JSON")
    return frames[-1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    parser.add_argument("--frame-id", type=int, default=-1)
    parser.add_argument("--rows", type=int, default=6)
    parser.add_argument("--cols", type=int, default=8)
    parser.add_argument("--show-labels", action="store_true")
    parser.add_argument("--out", default="")
    args = parser.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")

    report = load_json(report_path)
    outputs = report.get("outputs", {})

    frames_json = Path(outputs["frames_json"])
    qqss_events_json = Path(outputs["qqss_events_json"])
    qqss_target_json = Path(outputs["qqss_target_json"])

    frames = load_json(frames_json)
    qqss_events = load_json(qqss_events_json) if qqss_events_json.exists() else []
    qqss_target = load_json(qqss_target_json) if qqss_target_json.exists() else {}

    frame_row = pick_frame(frames, args.frame_id)
    frame_path = Path(frame_row["image_path"])
    if not frame_path.exists():
        raise FileNotFoundError(f"FRAME_IMAGE_NOT_FOUND: {frame_path}")

    image = cv2.imread(str(frame_path))
    if image is None:
        raise RuntimeError(f"FAILED_TO_READ_IMAGE: {frame_path}")

    h, w = image.shape[:2]
    grid = GridMapper(width=w, height=h, rows=args.rows, cols=args.cols)

    out = render_grid_overlay(
        image=image,
        grid=grid,
        target_data=qqss_target,
        qqss_events=qqss_events,
        frame_id=int(frame_row["frame_id"]),
        show_labels=bool(args.show_labels),
    )

    if args.out:
        out_path = Path(args.out)
    else:
        out_path = Path("reports") / f"qqss_overlay_frame_{int(frame_row['frame_id']):06d}.jpg"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(out_path), out)
    if not ok:
        raise RuntimeError(f"FAILED_TO_WRITE_OUTPUT: {out_path}")

    print("=== QQSS OVERLAY RENDERED ===")
    print(f"video_id: {report.get('video_id')}")
    print(f"frame_id: {frame_row['frame_id']}")
    print(f"frame_image: {frame_path}")
    print(f"saved_to: {out_path}")


if __name__ == "__main__":
    main()