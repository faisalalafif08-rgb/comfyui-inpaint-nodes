from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")

    report = load_json(report_path)
    outputs = report.get("outputs", {})

    qqss_events_path = Path(outputs["qqss_events_json"])
    qqss_summary_path = Path(outputs["qqss_summary_json"])
    qqss_target_path = Path(outputs["qqss_target_json"])

    qqss_events = load_json(qqss_events_path) if qqss_events_path.exists() else []
    qqss_summary = load_json(qqss_summary_path) if qqss_summary_path.exists() else {}
    qqss_target = load_json(qqss_target_path) if qqss_target_path.exists() else {}

    print("=== QQSS PY INSPECT ===")
    print(f"video_id: {report.get('video_id')}")
    print(f"events_count: {len(qqss_events)}")
    print(f"high_risk_count: {qqss_summary.get('high_risk_count', 0)}")
    print(f"on_target_count: {qqss_summary.get('on_target_count', 0)}")
    print(f"near_target_count: {qqss_summary.get('near_target_count', 0)}")

    if qqss_target:
        print("target:")
        print(json.dumps(qqss_target, ensure_ascii=False, indent=2))

    if qqss_events:
        top = sorted(qqss_events, key=lambda x: float(x.get("risk_score", 0.0)), reverse=True)[:5]
        print("top_events:")
        print(json.dumps(top, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()