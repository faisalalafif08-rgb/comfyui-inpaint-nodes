from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qqss.qqss_engine import QQSSEngine


def main():
    engine = QQSSEngine(width=400, height=400, rows=4, cols=4)
    target = engine.set_target("target_1", [150, 150, 250, 250], radius=1)

    s1 = engine.analyze_track("trk_1", [10, 150, 70, 230], frame_id=1, timestamp=0.0)
    s2 = engine.analyze_track("trk_1", [95, 150, 160, 230], frame_id=2, timestamp=0.2)
    s3 = engine.analyze_track("trk_1", [165, 165, 235, 235], frame_id=3, timestamp=0.4)

    payload = {
        "target": target,
        "step_1": s1,
        "step_2": s2,
        "step_3": s3,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()