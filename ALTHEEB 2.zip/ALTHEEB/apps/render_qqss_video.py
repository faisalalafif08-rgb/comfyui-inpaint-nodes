from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2

from qqss.grid_mapper import GridMapper
from qqss.grid_renderer import render_grid_overlay


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_report(report_path: Path):
    if not report_path.exists():
        raise FileNotFoundError(f"REPORT_NOT_FOUND: {report_path}")
    report = load_json(report_path)
    outputs = report.get("outputs", {})
    required = ["frames_json", "qqss_events_json", "qqss_target_json", "video_json"]
    for key in required:
        if key not in outputs:
            raise RuntimeError(f"MISSING_OUTPUT_KEY: {key}")
    return report, outputs


def estimate_fps(video_meta: dict, frames: list, fallback: float = 5.0) -> float:
    fps = float(video_meta.get("fps", 0.0) or 0.0)
    if fps > 0:
        return fps

    if len(frames) >= 2:
        t0 = float(frames[0].get("timestamp", 0.0))
        t1 = float(frames[1].get("timestamp", 0.0))
        dt = t1 - t0
        if dt > 0:
            return max(1.0, 1.0 / dt)

    return fallback


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    parser.add_argument("--rows", type=int, default=6)
    parser.add_argument("--cols", type=int, default=8)
    parser.add_argument("--fps", type=float, default=0.0)
    parser.add_argument("--show-labels", action="store_true")
    parser.add_argument("--out", default="reports/qqss_overlay_video.mp4")
    args = parser.parse_args()

    report_path = Path(args.report)
    report, outputs = resolve_report(report_path)

    frames_json = Path(outputs["frames_json"])
    qqss_events_json = Path(outputs["qqss_events_json"])
    qqss_target_json = Path(outputs["qqss_target_json"])
    video_json = Path(outputs["video_json"])

    frames = load_json(frames_json)
    qqss_events = load_json(qqss_events_json) if qqss_events_json.exists() else []
    qqss_target = load_json(qqss_target_json) if qqss_target_json.exists() else {}
    video_meta = load_json(video_json) if video_json.exists() else {}

    if not frames:
        raise RuntimeError("NO_FRAMES_FOUND")

    first_frame_path = Path(frames[0]["image_path"])
    first_image = cv2.imread(str(first_frame_path))
    if first_image is None:
        raise RuntimeError(f"FAILED_TO_READ_FIRST_FRAME: {first_frame_path}")

    h, w = first_image.shape[:2]
    grid = GridMapper(width=w, height=h, rows=args.rows, cols=args.cols)

    fps = float(args.fps) if float(args.fps) > 0 else estimate_fps(video_meta, frames, fallback=5.0)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(out_path), fourcc, fps, (w, h))
    if not writer.isOpened():
        raise RuntimeError(f"FAILED_TO_OPEN_VIDEO_WRITER: {out_path}")

    try:
        for frame_row in frames:
            frame_id = int(frame_row["frame_id"])
            frame_path = Path(frame_row["image_path"])
            image = cv2.imread(str(frame_path))
            if image is None:
                raise RuntimeError(f"FAILED_TO_READ_FRAME: {frame_path}")

            rendered = render_grid_overlay(
                image=image,
                grid=grid,
                target_data=qqss_target,
                qqss_events=qqss_events,
                frame_id=frame_id,
                show_labels=bool(args.show_labels),
            )
            writer.write(rendered)
    finally:
        writer.release()

    print("=== QQSS VIDEO RENDERED ===")
    print(f"video_id: {report.get('video_id')}")
    print(f"frames_count: {len(frames)}")
    print(f"fps_used: {fps}")
    print(f"saved_to: {out_path}")


if __name__ == "__main__":
    main()