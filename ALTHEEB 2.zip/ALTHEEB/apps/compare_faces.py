from __future__ import annotations

import sys
from pathlib import Path

from identity.face_embedder import FaceEmbedder


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: python .\\apps\\compare_faces.py <img1> <img2>")
        return 1

    p1 = Path(sys.argv[1])
    p2 = Path(sys.argv[2])

    if not p1.exists() or not p2.exists():
        print("One or both image paths do not exist.")
        return 1

    embedder = FaceEmbedder()
    e1 = embedder.embed_path(str(p1))
    e2 = embedder.embed_path(str(p2))

    if e1 is None or e2 is None:
        print("Failed to compute one or both embeddings.")
        return 1

    score = embedder.similarity(e1, e2)
    print(f"similarity: {score:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())