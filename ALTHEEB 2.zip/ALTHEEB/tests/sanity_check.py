#!/usr/bin/env python3
from __future__ import annotations

import importlib
import sys
from pathlib import Path

REQUIRED_FILES = [
    "config/system.yaml",
    "run.py",
    "core/models.py",
    "core/logger.py",
    "core/paths.py",
    "perception/video_reader.py",
    "perception/frame_extractor.py",
    "perception/face_detector.py",
    "perception/object_detector.py",
    "perception/object_tracker.py",
    "identity/face_quality.py",
    "identity/face_embedder.py",
    "identity/face_aligner.py",
    "identity/face_matcher.py",
    "identity/identity_vault.py",
    "analysis/lower_body_analyzer.py",
    "scene/brain.py",
    "scene/event_builder.py",
    "scene/scene_builder.py",
    "scene/scene_validator.py",
    "orchestration/pipeline.py",
]

REQUIRED_IMPORTS = ["cv2", "numpy", "yaml"]
OPTIONAL_IMPORTS = ["mediapipe"]

def main() -> int:
    root = Path(__file__).resolve().parents[1]
    print("=== ALTHEEB SANITY CHECK ===")
    print("Python:", sys.executable)

    ok = True

    missing = []
    for rel in REQUIRED_FILES:
        if not (root / rel).exists():
            missing.append(rel)

    if missing:
        ok = False
        print("\nMissing files:")
        for x in missing:
            print("  -", x)
    else:
        print("\nFiles: OK")

    for mod in REQUIRED_IMPORTS:
        try:
            importlib.import_module(mod)
            print(f"[OK] import {mod}")
        except Exception as e:
            ok = False
            print(f"[FAIL] import {mod}: {e}")

    for mod in OPTIONAL_IMPORTS:
        try:
            importlib.import_module(mod)
            print(f"[OK] optional import {mod}")
        except Exception as e:
            print(f"[WARN] optional import {mod}: {e}")

    print("\nSANITY =", "PASS" if ok else "FAIL")
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())