from __future__ import annotations

import unittest

import numpy as np

from qqss.grid_mapper import GridMapper
from qqss.grid_renderer import render_grid_overlay


class TestGridRenderer(unittest.TestCase):
    def test_render_shape(self):
        image = np.zeros((240, 320, 3), dtype=np.uint8)
        grid = GridMapper(width=320, height=240, rows=4, cols=4)

        target = {
            "target_id": "target_1",
            "bbox": [80, 60, 160, 120],
            "primary_cell": "r01_c01",
            "covered_cells": ["r01_c01"],
            "neighbor_cells": ["r00_c00", "r00_c01", "r01_c00"],
        }

        events = [
            {
                "track_id": "trk_1",
                "frame_id": 1,
                "relation": "on_target",
                "pattern": "target_entry",
                "risk_score": 0.90,
                "current_cell": "r01_c01",
                "target_cell": "r01_c01",
            }
        ]

        out = render_grid_overlay(
            image=image,
            grid=grid,
            target_data=target,
            qqss_events=events,
            frame_id=1,
            show_labels=True,
        )
        self.assertEqual(out.shape, image.shape)


if __name__ == "__main__":
    unittest.main()