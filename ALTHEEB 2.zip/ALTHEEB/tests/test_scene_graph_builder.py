from __future__ import annotations

import unittest

from scene.scene_graph_builder import SceneGraphBuilder


class TestSceneGraphBuilder(unittest.TestCase):
    def test_build_graph(self):
        builder = SceneGraphBuilder()

        report = {"video_id": "vid_1"}
        target = {
            "target_id": "target_1",
            "primary_cell": "r03_c02",
            "covered_cells": ["r03_c02"],
            "neighbor_cells": ["r03_c01", "r03_c03"]
        }
        events = [
            {
                "track_id": "track_1",
                "relation": "on_target",
                "pattern": "target_entry",
                "risk_score": 0.8,
                "current_cell": "r03_c02"
            },
            {
                "track_id": "track_2",
                "relation": "near_target",
                "pattern": "approaching",
                "risk_score": 0.7,
                "current_cell": "r03_c01"
            }
        ]

        out = builder.build(report, target, events)
        self.assertEqual(len(out["nodes"]), 3)
        self.assertEqual(len(out["edges"]), 2)


if __name__ == "__main__":
    unittest.main()