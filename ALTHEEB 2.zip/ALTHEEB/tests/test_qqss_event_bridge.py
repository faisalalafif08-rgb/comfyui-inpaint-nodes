from __future__ import annotations

import unittest

from scene.qqss_event_bridge import QQSSEventBridge


class TestQQSSEventBridge(unittest.TestCase):
    def test_bridge_builds_expected_events(self):
        bridge = QQSSEventBridge(min_risk_score=0.70)

        qqss_events = [
            {
                "track_id": "track_1",
                "frame_id": 10,
                "timestamp": 2.0,
                "relation": "on_target",
                "pattern": "target_entry",
                "risk_score": 0.8,
            },
            {
                "track_id": "track_1",
                "frame_id": 11,
                "timestamp": 2.2,
                "relation": "on_target",
                "pattern": "on_target_hold",
                "risk_score": 0.7,
            },
            {
                "track_id": "track_2",
                "frame_id": 12,
                "timestamp": 2.4,
                "relation": "near_target",
                "pattern": "approaching",
                "risk_score": 0.75,
            },
        ]

        out = bridge.build(video_id="vid_1", qqss_events=qqss_events)
        self.assertEqual(len(out), 3)
        self.assertEqual(out[0].event_type, "qqss_target_entry")
        self.assertEqual(out[1].event_type, "qqss_on_target_hold")
        self.assertEqual(out[2].event_type, "qqss_high_risk_presence")


if __name__ == "__main__":
    unittest.main()