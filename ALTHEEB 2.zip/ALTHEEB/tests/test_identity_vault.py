#!/usr/bin/env python3
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from core.models import FaceObservation
from identity.face_embedder import FaceEmbedder
from identity.identity_vault import IdentityVault


class TestIdentityVault(unittest.TestCase):
    def _make_face_image(self, path: Path, seed: int = 1):
        rng = np.random.default_rng(seed)
        img = np.full((120, 120, 3), 180, dtype=np.uint8)

        cv2.circle(img, (60, 60), 40, (200, 200, 200), -1)
        cv2.circle(img, (45, 50), 5, (30, 30, 30), -1)
        cv2.circle(img, (75, 50), 5, (30, 30, 30), -1)
        cv2.ellipse(img, (60, 75), (15, 8), 0, 0, 180, (40, 40, 40), 2)

        noise = rng.integers(0, 5, size=img.shape, dtype=np.uint8)
        img = cv2.add(img, noise)

        cv2.imwrite(str(path), img)

    def test_embedder_returns_vector(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "face.jpg"
            self._make_face_image(path, seed=1)

            embedder = FaceEmbedder()
            emb = embedder.embed_path(str(path))

            self.assertIsNotNone(emb)
            self.assertGreater(len(emb), 0)

    def test_identity_vault_matches_similar_faces(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            face1 = td / "face1.jpg"
            face2 = td / "face2.jpg"

            self._make_face_image(face1, seed=1)
            self._make_face_image(face2, seed=1)

            vault = IdentityVault(
                vault_path=str(td / "vault.json"),
                min_quality=0.10,
                match_threshold=0.85,
            )

            obs1 = FaceObservation(
                face_obs_id="f1",
                video_id="vid_001",
                frame_id=1,
                timestamp=0.1,
                bbox=[10, 10, 100, 100],
                crop_path=str(face1),
                confidence=1.0,
                quality_score=0.80,
            )

            obs2 = FaceObservation(
                face_obs_id="f2",
                video_id="vid_001",
                frame_id=2,
                timestamp=0.2,
                bbox=[10, 10, 100, 100],
                crop_path=str(face2),
                confidence=1.0,
                quality_score=0.82,
            )

            rec1 = vault.register_face(obs1)
            rec2 = vault.register_face(obs2)

            self.assertEqual(rec1.action, "created")
            self.assertIn(rec2.action, {"matched", "created"})
            self.assertTrue(vault.snapshot()["people"])

    def test_identity_vault_rejects_low_quality(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            face1 = td / "face1.jpg"
            self._make_face_image(face1, seed=3)

            vault = IdentityVault(
                vault_path=str(td / "vault.json"),
                min_quality=0.50,
                match_threshold=0.90,
            )

            obs = FaceObservation(
                face_obs_id="f_low",
                video_id="vid_001",
                frame_id=1,
                timestamp=0.1,
                bbox=[10, 10, 100, 100],
                crop_path=str(face1),
                confidence=1.0,
                quality_score=0.10,
            )

            rec = vault.register_face(obs)
            self.assertEqual(rec.action, "rejected")


if __name__ == "__main__":
    unittest.main()