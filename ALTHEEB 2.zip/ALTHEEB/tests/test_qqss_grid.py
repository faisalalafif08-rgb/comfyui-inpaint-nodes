from __future__ import annotations

import unittest

from qqss.grid_mapper import GridMapper
from qqss.qqss_engine import QQSSEngine


class TestQQSSGrid(unittest.TestCase):
    def test_grid_mapping(self):
        grid = GridMapper(width=400, height=400, rows=4, cols=4)
        self.assertEqual(grid.point_to_cell(10, 10), "r00_c00")
        self.assertEqual(grid.point_to_cell(399, 399), "r03_c03")

    def test_target_entry(self):
        engine = QQSSEngine(width=400, height=400, rows=4, cols=4)
        engine.set_target("target_1", [150, 150, 250, 250], radius=1)

        step1 = engine.analyze_track("trk_1", [10, 150, 70, 230], frame_id=1, timestamp=0.0)
        step2 = engine.analyze_track("trk_1", [95, 150, 160, 230], frame_id=2, timestamp=0.2)
        step3 = engine.analyze_track("trk_1", [165, 165, 235, 235], frame_id=3, timestamp=0.4)

        self.assertEqual(step3["relation"], "on_target")
        self.assertIn(step3["pattern"], {"target_entry", "on_target_hold", "approaching"})
        self.assertGreaterEqual(step3["risk_score"], 0.7)
        self.assertGreater(step2["signal"]["delta_target_distance"], -10)

if __name__ == "__main__":
    unittest.main()