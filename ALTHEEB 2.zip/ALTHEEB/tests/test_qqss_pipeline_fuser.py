from __future__ import annotations

import unittest

from core.models import EventRecord
from scene.qqss_pipeline_fuser import QQSSPipelineFuser


class TestQQSSPipelineFuser(unittest.TestCase):
    def test_fuse_merges_events_scenes_decisions(self):
        fuser = QQSSPipelineFuser()

        qqss_summary = {
            "high_risk_count": 2,
            "on_target_count": 1,
            "near_target_count": 1,
            "bridge_events_count": 2,
        }

        events = [
            EventRecord(
                event_id="e0",
                video_id="vid_1",
                start_time=0.2,
                end_time=0.4,
                frame_start_id=1,
                frame_end_id=2,
                event_type="motion_spike",
                confidence=0.7,
            )
        ]
        qqss_bridge_events = [
            EventRecord(
                event_id="qe1",
                video_id="vid_1",
                start_time=1.0,
                end_time=1.2,
                frame_start_id=5,
                frame_end_id=6,
                event_type="qqss_target_entry",
                confidence=0.8,
            ),
            EventRecord(
                event_id="qe2",
                video_id="vid_1",
                start_time=1.3,
                end_time=1.5,
                frame_start_id=7,
                frame_end_id=8,
                event_type="qqss_on_target_hold",
                confidence=0.75,
            ),
        ]
        scenes = []
        decisions = []

        out = fuser.fuse(
            video_id="vid_1",
            qqss_summary=qqss_summary,
            qqss_bridge_events=qqss_bridge_events,
            events=events,
            scenes=scenes,
            decisions=decisions,
        )

        self.assertEqual(len(out["events"]), 3)
        self.assertGreaterEqual(len(out["qqss_scenes"]), 1)
        self.assertGreaterEqual(len(out["qqss_brain_decisions"]), 1)
        self.assertEqual(len(out["decisions"]), len(out["qqss_brain_decisions"]))


if __name__ == "__main__":
    unittest.main()