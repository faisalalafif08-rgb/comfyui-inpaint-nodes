from __future__ import annotations

import unittest

from brain.world_plausibility import WorldPlausibility


class TestWorldPlausibility(unittest.TestCase):
    def test_evaluate(self):
        engine = WorldPlausibility()
        out = engine.evaluate(
            report={
                "frames_count": 20,
                "objects_count": 8,
                "tracks_count": 2,
                "qqss_events_count": 5
            },
            qqss_summary={
                "high_risk_count": 2,
                "bridge_events_count": 2
            },
            qqss_scenes=[{"scene_id": "s1"}]
        )
        self.assertGreaterEqual(out["score"], 0.65)
        self.assertIn(out["status"], {"stable", "acceptable", "fragile"})


if __name__ == "__main__":
    unittest.main()