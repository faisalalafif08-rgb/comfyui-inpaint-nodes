from __future__ import annotations

import unittest

from core.models import EventRecord
from scene.qqss_brain_reasoner import QQSSBrainReasoner


class TestQQSSBrainReasoner(unittest.TestCase):
    def test_build_creates_decisions(self):
        reasoner = QQSSBrainReasoner()

        summary = {
            "high_risk_count": 3,
            "on_target_count": 2,
            "near_target_count": 1,
            "bridge_events_count": 4,
        }

        bridge = [
            EventRecord(
                event_id="e1",
                video_id="vid_1",
                start_time=1.0,
                end_time=1.2,
                frame_start_id=1,
                frame_end_id=2,
                event_type="qqss_target_entry",
                confidence=0.8,
            )
        ]

        out = reasoner.build(video_id="vid_1", qqss_summary=summary, qqss_bridge_events=bridge)
        event_types = {x.event_type for x in out}

        self.assertIn("qqss_attention", event_types)
        self.assertIn("qqss_target_hold", event_types)
        self.assertIn("qqss_event_fusion", event_types)


if __name__ == "__main__":
    unittest.main()