from __future__ import annotations

import unittest

from core.models import EventRecord
from scene.qqss_scene_builder import QQSSSceneBuilder


class TestQQSSSceneBuilder(unittest.TestCase):
    def test_build_groups_close_events(self):
        builder = QQSSSceneBuilder(max_gap_sec=0.5)

        rows = [
            EventRecord(
                event_id="e1",
                video_id="vid_1",
                start_time=1.0,
                end_time=1.2,
                frame_start_id=5,
                frame_end_id=6,
                event_type="qqss_target_entry",
                confidence=0.8,
            ),
            EventRecord(
                event_id="e2",
                video_id="vid_1",
                start_time=1.3,
                end_time=1.5,
                frame_start_id=7,
                frame_end_id=8,
                event_type="qqss_on_target_hold",
                confidence=0.7,
            ),
            EventRecord(
                event_id="e3",
                video_id="vid_1",
                start_time=3.0,
                end_time=3.1,
                frame_start_id=15,
                frame_end_id=16,
                event_type="qqss_high_risk_presence",
                confidence=0.75,
            ),
        ]

        out = builder.build(video_id="vid_1", qqss_bridge_events=rows)
        self.assertEqual(len(out), 2)
        self.assertEqual(out[0].event_ids, ["e1", "e2"])
        self.assertEqual(out[1].event_ids, ["e3"])


if __name__ == "__main__":
    unittest.main()