from __future__ import annotations

import unittest

from brain.cinematic_reasoner import CinematicReasoner


class TestCinematicReasoner(unittest.TestCase):
    def test_reason(self):
        engine = CinematicReasoner()
        out = engine.reason(
            report={"video_id": "vid_1"},
            qqss_summary={
                "high_risk_count": 3,
                "on_target_count": 2,
                "near_target_count": 1
            },
            knowledge_summary={
                "dominant_pattern": "target_entry",
                "dominant_relation": "on_target"
            },
            plausibility={"score": 0.9}
        )
        self.assertEqual(out["scene_phase"], "pressure")
        self.assertIn(out["action"], {"ALERT", "INVESTIGATE", "LOG"})


if __name__ == "__main__":
    unittest.main()