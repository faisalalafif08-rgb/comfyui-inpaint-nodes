#!/usr/bin/env python3
from __future__ import annotations

import unittest

from scene.event_builder import EventBuilder
from scene.scene_builder import SceneBuilder
from scene.scene_validator import SceneValidator


class TestEventSceneBuilders(unittest.TestCase):
    def test_event_builder_creates_events(self):
        builder = EventBuilder(
            motion_event_threshold=0.10,
            event_gap_sec=0.50,
        )

        frame_rows = [
            {"frame_id": 0, "timestamp": 0.0, "motion_score": 0.01, "num_faces": 0, "num_objects": 0, "face_jump": 0.0, "object_jump": 0.0, "decision_emitted": False},
            {"frame_id": 1, "timestamp": 0.2, "motion_score": 0.20, "num_faces": 1, "num_objects": 1, "face_jump": 1.0, "object_jump": 1.0, "decision_emitted": False},
            {"frame_id": 2, "timestamp": 0.4, "motion_score": 0.25, "num_faces": 1, "num_objects": 1, "face_jump": 0.0, "object_jump": 0.0, "decision_emitted": False},
            {"frame_id": 3, "timestamp": 1.2, "motion_score": 0.00, "num_faces": 0, "num_objects": 0, "face_jump": 0.0, "object_jump": 0.0, "decision_emitted": False},
            {"frame_id": 4, "timestamp": 2.0, "motion_score": 0.30, "num_faces": 1, "num_objects": 2, "face_jump": 1.0, "object_jump": 2.0, "decision_emitted": True},
            {"frame_id": 5, "timestamp": 2.2, "motion_score": 0.18, "num_faces": 1, "num_objects": 2, "face_jump": 0.0, "object_jump": 0.0, "decision_emitted": False},
            {"frame_id": 6, "timestamp": 3.2, "motion_score": 0.00, "num_faces": 0, "num_objects": 0, "face_jump": 0.0, "object_jump": 0.0, "decision_emitted": False},
        ]

        events = builder.build("vid_test", frame_rows)
        self.assertGreaterEqual(len(events), 1)

    def test_scene_builder_creates_scenes(self):
        builder = SceneBuilder(
            scene_gap_sec=1.0,
            min_scene_duration_sec=0.1,
        )

        events = [
            {
                "event_id": "e1",
                "video_id": "vid_test",
                "start_time": 0.0,
                "end_time": 1.0,
                "faces_count": 1,
                "objects_count": 2,
                "confidence": 0.8,
            },
            {
                "event_id": "e2",
                "video_id": "vid_test",
                "start_time": 1.4,
                "end_time": 2.0,
                "faces_count": 1,
                "objects_count": 1,
                "confidence": 0.7,
            },
        ]

        # تحويل مبسط ليتوافق مع SceneBuilder
        class E:
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)

        scene_events = [E(**x) for x in events]
        scenes = builder.build("vid_test", scene_events)

        self.assertGreaterEqual(len(scenes), 1)

    def test_scene_validator_flags_invalid_scenes(self):
        validator = SceneValidator(
            min_scene_confidence=0.5,
            min_events_per_scene=2,
            min_scene_duration_sec=1.0,
            require_any_faces_or_objects=False,
        )

        scenes = [
            {
                "scene_id": "s1",
                "start_time": 0.0,
                "end_time": 0.5,
                "event_ids": ["e1"],
                "faces_count": 0,
                "objects_count": 0,
                "confidence": 0.2,
            },
            {
                "scene_id": "s2",
                "start_time": 1.0,
                "end_time": 3.0,
                "event_ids": ["e2", "e3"],
                "faces_count": 1,
                "objects_count": 1,
                "confidence": 0.9,
            },
        ]

        validations, summary = validator.validate(scenes)

        self.assertEqual(len(validations), 2)
        self.assertEqual(summary["scenes_total"], 2)
        self.assertEqual(summary["scenes_valid"], 1)
        self.assertEqual(summary["scenes_invalid"], 1)


if __name__ == "__main__":
    unittest.main()