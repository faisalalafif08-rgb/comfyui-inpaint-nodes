from __future__ import annotations

import unittest

from core.models import TrackedObject
from qqss.target_selector import QQSSTargetSelector


class TestQQSSTargetSelector(unittest.TestCase):
    def test_select_prefers_person_and_center(self):
        selector = QQSSTargetSelector()

        items = [
            TrackedObject(
                track_id="track_1",
                video_id="vid_1",
                frame_id=1,
                timestamp=0.0,
                label="car",
                bbox=[10, 10, 80, 80],
                confidence=0.95,
                source="tracker",
            ),
            TrackedObject(
                track_id="track_2",
                video_id="vid_1",
                frame_id=1,
                timestamp=0.0,
                label="person",
                bbox=[140, 90, 210, 220],
                confidence=0.70,
                source="tracker",
            ),
        ]

        picked = selector.select(
            video_id="vid_1",
            tracked_objects=items,
            frame_width=320,
            frame_height=240,
        )
        self.assertIsNotNone(picked)
        self.assertEqual(picked.track_id, "track_2")


if __name__ == "__main__":
    unittest.main()