from __future__ import annotations

import unittest

from brain.brain_v2 import BrainV2


class TestBrainV2(unittest.TestCase):
    def test_reason_alert(self):
        brain = BrainV2()

        report = {
            "qqss_events_count": 8,
            "qqss_bridge_events_count": 5,
            "qqss_high_risk_count": 4
        }
        knowledge = {
            "pressure_score": 0.9,
            "anomalies": [
                {"anomaly_type": "a1"},
                {"anomaly_type": "a2"}
            ],
            "dominant_relation": "on_target",
            "dominant_pattern": "on_target_hold"
        }
        graph = {"nodes": [1, 2], "edges": [1]}

        out = brain.reason(report, knowledge, graph)
        self.assertEqual(out["scene_phase"], "alert")
        self.assertEqual(out["action"], "ALERT")


if __name__ == "__main__":
    unittest.main()