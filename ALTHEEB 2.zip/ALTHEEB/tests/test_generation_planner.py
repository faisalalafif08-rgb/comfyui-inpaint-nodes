from __future__ import annotations

import unittest

from generation.generation_planner import GenerationPlanner


class TestGenerationPlanner(unittest.TestCase):
    def test_build_plan(self):
        planner = GenerationPlanner()

        report = {
            "video_id": "vid_1",
            "qqss_events_count": 4,
            "qqss_bridge_events_count": 2
        }
        knowledge = {
            "dominant_relation": "on_target",
            "dominant_pattern": "target_entry"
        }
        graph = {
            "zones": {
                "target_primary_cell": "r03_c02",
                "neighbor_cells": ["r03_c01", "r03_c03"]
            },
            "nodes": [1, 2],
            "edges": [1]
        }
        brain = {
            "scene_phase": "pressure",
            "camera_hint": {
                "shot_type": "medium",
                "camera_angle": "eye_level",
                "focus_mode": "target_subject_pair",
                "lighting_hint": "neutral"
            }
        }

        out = planner.build(report, knowledge, graph, brain)
        self.assertEqual(out["mode"], "cinematic_reconstruction")
        self.assertIn("target_cell=r03_c02", out["prompt"])


if __name__ == "__main__":
    unittest.main()