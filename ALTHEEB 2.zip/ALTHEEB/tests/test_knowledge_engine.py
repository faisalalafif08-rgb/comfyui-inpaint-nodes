from __future__ import annotations

import unittest

from knowledge.knowledge_engine import KnowledgeEngine


class TestKnowledgeEngine(unittest.TestCase):
    def test_detects_persistent_hold(self):
        engine = KnowledgeEngine()

        report = {
            "video_id": "vid_1",
            "tracks_count": 2,
            "motion_count": 10,
            "qqss_events_count": 5,
            "qqss_high_risk_count": 4
        }
        target = {
            "target_id": "target_1",
            "primary_cell": "r03_c02",
            "covered_cells": ["r03_c02"],
            "neighbor_cells": ["r03_c01", "r03_c03"]
        }
        events = [
            {"track_id": "t1", "relation": "on_target", "pattern": "on_target_hold", "risk_score": 0.8},
            {"track_id": "t1", "relation": "on_target", "pattern": "on_target_hold", "risk_score": 0.8},
            {"track_id": "t1", "relation": "on_target", "pattern": "on_target_hold", "risk_score": 0.8},
            {"track_id": "t2", "relation": "near_target", "pattern": "approaching", "risk_score": 0.7}
        ]
        summary = {
            "high_risk_count": 4,
            "on_target_count": 3,
            "near_target_count": 1
        }

        out = engine.analyze(report, target, events, summary, [])
        names = {x["anomaly_type"] for x in out["anomalies"]}

        self.assertIn("persistent_target_hold", names)
        self.assertIn("repeated_high_risk_presence", names)


if __name__ == "__main__":
    unittest.main()