import cv2
import numpy as np

class FeatureExtractor:
    def __init__(self):
        self.prev_gray = None

    def extract(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        if self.prev_gray is None:
            self.prev_gray = gray
            return None

        diff = cv2.absdiff(self.prev_gray, gray)
        self.prev_gray = gray

        # عتبة بسيطة لإبراز التغير
        _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)

        # حساب المساحة المتغيرة
        area = float(np.sum(thresh > 0)) / thresh.size

        # اتجاه الحركة (مركز الكتل)
        ys, xs = np.where(thresh > 0)
        if len(xs) == 0:
            return {
                "direction": "none",
                "speed": "low",
                "area": "low"
            }

        cx = xs.mean()
        cy = ys.mean()
        h, w = thresh.shape

        # تحديد الاتجاه
        if cx < w * 0.4:
            direction = "left"
        elif cx > w * 0.6:
            direction = "right"
        elif cy < h * 0.4:
            direction = "up"
        elif cy > h * 0.6:
            direction = "down"
        else:
            direction = "center"

        # سرعة تقريبية من نسبة التغير
        if area < 0.01:
            speed = "low"
        elif area < 0.05:
            speed = "medium"
        else:
            speed = "high"

        # مساحة
        area_label = "low" if area < 0.02 else "medium" if area < 0.08 else "high"

        return {
            "direction": direction,
            "speed": speed,
            "area": area_label
        }
