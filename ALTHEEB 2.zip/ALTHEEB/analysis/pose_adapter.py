from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

from core.models import BodyMetrics, PoseObservation


@dataclass
class _PoseRuntime:
    kind: str
    runtime: object


class PoseAdapter:
    """
    Backend chain:
    1) mediapipe tasks (if task model exists)
    2) mediapipe solutions
    3) ultralytics pose (optional, approximate lower-body fallback)
    4) none
    """

    def __init__(
        self,
        logger=None,
        backend: str = "auto",
        task_model_path: str = "models/mediapipe/pose_landmarker_full.task",
        ultralytics_model: str = "",
    ):
        self.logger = logger
        self.backend = str(backend or "auto").strip().lower()
        self.task_model_path = str(task_model_path or "").strip()
        self.ultralytics_model = str(ultralytics_model or "").strip()
        self.runtime = self._init_runtime()

    def _log_info(self, message: str, **meta):
        if self.logger is not None:
            self.logger.info("pose_adapter", message, **meta)

    def _log_warning(self, message: str, **meta):
        if self.logger is not None:
            self.logger.warning("pose_adapter", message, **meta)

    def _resolve_order(self):
        if self.backend == "auto":
            return ["mediapipe_tasks", "mediapipe_solutions", "ultralytics"]
        if self.backend == "mediapipe_tasks":
            return ["mediapipe_tasks"]
        if self.backend == "mediapipe_solutions":
            return ["mediapipe_solutions"]
        if self.backend == "ultralytics":
            return ["ultralytics"]
        return ["mediapipe_tasks", "mediapipe_solutions", "ultralytics"]

    def _init_runtime(self) -> Optional[_PoseRuntime]:
        for item in self._resolve_order():
            if item == "mediapipe_tasks":
                rt = self._init_mediapipe_tasks()
                if rt is not None:
                    return rt
            if item == "mediapipe_solutions":
                rt = self._init_mediapipe_solutions()
                if rt is not None:
                    return rt
            if item == "ultralytics":
                rt = self._init_ultralytics_pose()
                if rt is not None:
                    return rt
        self._log_warning("no pose backend available")
        return None

    def _init_mediapipe_tasks(self) -> Optional[_PoseRuntime]:
        try:
            model_path = Path(self.task_model_path)
            if not model_path.exists():
                self._log_warning("mediapipe task model not found", path=str(model_path))
                return None

            import mediapipe as mp
            from mediapipe.tasks.python import BaseOptions
            from mediapipe.tasks.python import vision

            options = vision.PoseLandmarkerOptions(
                base_options=BaseOptions(model_asset_path=str(model_path)),
                running_mode=vision.RunningMode.IMAGE,
                num_poses=1,
                min_pose_detection_confidence=0.5,
                min_pose_presence_confidence=0.5,
                min_tracking_confidence=0.5,
                output_segmentation_masks=False,
            )
            landmarker = vision.PoseLandmarker.create_from_options(options)
            self._log_info("pose backend initialized", backend="mediapipe_tasks")
            return _PoseRuntime(kind="mediapipe_tasks", runtime=landmarker)
        except Exception as e:
            self._log_warning("mediapipe tasks init failed", error=str(e))
            return None

    def _init_mediapipe_solutions(self) -> Optional[_PoseRuntime]:
        try:
            import mediapipe as mp

            if not hasattr(mp, "solutions") or not hasattr(mp.solutions, "pose"):
                self._log_warning("mediapipe solutions API unavailable")
                return None

            pose = mp.solutions.pose.Pose(
                static_image_mode=False,
                model_complexity=1,
                enable_segmentation=False,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5,
            )
            self._log_info("pose backend initialized", backend="mediapipe_solutions")
            return _PoseRuntime(kind="mediapipe_solutions", runtime=pose)
        except Exception as e:
            self._log_warning("mediapipe solutions init failed", error=str(e))
            return None

    def _init_ultralytics_pose(self) -> Optional[_PoseRuntime]:
        try:
            if not self.ultralytics_model:
                self._log_warning("ultralytics pose model not configured")
                return None

            from ultralytics import YOLO

            model = YOLO(self.ultralytics_model)
            self._log_info("pose backend initialized", backend="ultralytics", model=self.ultralytics_model)
            return _PoseRuntime(kind="ultralytics", runtime=model)
        except Exception as e:
            self._log_warning("ultralytics pose init failed", error=str(e))
            return None

    def close(self):
        if self.runtime is None:
            return
        try:
            if hasattr(self.runtime.runtime, "close"):
                self.runtime.runtime.close()
        except Exception:
            pass

    def extract(self, frame_bgr, video_id: str, frame_id: int, timestamp: float) -> Optional[PoseObservation]:
        if self.runtime is None:
            return None

        if self.runtime.kind == "mediapipe_tasks":
            return self._extract_mediapipe_tasks(frame_bgr, video_id, frame_id, timestamp)
        if self.runtime.kind == "mediapipe_solutions":
            return self._extract_mediapipe_solutions(frame_bgr, video_id, frame_id, timestamp)
        if self.runtime.kind == "ultralytics":
            return self._extract_ultralytics(frame_bgr, video_id, frame_id, timestamp)
        return None

    def _extract_mediapipe_tasks(self, frame_bgr, video_id: str, frame_id: int, timestamp: float):
        try:
            import cv2
            import mediapipe as mp

            h, w = frame_bgr.shape[:2]
            rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            result = self.runtime.runtime.detect(mp_image)
            if not result.pose_landmarks:
                return None

            lms = result.pose_landmarks[0]
            return self._build_pose_observation_from_mp_landmarks(
                lms=lms,
                frame_w=w,
                frame_h=h,
                video_id=video_id,
                frame_id=frame_id,
                timestamp=timestamp,
                backend="mediapipe_tasks",
            )
        except Exception as e:
            self._log_warning("pose extraction failed", backend="mediapipe_tasks", frame_id=frame_id, error=str(e))
            return None

    def _extract_mediapipe_solutions(self, frame_bgr, video_id: str, frame_id: int, timestamp: float):
        try:
            import cv2

            h, w = frame_bgr.shape[:2]
            rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            result = self.runtime.runtime.process(rgb)
            if result.pose_landmarks is None:
                return None

            lms = result.pose_landmarks.landmark
            return self._build_pose_observation_from_mp_landmarks(
                lms=lms,
                frame_w=w,
                frame_h=h,
                video_id=video_id,
                frame_id=frame_id,
                timestamp=timestamp,
                backend="mediapipe_solutions",
            )
        except Exception as e:
            self._log_warning("pose extraction failed", backend="mediapipe_solutions", frame_id=frame_id, error=str(e))
            return None

    def _extract_ultralytics(self, frame_bgr, video_id: str, frame_id: int, timestamp: float):
        try:
            results = self.runtime.runtime.predict(source=frame_bgr, verbose=False)
            if not results:
                return None

            res = results[0]
            if not hasattr(res, "keypoints") or res.keypoints is None or res.keypoints.xy is None:
                return None

            xy = res.keypoints.xy
            conf = res.keypoints.conf if hasattr(res.keypoints, "conf") else None
            if len(xy) == 0:
                return None

            pts = xy[0].tolist()
            cfs = conf[0].tolist() if conf is not None else [0.5] * len(pts)

            left_hip = pts[11]
            right_hip = pts[12]
            left_ankle = pts[15]
            right_ankle = pts[16]

            pelvis_mid_x = (float(left_hip[0]) + float(right_hip[0])) / 2.0
            hip_span_px = abs(float(left_hip[0]) - float(right_hip[0]))
            heel_span_px = abs(float(left_ankle[0]) - float(right_ankle[0]))
            toe_span_px = heel_span_px

            vis = [
                float(cfs[11]),
                float(cfs[12]),
                float(cfs[15]),
                float(cfs[16]),
            ]
            confidence = sum(vis) / max(1, len(vis))

            landmarks: Dict[str, float] = {
                "pelvis_mid_x": float(pelvis_mid_x),
                "left_heel_y": float(left_ankle[1]),
                "right_heel_y": float(right_ankle[1]),
                "left_toe_y": float(left_ankle[1]),
                "right_toe_y": float(right_ankle[1]),
                "hip_span_px": float(hip_span_px),
                "heel_span_px": float(heel_span_px),
                "toe_span_px": float(toe_span_px),
            }

            return PoseObservation(
                pose_obs_id=f"{video_id}_pose_{frame_id:06d}",
                video_id=video_id,
                frame_id=frame_id,
                timestamp=timestamp,
                backend="ultralytics_pose",
                landmarks=landmarks,
                confidence=round(confidence, 4),
                available=True,
            )
        except Exception as e:
            self._log_warning("pose extraction failed", backend="ultralytics", frame_id=frame_id, error=str(e))
            return None

    def _build_pose_observation_from_mp_landmarks(
        self,
        lms,
        frame_w: int,
        frame_h: int,
        video_id: str,
        frame_id: int,
        timestamp: float,
        backend: str,
    ) -> PoseObservation:
        left_hip = lms[23]
        right_hip = lms[24]
        left_heel = lms[29]
        right_heel = lms[30]
        left_toe = lms[31]
        right_toe = lms[32]

        pelvis_mid_x = ((left_hip.x + right_hip.x) / 2.0) * frame_w
        hip_span_px = abs(left_hip.x - right_hip.x) * frame_w
        heel_span_px = abs(left_heel.x - right_heel.x) * frame_w
        toe_span_px = abs(left_toe.x - right_toe.x) * frame_w

        vis = [
            float(getattr(left_hip, "visibility", 0.5)),
            float(getattr(right_hip, "visibility", 0.5)),
            float(getattr(left_heel, "visibility", 0.5)),
            float(getattr(right_heel, "visibility", 0.5)),
            float(getattr(left_toe, "visibility", 0.5)),
            float(getattr(right_toe, "visibility", 0.5)),
        ]
        confidence = sum(vis) / max(1, len(vis))

        landmarks: Dict[str, float] = {
            "pelvis_mid_x": float(pelvis_mid_x),
            "left_heel_y": float(left_heel.y * frame_h),
            "right_heel_y": float(right_heel.y * frame_h),
            "left_toe_y": float(left_toe.y * frame_h),
            "right_toe_y": float(right_toe.y * frame_h),
            "hip_span_px": float(hip_span_px),
            "heel_span_px": float(heel_span_px),
            "toe_span_px": float(toe_span_px),
        }

        return PoseObservation(
            pose_obs_id=f"{video_id}_pose_{frame_id:06d}",
            video_id=video_id,
            frame_id=frame_id,
            timestamp=timestamp,
            backend=backend,
            landmarks=landmarks,
            confidence=round(confidence, 4),
            available=True,
        )

    def to_gait_landmarks(self, pose_obs: Optional[PoseObservation]) -> Optional[Dict[str, float]]:
        if pose_obs is None or not pose_obs.available:
            return None

        required = {"pelvis_mid_x", "left_heel_y", "right_heel_y", "left_toe_y", "right_toe_y"}
        if not required.issubset(set(pose_obs.landmarks.keys())):
            return None
        return dict(pose_obs.landmarks)

    def to_body_metrics(self, pose_obs: Optional[PoseObservation]) -> Optional[BodyMetrics]:
        if pose_obs is None or not pose_obs.available:
            return None

        hip_span = float(pose_obs.landmarks.get("hip_span_px", 0.0))
        heel_span = float(pose_obs.landmarks.get("heel_span_px", 0.0))
        toe_span = float(pose_obs.landmarks.get("toe_span_px", 0.0))
        pelvis_mid_x = float(pose_obs.landmarks.get("pelvis_mid_x", 0.0))

        visible = hip_span > 0.0
        confidence = pose_obs.confidence
        if visible and heel_span > 0.0 and toe_span > 0.0:
            confidence = min(1.0, max(confidence, 0.55))

        return BodyMetrics(
            body_obs_id=f"{pose_obs.video_id}_body_{pose_obs.frame_id:06d}",
            video_id=pose_obs.video_id,
            frame_id=pose_obs.frame_id,
            timestamp=pose_obs.timestamp,
            hip_span_px=round(hip_span, 4),
            heel_span_px=round(heel_span, 4),
            toe_span_px=round(toe_span, 4),
            pelvis_mid_x=round(pelvis_mid_x, 4),
            lower_body_visible=visible,
            confidence=round(confidence, 4),
        )