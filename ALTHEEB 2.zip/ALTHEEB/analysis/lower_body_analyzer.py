from collections import deque
from typing import Dict, List

from core.models import GaitMetrics


class LowerBodyAnalyzer:
    """
    Baseline 2D gait analyzer using MediaPipe landmarks.
    """

    def __init__(
        self,
        fps: float = 30.0,
        max_history: int = 300,
        min_step_interval_sec: float = 0.35,
        min_global_interval_sec: float = 0.15,
    ):
        self.fps = fps
        self.history = deque(maxlen=max_history)

        self.min_step_interval_sec = min_step_interval_sec
        self.min_global_interval_sec = min_global_interval_sec

        self.left_heel_strikes: List[float] = []
        self.right_heel_strikes: List[float] = []
        self.left_toe_offs: List[float] = []
        self.right_toe_offs: List[float] = []

        self.last_left_strike = -999.0
        self.last_right_strike = -999.0
        self.last_global_event = -999.0

    def _is_local_max(self, values: List[float], idx: int) -> bool:
        return values[idx] > values[idx - 1] and values[idx] > values[idx + 1]

    def _is_local_min(self, values: List[float], idx: int) -> bool:
        return values[idx] < values[idx - 1] and values[idx] < values[idx + 1]

    def _can_emit(self, current_ts: float, side: str) -> bool:
        if current_ts - self.last_global_event < self.min_global_interval_sec:
            return False
        if side == "left" and current_ts - self.last_left_strike < self.min_step_interval_sec:
            return False
        if side == "right" and current_ts - self.last_right_strike < self.min_step_interval_sec:
            return False
        return True

    def _register_heel_strike(self, side: str, ts: float) -> None:
        if not self._can_emit(ts, side):
            return

        self.last_global_event = ts
        if side == "left":
            self.left_heel_strikes.append(ts)
            self.last_left_strike = ts
        else:
            self.right_heel_strikes.append(ts)
            self.last_right_strike = ts

    def _register_toe_off(self, side: str, ts: float) -> None:
        if side == "left":
            if not self.left_toe_offs or ts - self.left_toe_offs[-1] >= self.min_step_interval_sec:
                self.left_toe_offs.append(ts)
        else:
            if not self.right_toe_offs or ts - self.right_toe_offs[-1] >= self.min_step_interval_sec:
                self.right_toe_offs.append(ts)

    def update(self, landmarks: Dict[str, float], timestamp: float) -> None:
        required = {"pelvis_mid_x", "left_heel_y", "right_heel_y", "left_toe_y", "right_toe_y"}
        if not required.issubset(landmarks.keys()):
            return

        self.history.append(
            {
                "timestamp": float(timestamp),
                "pelvis_mid_x": float(landmarks["pelvis_mid_x"]),
                "left_heel_y": float(landmarks["left_heel_y"]),
                "right_heel_y": float(landmarks["right_heel_y"]),
                "left_toe_y": float(landmarks["left_toe_y"]),
                "right_toe_y": float(landmarks["right_toe_y"]),
            }
        )

        if len(self.history) < 5:
            return

        hist = list(self.history)
        idx = len(hist) - 2  # candidate at middle-near-end so we have prev/next

        left_heel = [h["left_heel_y"] for h in hist]
        right_heel = [h["right_heel_y"] for h in hist]
        left_toe = [h["left_toe_y"] for h in hist]
        right_toe = [h["right_toe_y"] for h in hist]
        candidate_ts = hist[idx]["timestamp"]

        if self._is_local_max(left_heel, idx):
            self._register_heel_strike("left", candidate_ts)

        if self._is_local_max(right_heel, idx):
            self._register_heel_strike("right", candidate_ts)

        if self._is_local_min(left_toe, idx):
            self._register_toe_off("left", candidate_ts)

        if self._is_local_min(right_toe, idx):
            self._register_toe_off("right", candidate_ts)

    def get_metrics(self) -> GaitMetrics:
        if len(self.history) < 2:
            return GaitMetrics(confidence=0.0)

        hist = list(self.history)
        start_ts = hist[0]["timestamp"]
        end_ts = hist[-1]["timestamp"]
        duration = max(0.001, end_ts - start_ts)

        total_steps = len(self.left_heel_strikes) + len(self.right_heel_strikes)
        cadence_spm = (total_steps / duration) * 60.0 if total_steps > 0 else 0.0

        pelvis_start = hist[0]["pelvis_mid_x"]
        pelvis_end = hist[-1]["pelvis_mid_x"]
        forward_speed = abs(pelvis_end - pelvis_start) / duration

        left_count = len(self.left_heel_strikes)
        right_count = len(self.right_heel_strikes)
        max_count = max(1, max(left_count, right_count))
        count_diff_ratio = abs(left_count - right_count) / max_count
        timing_symmetry = max(0.0, 100.0 - (count_diff_ratio * 100.0))

        event_count = total_steps + len(self.left_toe_offs) + len(self.right_toe_offs)
        confidence = min(1.0, event_count / 12.0)

        return GaitMetrics(
            cadence_spm=round(cadence_spm, 3),
            forward_speed=round(forward_speed, 3),
            timing_symmetry=round(timing_symmetry, 3),
            heel_strikes_left=left_count,
            heel_strikes_right=right_count,
            toe_offs_left=len(self.left_toe_offs),
            toe_offs_right=len(self.right_toe_offs),
            confidence=round(confidence, 3),
        )