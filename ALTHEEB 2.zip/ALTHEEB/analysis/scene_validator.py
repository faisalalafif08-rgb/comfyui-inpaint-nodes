
class SceneValidationError(Exception):
    pass

class SceneValidator:
    def __init__(self, world_map: dict):
        self.map = world_map
        self.regions = {r["region_id"]: r for r in world_map.get("regions",[])}
        self.scenes = {s["scene_id"]: s for s in world_map.get("scene_bindings",[])}

    def validate_scene(self, scene_id: str):
        if scene_id not in self.scenes:
            raise SceneValidationError(f"Scene '{scene_id}' not found")

        scene = self.scenes[scene_id]
        region_id = scene["region_id"]

        if region_id not in self.regions:
            raise SceneValidationError(f"Region '{region_id}' not found")

        region = self.regions[region_id]
        env = scene["environment_context"]["primary"]

        if env not in region["environment"]:
            raise SceneValidationError(f"Environment '{env}' not allowed")

        return True
