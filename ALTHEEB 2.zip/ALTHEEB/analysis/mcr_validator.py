import jsonschema

class MCRValidationError(Exception):
    pass

class MCRValidator:
    def __init__(self, schema):
        self.schema = schema

    def validate(self, mcr):
        jsonschema.validate(instance=mcr, schema=self.schema)
        return True
