# brain/pattern_report.py
import json
import time

class PatternReport:
    def __init__(self, pattern_memory):
        self.pattern_memory = pattern_memory

    def export(self, path="pattern_memory_dump.json"):
        data = {
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_patterns": len(self.pattern_memory.patterns),
            "patterns": []
        }

        for sig, info in self.pattern_memory.patterns.items():
            data["patterns"].append({
                "signature": sig,
                "count": info.get("count"),
                "first_seen": info.get("first_seen"),
                "last_seen": info.get("last_seen"),
                "example": info.get("example")
            })

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        print(f"[REPORT] Pattern memory exported to {path}")
