import cv2
import numpy as np
from typing import Dict, List, Optional, Union


class FaceQualityScorer:
    """
    Baseline face quality scorer.
    Measures sharpness, brightness, contrast, size, center bias.
    """

    def _load_image(self, image_or_path: Union[str, np.ndarray]) -> Optional[np.ndarray]:
        if isinstance(image_or_path, str):
            return cv2.imread(image_or_path)
        if isinstance(image_or_path, np.ndarray):
            return image_or_path
        return None

    def score(
        self,
        image_or_path: Union[str, np.ndarray],
        bbox: Optional[List[int]] = None,
        frame_shape: Optional[tuple] = None,
    ) -> Dict[str, float]:
        image = self._load_image(image_or_path)
        if image is None or image.size == 0:
            return {
                "quality_score": 0.0,
                "sharpness": 0.0,
                "brightness": 0.0,
                "contrast": 0.0,
                "size_score": 0.0,
                "center_score": 0.0,
            }

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        sharpness = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        sharpness_norm = min(1.0, sharpness / 500.0)

        brightness = float(gray.mean() / 255.0)
        brightness_score = max(0.0, 1.0 - abs(brightness - 0.55) / 0.55)

        contrast = float(gray.std())
        contrast_norm = min(1.0, contrast / 64.0)

        size_score = 0.5
        center_score = 0.5

        if bbox is not None and frame_shape is not None:
            x1, y1, x2, y2 = bbox
            h, w = frame_shape[:2]

            face_w = max(1, x2 - x1)
            face_h = max(1, y2 - y1)
            area_ratio = (face_w * face_h) / max(1, (w * h))
            size_score = min(1.0, area_ratio * 10.0)

            center_x = (x1 + x2) / 2.0
            center_y = (y1 + y2) / 2.0
            dist_x = abs(center_x - (w / 2.0)) / max(1.0, w / 2.0)
            dist_y = abs(center_y - (h / 2.0)) / max(1.0, h / 2.0)
            center_score = max(0.0, 1.0 - ((dist_x + dist_y) / 2.0))

        quality = (
            (0.40 * sharpness_norm)
            + (0.20 * brightness_score)
            + (0.20 * contrast_norm)
            + (0.10 * size_score)
            + (0.10 * center_score)
        )
        quality = max(0.0, min(1.0, quality))

        return {
            "quality_score": round(float(quality), 4),
            "sharpness": round(float(sharpness_norm), 4),
            "brightness": round(float(brightness_score), 4),
            "contrast": round(float(contrast_norm), 4),
            "size_score": round(float(size_score), 4),
            "center_score": round(float(center_score), 4),
        }