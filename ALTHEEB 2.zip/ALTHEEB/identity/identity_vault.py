import json
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from core.models import FaceObservation, IdentityRecord
from identity.face_aligner import FaceAligner
from identity.face_embedder import FaceEmbedder
from identity.face_matcher import FaceMatcher


class IdentityVault:
    """
    Vault baseline: quality gate, align -> embed -> cosine match,
    best face policy, review zone.
    """

    def __init__(
        self,
        vault_path: str,
        min_quality: float = 0.35,
        match_threshold: float = 0.90,
        embedder: Optional[FaceEmbedder] = None,
        aligner: Optional[FaceAligner] = None,
        matcher: Optional[FaceMatcher] = None,
    ):
        self.vault_path = Path(vault_path)
        self.vault_path.parent.mkdir(parents=True, exist_ok=True)

        self.min_quality = float(min_quality)
        self.match_threshold = float(match_threshold)

        self.embedder = embedder or FaceEmbedder()
        self.aligner = aligner or FaceAligner()
        self.matcher = matcher or FaceMatcher(
            strong_match_threshold=self.match_threshold,
            review_match_threshold=max(0.0, self.match_threshold - 0.06),
            embedder=self.embedder,
            aligner=self.aligner,
        )

        self.people: List[Dict] = []
        self._load()

    def _load(self) -> None:
        if not self.vault_path.exists():
            self.people = []
            return

        try:
            with open(self.vault_path, "r", encoding="utf-8") as f:
                data = json.load(f) or {}
            self.people = data.get("people", [])
        except Exception:
            self.people = []

    def save(self) -> None:
        with open(self.vault_path, "w", encoding="utf-8") as f:
            json.dump({"people": self.people}, f, ensure_ascii=False, indent=2)

    def _next_person_id(self) -> str:
        return f"person_{len(self.people) + 1:04d}"

    def _gallery(self) -> Dict[str, np.ndarray]:
        out: Dict[str, np.ndarray] = {}
        for person in self.people:
            try:
                out[person["person_id"]] = np.asarray(person["descriptor"], dtype=np.float32)
            except Exception:
                continue
        return out

    def register_face(self, face: FaceObservation) -> IdentityRecord:
        if face.quality_score < self.min_quality:
            return IdentityRecord(
                event_id=f"id_evt_{face.face_obs_id}",
                video_id=face.video_id,
                face_obs_id=face.face_obs_id,
                person_id="rejected_quality",
                action="rejected",
                similarity=0.0,
                quality_score=face.quality_score,
                best_face_path=face.crop_path,
            )

        crop_path = Path(face.crop_path)
        aligned_path = str(crop_path.with_name(f"{crop_path.stem}_aligned{crop_path.suffix}"))

        pack = self.matcher.embedding_from_path(
            image_path=face.crop_path,
            aligned_output_path=aligned_path,
        )

        descriptor = pack["embedding"]
        best_face_path = pack.get("aligned_path") or face.crop_path

        if descriptor is None:
            return IdentityRecord(
                event_id=f"id_evt_{face.face_obs_id}",
                video_id=face.video_id,
                face_obs_id=face.face_obs_id,
                person_id="rejected_descriptor",
                action="rejected",
                similarity=0.0,
                quality_score=face.quality_score,
                best_face_path=best_face_path,
            )

        gallery = self._gallery()
        best_person_id, best_score = self.matcher.find_best_match(descriptor, gallery)
        decision = self.matcher.decide(best_score)

        if best_person_id is not None and decision["label"] == "matched":
            for person in self.people:
                if person["person_id"] != best_person_id:
                    continue

                if face.face_obs_id not in person["face_obs_ids"]:
                    person["face_obs_ids"].append(face.face_obs_id)

                if face.video_id not in person["videos"]:
                    person["videos"].append(face.video_id)

                if face.quality_score > float(person.get("best_quality", 0.0)):
                    person["best_quality"] = float(face.quality_score)
                    person["best_face_path"] = best_face_path
                    person["descriptor"] = descriptor.tolist()
                    person["align_method"] = pack.get("align_method", "unknown")
                    person["align_confidence"] = float(pack.get("align_confidence", 0.0))

                self.save()

                return IdentityRecord(
                    event_id=f"id_evt_{face.face_obs_id}",
                    video_id=face.video_id,
                    face_obs_id=face.face_obs_id,
                    person_id=best_person_id,
                    action="matched",
                    similarity=round(float(best_score), 4),
                    quality_score=face.quality_score,
                    best_face_path=person.get("best_face_path", ""),
                )

        person_id = self._next_person_id()
        create_action = "created_review_zone" if decision["label"] == "review" else "created"

        self.people.append(
            {
                "person_id": person_id,
                "descriptor": descriptor.tolist(),
                "best_quality": float(face.quality_score),
                "best_face_path": best_face_path,
                "face_obs_ids": [face.face_obs_id],
                "videos": [face.video_id],
                "align_method": pack.get("align_method", "unknown"),
                "align_confidence": float(pack.get("align_confidence", 0.0)),
            }
        )
        self.save()

        return IdentityRecord(
            event_id=f"id_evt_{face.face_obs_id}",
            video_id=face.video_id,
            face_obs_id=face.face_obs_id,
            person_id=person_id,
            action=create_action,
            similarity=round(float(max(best_score, 0.0)), 4),
            quality_score=face.quality_score,
            best_face_path=best_face_path,
        )

    def snapshot(self) -> Dict:
        return {"people": self.people}