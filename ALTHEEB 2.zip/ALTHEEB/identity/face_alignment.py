from __future__ import annotations
import os
from pathlib import Path
import cv2
from ..core.models import FaceObservation, FrameRecord
from ..core.logger import PipelineLogger

try:
    from insightface.app import FaceAnalysis
except Exception:
    FaceAnalysis = None

_FACE_APP = None
_HAAR = None


def _get_app():
    global _FACE_APP
    if _FACE_APP is None and FaceAnalysis is not None:
        _FACE_APP = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])
        _FACE_APP.prepare(ctx_id=-1, det_size=(640, 640))
    return _FACE_APP


def _get_haar():
    global _HAAR
    if _HAAR is None:
        path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        _HAAR = cv2.CascadeClassifier(path)
    return _HAAR


def detect_faces(image_path: str) -> list[dict]:
    img = cv2.imread(image_path)
    if img is None:
        return []
    app = _get_app()
    if app is not None:
        faces = app.get(img)
        out = []
        for face in faces:
            bbox = [int(v) for v in face.bbox.tolist()]
            landmarks = getattr(face, 'kps', None)
            out.append({'bbox': bbox, 'landmarks': landmarks.tolist() if landmarks is not None else None, 'confidence': float(getattr(face, 'det_score', 0.0))})
        return out
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    rects = _get_haar().detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
    return [{'bbox': [int(x), int(y), int(x+w), int(y+h)], 'landmarks': None, 'confidence': 0.5} for (x, y, w, h) in rects]


def align_face(image_path: str, bbox: list[int], landmarks, out_path: str) -> dict:
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(image_path)
    x1, y1, x2, y2 = bbox
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(img.shape[1], x2), min(img.shape[0], y2)
    face_crop = img[y1:y2, x1:x2]
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(out_path, face_crop)
    return {'crop_path': out_path, 'yaw': 0.0, 'pitch': 0.0, 'roll': 0.0}


def process_frame_faces(frame: FrameRecord, out_dir: str | Path, logger: PipelineLogger) -> list[FaceObservation]:
    faces_data = detect_faces(frame.image_path)
    face_obs_list: list[FaceObservation] = []
    for i, face in enumerate(faces_data):
        face_id = f'face_{frame.frame_id:06d}_{i:02d}'
        crop_path = Path(out_dir) / frame.video_id / 'faces' / f'{face_id}.jpg'
        aligned = align_face(frame.image_path, face['bbox'], face.get('landmarks'), str(crop_path))
        face_obs = FaceObservation(
            face_obs_id=face_id,
            video_id=frame.video_id,
            frame_id=frame.frame_id,
            timestamp=frame.timestamp,
            track_id=None,
            bbox=face['bbox'],
            crop_path=aligned['crop_path'],
            yaw=aligned['yaw'],
            pitch=aligned['pitch'],
            roll=aligned['roll'],
        )
        face_obs_list.append(face_obs)
    logger.info('face_alignment', f'تم اكتشاف {len(face_obs_list)} وجه في الفريم {frame.frame_id}', video_id=frame.video_id)
    return face_obs_list
