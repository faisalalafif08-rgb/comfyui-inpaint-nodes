from typing import Optional, Union

import cv2
import numpy as np


class FaceEmbedder:
    """
    Baseline embedder: DCT + histogram + L2 normalization.
    """

    def __init__(self):
        self.backend = "baseline_dct_hist"

    def _load_image(self, image_or_path: Union[str, np.ndarray]) -> Optional[np.ndarray]:
        if isinstance(image_or_path, str):
            return cv2.imread(image_or_path)
        if isinstance(image_or_path, np.ndarray):
            return image_or_path
        return None

    def _baseline_descriptor(self, image: np.ndarray) -> Optional[np.ndarray]:
        if image is None or image.size == 0:
            return None

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)

        thumb32 = cv2.resize(gray, (32, 32), interpolation=cv2.INTER_AREA)
        thumb16 = cv2.resize(gray, (16, 16), interpolation=cv2.INTER_AREA)

        thumb32_f = thumb32.astype(np.float32) / 255.0
        dct = cv2.dct(thumb32_f)[:8, :8].flatten()

        hist = cv2.calcHist([gray], [0], None, [32], [0, 256]).flatten().astype(np.float32)
        hist_sum = float(hist.sum())
        if hist_sum > 0:
            hist /= hist_sum

        tiny = thumb16.astype(np.float32).flatten() / 255.0

        desc = np.concatenate([dct.astype(np.float32), hist, tiny]).astype(np.float32)
        norm = float(np.linalg.norm(desc))
        if norm <= 1e-8:
            return None

        return desc / norm

    def embed(self, image_or_path: Union[str, np.ndarray]) -> Optional[np.ndarray]:
        image = self._load_image(image_or_path)
        return self._baseline_descriptor(image)

    def embed_path(self, image_path: str) -> Optional[np.ndarray]:
        return self.embed(image_path)

    def similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        if a is None or b is None:
            return 0.0
        return float(np.dot(a, b))