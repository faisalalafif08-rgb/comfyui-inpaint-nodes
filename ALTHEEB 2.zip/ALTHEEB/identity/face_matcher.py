from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np

from identity.face_aligner import FaceAligner
from identity.face_embedder import FaceEmbedder


class FaceMatcher:
    """
    Baseline matcher: align -> embed -> cosine similarity.
    Decision policy: strong_match / review / new.
    """

    def __init__(
        self,
        strong_match_threshold: float = 0.90,
        review_match_threshold: float = 0.84,
        embedder: Optional[FaceEmbedder] = None,
        aligner: Optional[FaceAligner] = None,
    ):
        self.strong_match_threshold = float(strong_match_threshold)
        self.review_match_threshold = float(review_match_threshold)
        self.embedder = embedder or FaceEmbedder()
        self.aligner = aligner or FaceAligner()

    def similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        if a is None or b is None:
            return 0.0
        return float(np.dot(a, b))

    def embedding_from_path(
        self,
        image_path: str,
        aligned_output_path: Optional[str] = None,
    ) -> Dict:
        align_result = self.aligner.align(image_path, save_path=aligned_output_path)

        if not align_result.get("ok"):
            return {
                "embedding": None,
                "aligned_path": None,
                "align_method": "failed",
                "align_confidence": 0.0,
            }

        aligned_image = align_result["aligned_image"]
        emb = self.embedder.embed(aligned_image)

        return {
            "embedding": emb,
            "aligned_path": align_result.get("aligned_path"),
            "align_method": align_result.get("method", "unknown"),
            "align_confidence": align_result.get("confidence", 0.0),
        }

    def find_best_match(
        self,
        query_embedding: np.ndarray,
        gallery: Dict[str, np.ndarray],
    ) -> Tuple[Optional[str], float]:
        if query_embedding is None or not gallery:
            return None, -1.0

        best_person_id = None
        best_score = -1.0

        for person_id, emb in gallery.items():
            score = self.similarity(query_embedding, emb)
            if score > best_score:
                best_score = score
                best_person_id = person_id

        return best_person_id, float(best_score)

    def decide(self, score: float) -> Dict[str, object]:
        if score >= self.strong_match_threshold:
            return {
                "label": "matched",
                "accept": True,
                "score": round(float(score), 4),
            }

        if score >= self.review_match_threshold:
            return {
                "label": "review",
                "accept": False,
                "score": round(float(score), 4),
            }

        return {
            "label": "new",
            "accept": False,
            "score": round(float(score), 4),
        }

    def compare_paths(self, path_a: str, path_b: str) -> Dict:
        pack_a = self.embedding_from_path(path_a)
        pack_b = self.embedding_from_path(path_b)

        emb_a = pack_a["embedding"]
        emb_b = pack_b["embedding"]
        score = self.similarity(emb_a, emb_b)
        decision = self.decide(score)

        return {
            "score": round(float(score), 4),
            "decision": decision["label"],
            "path_a_aligned": pack_a.get("aligned_path"),
            "path_b_aligned": pack_b.get("aligned_path"),
        }