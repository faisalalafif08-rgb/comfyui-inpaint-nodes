from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

import cv2
import numpy as np


class FaceAligner:
    """
    Baseline face aligner using eye detection.
    """

    def __init__(self, output_size: Tuple[int, int] = (112, 112)):
        self.output_size = tuple(output_size)

        eye_cascade_path = cv2.data.haarcascades + "haarcascade_eye.xml"
        self.eye_detector = cv2.CascadeClassifier(eye_cascade_path)
        if self.eye_detector.empty():
            raise RuntimeError("Failed to load eye cascade.")

    def _load_image(self, image_or_path: Union[str, np.ndarray]) -> Optional[np.ndarray]:
        if isinstance(image_or_path, str):
            return cv2.imread(image_or_path)
        if isinstance(image_or_path, np.ndarray):
            return image_or_path.copy()
        return None

    def _square_crop(self, image: np.ndarray) -> np.ndarray:
        h, w = image.shape[:2]
        side = min(h, w)
        cx = w // 2
        cy = h // 2
        x1 = max(0, cx - (side // 2))
        y1 = max(0, cy - (side // 2))
        x2 = min(w, x1 + side)
        y2 = min(h, y1 + side)
        crop = image[y1:y2, x1:x2]
        if crop.size == 0:
            return image
        return crop

    def _detect_eyes(self, gray: np.ndarray) -> list[Tuple[int, int, int, int]]:
        h, w = gray.shape[:2]
        roi = gray[: max(1, int(h * 0.65)), :]
        eyes = self.eye_detector.detectMultiScale(
            roi,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(8, 8),
        )

        out = []
        for (x, y, ew, eh) in eyes:
            out.append((int(x), int(y), int(ew), int(eh)))

        if not out:
            return []

        out = sorted(out, key=lambda e: e[2] * e[3], reverse=True)[:4]
        out = sorted(out, key=lambda e: e[0])
        return out

    def _pick_eye_pair(self, eyes: list[Tuple[int, int, int, int]]) -> Optional[Tuple[Tuple[float, float], Tuple[float, float]]]:
        if len(eyes) < 2:
            return None

        best_pair = None
        best_score = -1.0

        for i in range(len(eyes)):
            for j in range(i + 1, len(eyes)):
                e1 = eyes[i]
                e2 = eyes[j]

                c1 = (e1[0] + (e1[2] / 2.0), e1[1] + (e1[3] / 2.0))
                c2 = (e2[0] + (e2[2] / 2.0), e2[1] + (e2[3] / 2.0))

                dx = abs(c2[0] - c1[0])
                dy = abs(c2[1] - c1[1])

                score = dx - (dy * 0.75)
                if score > best_score:
                    best_score = score
                    best_pair = (c1, c2)

        return best_pair

    def _rotate(self, image: np.ndarray, angle_deg: float, center: Tuple[float, float]) -> np.ndarray:
        h, w = image.shape[:2]
        mat = cv2.getRotationMatrix2D(center, angle_deg, 1.0)
        rotated = cv2.warpAffine(
            image,
            mat,
            (w, h),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REPLICATE,
        )
        return rotated

    def align(
        self,
        image_or_path: Union[str, np.ndarray],
        save_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        image = self._load_image(image_or_path)
        if image is None or image.size == 0:
            return {
                "ok": False,
                "aligned_image": None,
                "aligned_path": None,
                "method": "failed",
                "confidence": 0.0,
            }

        method = "resize_only"
        confidence = 0.35
        work = image.copy()

        try:
            gray = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
            eyes = self._detect_eyes(gray)
            eye_pair = self._pick_eye_pair(eyes)

            if eye_pair is not None:
                left_eye, right_eye = eye_pair
                dy = right_eye[1] - left_eye[1]
                dx = right_eye[0] - left_eye[0]
                angle = np.degrees(np.arctan2(dy, dx))
                center = ((left_eye[0] + right_eye[0]) / 2.0, (left_eye[1] + right_eye[1]) / 2.0)

                work = self._rotate(work, angle, center)
                method = "eye_rotation"
                confidence = 0.75
        except Exception:
            method = "resize_only"
            confidence = 0.35

        work = self._square_crop(work)
        work = cv2.resize(work, self.output_size, interpolation=cv2.INTER_AREA)

        aligned_path = None
        if save_path:
            out_path = Path(save_path)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(out_path), work)
            aligned_path = str(out_path)

        return {
            "ok": True,
            "aligned_image": work,
            "aligned_path": aligned_path,
            "method": method,
            "confidence": round(float(confidence), 4),
        }