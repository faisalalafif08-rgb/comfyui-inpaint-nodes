#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fno_identity_studio_adapter.py

Adapter between the uploaded FNO Studio source tree and the clean
face_identity_generation_bridge.py identity/render bridge.

What it fixes / adds:
- avoids the broken `core.*` imports in uploaded run.py by working directly
  with the real files that exist in the zip
- reads storyboard JSON files used by the uploaded SD/SDXL tools
- renders storyboard scenes with one of: img2img / sdxl / ip_adapter
- optionally injects identity from:
    * a CharacterBank JSON built with face_identity_generation_bridge.py
    * a scene-local reference image
- writes a render manifest for later video assembly

This is practical single-machine glue code, not a claim of a full production system.
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

# Bridge file created earlier in this conversation.
# Kept as import to avoid duplicating the identity/render logic.
from ..generation.face_identity_generation_bridge import CharacterBank, GeneratorBridge, RenderConfig


# ------------------------------------------------------------------
# Data models
# ------------------------------------------------------------------

@dataclass
class SceneRenderResult:
    scene_id: str
    title: str
    prompt: str
    negative_prompt: str
    out_path: str
    reference_image: Optional[str]
    character_name: Optional[str]
    render_mode: str
    width: int
    height: int
    steps: int
    guidance_scale: float
    seed: Optional[int]


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def sanitize_filename(text: str) -> str:
    text = re.sub(r"[^\w\-\u0600-\u06FF]+", "_", text, flags=re.UNICODE)
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "scene"


def load_storyboard(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def build_prompt(scene: Dict[str, Any], extra_style: str = "") -> str:
    base = (
        scene.get("visual_prompt")
        or scene.get("prompt")
        or scene.get("title")
        or "cinematic portrait"
    )
    extra = scene.get("extra_style") or extra_style
    if extra:
        return f"{base}, {extra}".strip(", ")
    return base


def build_negative(scene: Dict[str, Any], default_negative: str) -> str:
    return scene.get("negative_prompt") or default_negative


def find_reference_image(
    scene: Dict[str, Any],
    scene_ref_root: Optional[Path] = None,
    bank: Optional[CharacterBank] = None,
) -> tuple[Optional[Path], Optional[str]]:
    """
    Priority:
    1) explicit scene['reference_image']
    2) explicit scene['character_ref']
    3) scene_ref_root / <character_name> / first image
    4) CharacterBank first reference image for `character` / `character_name`
    """
    for key in ("reference_image", "character_ref", "ref_image"):
        val = scene.get(key)
        if val:
            p = Path(val)
            if p.exists() and p.suffix.lower() in IMAGE_EXTS:
                return p, None

    character_name = scene.get("character") or scene.get("character_name") or scene.get("identity")
    if character_name and scene_ref_root:
        folder = scene_ref_root / str(character_name)
        if folder.exists() and folder.is_dir():
            imgs = sorted([p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS])
            if imgs:
                return imgs[0], str(character_name)

    if character_name and bank and character_name in bank.records:
        rec = bank.records[character_name]
        if rec.reference_images:
            p = Path(rec.reference_images[0])
            if p.exists():
                return p, str(character_name)

    return None, str(character_name) if character_name else None


# ------------------------------------------------------------------
# Main workflow
# ------------------------------------------------------------------

def render_storyboard(
    storyboard_path: Path,
    out_dir: Path,
    model_id: str,
    mode: str,
    extra_style: str = "",
    default_negative: str = "blurry, deformed, distorted, bad anatomy, watermark, text, logo",
    default_steps: int = 28,
    default_guidance: float = 6.5,
    width: int = 1024,
    height: int = 576,
    default_strength: float = 0.35,
    default_seed: Optional[int] = None,
    identity_strength: float = 0.60,
    bank_json: Optional[Path] = None,
    scene_ref_root: Optional[Path] = None,
    ip_adapter_repo: Optional[str] = None,
    ip_adapter_subfolder: Optional[str] = None,
    ip_adapter_weight: Optional[str] = None,
) -> Path:
    storyboard = load_storyboard(storyboard_path)
    scenes = storyboard.get("scenes", [])
    if not scenes:
        raise ValueError("Storyboard must contain a non-empty 'scenes' list")

    bank = CharacterBank.load(bank_json) if bank_json else None

    out_dir.mkdir(parents=True, exist_ok=True)
    manifest: List[SceneRenderResult] = []

    for idx, scene in enumerate(scenes, start=1):
        prompt = build_prompt(scene, extra_style=extra_style)
        negative = build_negative(scene, default_negative)
        steps = int(scene.get("steps", default_steps))
        guidance = float(scene.get("guidance", default_guidance))
        seed = scene.get("seed", default_seed)
        strength = float(scene.get("strength", default_strength))

        reference_image, character_name = find_reference_image(
            scene, scene_ref_root=scene_ref_root, bank=bank
        )

        cfg = RenderConfig(
            model_id=model_id,
            mode=mode,
            prompt=prompt,
            negative_prompt=negative,
            strength=strength,
            guidance_scale=guidance,
            steps=steps,
            width=width,
            height=height,
            seed=int(seed) if seed is not None else 42,
            identity_strength=identity_strength,
            device="cuda",
            ip_adapter_repo=ip_adapter_repo,
            ip_adapter_subfolder=ip_adapter_subfolder,
            ip_adapter_weight=ip_adapter_weight,
        )
        bridge = GeneratorBridge(cfg)

        title = str(scene.get("title") or f"scene_{idx:03d}")
        scene_id = str(scene.get("id") or idx)
        out_name = f"{idx:03d}_{sanitize_filename(scene_id)}_{sanitize_filename(title)}.png"
        out_path = out_dir / out_name

        bridge.render(
            out_path=out_path,
            reference_image=reference_image,
            prompt=prompt,
            negative_prompt=negative,
        )

        manifest.append(
            SceneRenderResult(
                scene_id=scene_id,
                title=title,
                prompt=prompt,
                negative_prompt=negative,
                out_path=str(out_path),
                reference_image=str(reference_image) if reference_image else None,
                character_name=character_name,
                render_mode=mode,
                width=width,
                height=height,
                steps=steps,
                guidance_scale=guidance,
                seed=int(seed) if seed is not None else None,
            )
        )

    manifest_path = out_dir / "render_manifest.json"
    payload = {
        "storyboard": str(storyboard_path),
        "mode": mode,
        "model_id": model_id,
        "count": len(manifest),
        "renders": [asdict(x) for x in manifest],
    }
    manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest_path


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Render FNO storyboard with identity-aware bridge")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("render-storyboard", help="render storyboard scenes")
    r.add_argument("storyboard", help="Path to storyboard JSON")
    r.add_argument("--out-dir", required=True, help="Output directory for rendered scenes")
    r.add_argument("--model-id", required=True, help="Diffusers model id")
    r.add_argument("--mode", choices=["img2img", "sdxl", "ip_adapter"], default="sdxl")
    r.add_argument("--extra-style", default="")
    r.add_argument("--default-negative", default="blurry, deformed, distorted, bad anatomy, watermark, text, logo")
    r.add_argument("--steps", type=int, default=28)
    r.add_argument("--guidance", type=float, default=6.5)
    r.add_argument("--width", type=int, default=1024)
    r.add_argument("--height", type=int, default=576)
    r.add_argument("--strength", type=float, default=0.35)
    r.add_argument("--seed", type=int, default=None)
    r.add_argument("--identity-strength", type=float, default=0.60)
    r.add_argument("--bank-json", default=None, help="Character bank JSON from face_identity_generation_bridge.py")
    r.add_argument("--scene-ref-root", default=None, help="Folder with subfolders per character containing reference images")
    r.add_argument("--ip-adapter-repo", default=None)
    r.add_argument("--ip-adapter-subfolder", default=None)
    r.add_argument("--ip-adapter-weight", default=None)
    return p


def main() -> None:
    parser = make_parser()
    args = parser.parse_args()

    if args.cmd == "render-storyboard":
        manifest_path = render_storyboard(
            storyboard_path=Path(args.storyboard),
            out_dir=Path(args.out_dir),
            model_id=args.model_id,
            mode=args.mode,
            extra_style=args.extra_style,
            default_negative=args.default_negative,
            default_steps=args.steps,
            default_guidance=args.guidance,
            width=args.width,
            height=args.height,
            default_strength=args.strength,
            default_seed=args.seed,
            identity_strength=args.identity_strength,
            bank_json=Path(args.bank_json) if args.bank_json else None,
            scene_ref_root=Path(args.scene_ref_root) if args.scene_ref_root else None,
            ip_adapter_repo=args.ip_adapter_repo,
            ip_adapter_subfolder=args.ip_adapter_subfolder,
            ip_adapter_weight=args.ip_adapter_weight,
        )
        print(f"[OK] Manifest saved to: {manifest_path}")
        return


if __name__ == "__main__":
    main()
