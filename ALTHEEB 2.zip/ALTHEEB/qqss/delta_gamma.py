from __future__ import annotations

from qqss.grid_mapper import GridMapper
from qqss.models import CellTrace, QQSSSignal, TargetContext


class DeltaGammaComputer:
    def __init__(self, grid: GridMapper):
        self.grid = grid

    def compute(self, prev_trace: CellTrace | None, curr_trace: CellTrace, target: TargetContext) -> QQSSSignal:
        curr_dist = float(self.grid.cell_distance(curr_trace.primary_cell, target.primary_cell))

        if prev_trace is None:
            prev_dist = curr_dist
            delta_steps = 0
        else:
            prev_dist = float(self.grid.cell_distance(prev_trace.primary_cell, target.primary_cell))
            delta_steps = self.grid.cell_distance(prev_trace.primary_cell, curr_trace.primary_cell)

        delta_target_distance = prev_dist - curr_dist
        entered_target = curr_trace.primary_cell == target.primary_cell and (
            prev_trace is None or prev_trace.primary_cell != target.primary_cell
        )
        entered_neighbors = curr_trace.primary_cell in target.neighbor_cells and (
            prev_trace is None or prev_trace.primary_cell not in target.neighbor_cells
        )

        if curr_trace.primary_cell == target.primary_cell:
            gamma_focus = 1.0
        elif curr_trace.primary_cell in target.neighbor_cells:
            gamma_focus = 0.7
        else:
            max_span = max(1.0, float(self.grid.spec.rows + self.grid.spec.cols))
            gamma_focus = max(0.1, 1.0 - (curr_dist / max_span))

        gamma_motion = min(1.0, delta_steps / 3.0)
        gamma_risk = min(1.0, (gamma_focus * 0.7) + (gamma_motion * 0.3))

        return QQSSSignal(
            delta_cell_steps=int(delta_steps),
            prev_target_distance=round(prev_dist, 4),
            curr_target_distance=round(curr_dist, 4),
            delta_target_distance=round(delta_target_distance, 4),
            entered_target=entered_target,
            entered_neighbors=entered_neighbors,
            gamma_focus=round(gamma_focus, 4),
            gamma_motion=round(gamma_motion, 4),
            gamma_risk=round(gamma_risk, 4),
        )