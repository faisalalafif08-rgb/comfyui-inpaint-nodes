from __future__ import annotations

from dataclasses import asdict
from typing import Dict, List, Optional

from qqss.cell_tracker import CellTracker
from qqss.grid_mapper import GridMapper
from qqss.spatial_reasoner import SpatialReasoner
from qqss.target_locator import TargetLocator


class QQSSEngine:
    def __init__(self, width: int, height: int, rows: int = 6, cols: int = 8):
        self.grid = GridMapper(width=width, height=height, rows=rows, cols=cols)
        self.target_locator = TargetLocator(self.grid)
        self.cell_tracker = CellTracker(self.grid)
        self.reasoner = SpatialReasoner(self.grid)
        self.target_context = None

    def set_target(self, target_id: str, bbox: List[int], radius: int = 1):
        self.target_context = self.target_locator.locate(target_id=target_id, bbox=bbox, radius=radius)
        return asdict(self.target_context)

    def analyze_track(self, track_id: str, bbox: List[int], frame_id: int, timestamp: float) -> Dict:
        if self.target_context is None:
            raise RuntimeError("QQSS target is not set")

        prev_trace = self.cell_tracker.get_last(track_id)
        curr_trace = self.cell_tracker.record(track_id=track_id, bbox=bbox, frame_id=frame_id, timestamp=timestamp)
        summary = self.reasoner.analyze(prev_trace=prev_trace, curr_trace=curr_trace, target=self.target_context)
        return asdict(summary)