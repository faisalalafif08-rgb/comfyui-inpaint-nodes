from __future__ import annotations

from typing import List, Tuple

from qqss.models import GridSpec


class GridMapper:
    def __init__(self, width: int, height: int, rows: int = 6, cols: int = 8):
        self.spec = GridSpec(width=width, height=height, rows=rows, cols=cols)

    def cell_id(self, row: int, col: int) -> str:
        return f"r{row:02d}_c{col:02d}"

    def parse_cell_id(self, cell_id: str) -> Tuple[int, int]:
        left, right = cell_id.split("_")
        return int(left[1:]), int(right[1:])

    def clamp_point(self, x: float, y: float) -> Tuple[float, float]:
        x = min(max(0.0, x), max(0.0, self.spec.width - 1))
        y = min(max(0.0, y), max(0.0, self.spec.height - 1))
        return x, y

    def point_to_cell(self, x: float, y: float) -> str:
        x, y = self.clamp_point(x, y)
        col = min(int(x / self.spec.cell_width), self.spec.cols - 1)
        row = min(int(y / self.spec.cell_height), self.spec.rows - 1)
        return self.cell_id(row, col)

    def cell_center(self, cell_id: str) -> Tuple[float, float]:
        row, col = self.parse_cell_id(cell_id)
        cx = (col + 0.5) * self.spec.cell_width
        cy = (row + 0.5) * self.spec.cell_height
        return cx, cy

    def bbox_primary_cell(self, bbox: List[int]) -> str:
        x1, y1, x2, y2 = bbox
        cx = (float(x1) + float(x2)) / 2.0
        cy = (float(y1) + float(y2)) / 2.0
        return self.point_to_cell(cx, cy)

    def bbox_to_cells(self, bbox: List[int]) -> List[str]:
        x1, y1, x2, y2 = bbox
        x1 = min(x1, x2)
        y1 = min(y1, y2)
        x2 = max(x1, x2)
        y2 = max(y1, y2)

        start_cell = self.point_to_cell(x1, y1)
        end_cell = self.point_to_cell(x2, y2)
        r1, c1 = self.parse_cell_id(start_cell)
        r2, c2 = self.parse_cell_id(end_cell)

        out = []
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                out.append(self.cell_id(r, c))
        return out

    def neighborhood(self, cell_id: str, radius: int = 1) -> List[str]:
        row, col = self.parse_cell_id(cell_id)
        out = []
        for r in range(max(0, row - radius), min(self.spec.rows - 1, row + radius) + 1):
            for c in range(max(0, col - radius), min(self.spec.cols - 1, col + radius) + 1):
                cid = self.cell_id(r, c)
                if cid != cell_id:
                    out.append(cid)
        return out

    def cell_distance(self, a: str, b: str) -> int:
        ar, ac = self.parse_cell_id(a)
        br, bc = self.parse_cell_id(b)
        return abs(ar - br) + abs(ac - bc)