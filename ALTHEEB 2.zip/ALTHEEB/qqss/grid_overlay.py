from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass
class OverlayStyle:
    line_color: Tuple[int, int, int] = (180, 180, 180)
    line_thickness: int = 1
    line_alpha: float = 0.22

    target_fill_color: Tuple[int, int, int] = (0, 215, 255)
    target_fill_alpha: float = 0.18
    target_border_color: Tuple[int, int, int] = (0, 255, 255)
    target_border_thickness: int = 2

    neighbor_fill_color: Tuple[int, int, int] = (255, 200, 0)
    neighbor_fill_alpha: float = 0.08

    label_color: Tuple[int, int, int] = (160, 160, 160)
    label_scale: float = 0.28
    label_thickness: int = 1

    event_border_thickness: int = 2
    event_text_scale: float = 0.38
    event_text_thickness: int = 1


def risk_to_color(risk_score: float) -> Tuple[int, int, int]:
    if risk_score >= 0.85:
        return (0, 0, 255)
    if risk_score >= 0.70:
        return (0, 80, 255)
    if risk_score >= 0.50:
        return (0, 180, 255)
    return (0, 255, 120)


def risk_to_alpha(risk_score: float) -> float:
    if risk_score >= 0.85:
        return 0.26
    if risk_score >= 0.70:
        return 0.20
    if risk_score >= 0.50:
        return 0.14
    return 0.10