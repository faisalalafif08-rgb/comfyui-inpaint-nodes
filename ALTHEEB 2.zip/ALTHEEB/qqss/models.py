from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class GridSpec:
    width: int
    height: int
    rows: int
    cols: int

    @property
    def cell_width(self) -> float:
        return self.width / max(1, self.cols)

    @property
    def cell_height(self) -> float:
        return self.height / max(1, self.rows)


@dataclass
class TargetContext:
    target_id: str
    bbox: List[int]
    primary_cell: str
    covered_cells: List[str]
    neighbor_cells: List[str]


@dataclass
class CellTrace:
    track_id: str
    frame_id: int
    timestamp: float
    bbox: List[int]
    primary_cell: str
    covered_cells: List[str]
    center_x: float
    center_y: float


@dataclass
class QQSSSignal:
    delta_cell_steps: int
    prev_target_distance: float
    curr_target_distance: float
    delta_target_distance: float
    entered_target: bool
    entered_neighbors: bool
    gamma_focus: float
    gamma_motion: float
    gamma_risk: float


@dataclass
class QQSSSummary:
    track_id: str
    frame_id: int
    timestamp: float
    relation: str
    pattern: str
    risk_score: float
    current_cell: str
    target_cell: str
    signal: Dict[str, float] = field(default_factory=dict)