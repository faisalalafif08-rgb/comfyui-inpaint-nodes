from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from qqss.grid_mapper import GridMapper
from qqss.grid_overlay import OverlayStyle, risk_to_alpha, risk_to_color


def _cell_box(grid: GridMapper, cell_id: str) -> Tuple[int, int, int, int]:
    row, col = grid.parse_cell_id(cell_id)
    x1 = int(round(col * grid.spec.cell_width))
    y1 = int(round(row * grid.spec.cell_height))
    x2 = int(round((col + 1) * grid.spec.cell_width)) - 1
    y2 = int(round((row + 1) * grid.spec.cell_height)) - 1
    x2 = max(x1, x2)
    y2 = max(y1, y2)
    return x1, y1, x2, y2


def _blend_rect(
    image: np.ndarray,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    color: Tuple[int, int, int],
    alpha: float,
) -> np.ndarray:
    out = image.copy()
    overlay = image.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
    cv2.addWeighted(overlay, alpha, out, 1.0 - alpha, 0.0, dst=out)
    return out


def _put_small_text(
    image: np.ndarray,
    text: str,
    x: int,
    y: int,
    color: Tuple[int, int, int],
    scale: float,
    thickness: int,
):
    cv2.putText(
        image,
        text,
        (x, y),
        cv2.FONT_HERSHEY_SIMPLEX,
        scale,
        color,
        thickness,
        cv2.LINE_AA,
    )


def render_grid_overlay(
    image: np.ndarray,
    grid: GridMapper,
    target_data: Optional[Dict] = None,
    qqss_events: Optional[List[Dict]] = None,
    frame_id: Optional[int] = None,
    style: Optional[OverlayStyle] = None,
    show_labels: bool = False,
) -> np.ndarray:
    style = style or OverlayStyle()
    out = image.copy()
    h, w = out.shape[:2]

    if target_data:
        for cell_id in target_data.get("neighbor_cells", []):
            x1, y1, x2, y2 = _cell_box(grid, cell_id)
            out = _blend_rect(out, x1, y1, x2, y2, style.neighbor_fill_color, style.neighbor_fill_alpha)

        for cell_id in target_data.get("covered_cells", []):
            x1, y1, x2, y2 = _cell_box(grid, cell_id)
            out = _blend_rect(out, x1, y1, x2, y2, style.target_fill_color, style.target_fill_alpha)

        primary = target_data.get("primary_cell")
        if primary:
            x1, y1, x2, y2 = _cell_box(grid, primary)
            cv2.rectangle(out, (x1, y1), (x2, y2), style.target_border_color, style.target_border_thickness)

    if qqss_events:
        active = qqss_events
        if frame_id is not None:
            active = [x for x in qqss_events if int(x.get("frame_id", -1)) == int(frame_id)]

        for item in active:
            cell_id = item.get("current_cell")
            if not cell_id:
                continue
            risk = float(item.get("risk_score", 0.0))
            color = risk_to_color(risk)
            alpha = risk_to_alpha(risk)
            x1, y1, x2, y2 = _cell_box(grid, cell_id)
            out = _blend_rect(out, x1, y1, x2, y2, color, alpha)
            cv2.rectangle(out, (x1, y1), (x2, y2), color, style.event_border_thickness)

            relation = str(item.get("relation", "unknown"))
            pattern = str(item.get("pattern", "unknown"))
            label = f"{relation} | {pattern} | {risk:.2f}"
            _put_small_text(
                out,
                label,
                x1 + 4,
                min(y2 - 6, y1 + 16),
                color,
                style.event_text_scale,
                style.event_text_thickness,
            )

    overlay = out.copy()
    for c in range(grid.spec.cols + 1):
        x = int(round(c * grid.spec.cell_width))
        x = min(max(0, x), max(0, w - 1))
        cv2.line(overlay, (x, 0), (x, h - 1), style.line_color, style.line_thickness, cv2.LINE_AA)

    for r in range(grid.spec.rows + 1):
        y = int(round(r * grid.spec.cell_height))
        y = min(max(0, y), max(0, h - 1))
        cv2.line(overlay, (0, y), (w - 1, y), style.line_color, style.line_thickness, cv2.LINE_AA)

    cv2.addWeighted(overlay, style.line_alpha, out, 1.0 - style.line_alpha, 0.0, dst=out)

    if show_labels:
        for r in range(grid.spec.rows):
            for c in range(grid.spec.cols):
                cid = grid.cell_id(r, c)
                x1, y1, _, _ = _cell_box(grid, cid)
                _put_small_text(
                    out,
                    cid,
                    x1 + 3,
                    y1 + 12,
                    style.label_color,
                    style.label_scale,
                    style.label_thickness,
                )

    return out