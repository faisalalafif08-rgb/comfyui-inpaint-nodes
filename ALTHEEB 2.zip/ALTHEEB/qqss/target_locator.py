from __future__ import annotations

from typing import List

from qqss.grid_mapper import GridMapper
from qqss.models import TargetContext


class TargetLocator:
    def __init__(self, grid: GridMapper):
        self.grid = grid

    def locate(self, target_id: str, bbox: List[int], radius: int = 1) -> TargetContext:
        primary = self.grid.bbox_primary_cell(bbox)
        covered = self.grid.bbox_to_cells(bbox)
        neighbors = self.grid.neighborhood(primary, radius=radius)
        return TargetContext(
            target_id=target_id,
            bbox=list(bbox),
            primary_cell=primary,
            covered_cells=covered,
            neighbor_cells=neighbors,
        )