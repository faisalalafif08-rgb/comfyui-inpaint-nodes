from __future__ import annotations

from typing import Dict, List, Optional

from qqss.grid_mapper import GridMapper
from qqss.models import CellTrace


class CellTracker:
    def __init__(self, grid: GridMapper):
        self.grid = grid
        self.last_trace_by_track: Dict[str, CellTrace] = {}

    def record(self, track_id: str, bbox: List[int], frame_id: int, timestamp: float) -> CellTrace:
        x1, y1, x2, y2 = bbox
        cx = (float(x1) + float(x2)) / 2.0
        cy = (float(y1) + float(y2)) / 2.0

        trace = CellTrace(
            track_id=track_id,
            frame_id=frame_id,
            timestamp=timestamp,
            bbox=list(bbox),
            primary_cell=self.grid.bbox_primary_cell(bbox),
            covered_cells=self.grid.bbox_to_cells(bbox),
            center_x=cx,
            center_y=cy,
        )
        self.last_trace_by_track[track_id] = trace
        return trace

    def get_last(self, track_id: str) -> Optional[CellTrace]:
        return self.last_trace_by_track.get(track_id)