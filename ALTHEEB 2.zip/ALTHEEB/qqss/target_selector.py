from __future__ import annotations

from typing import List, Optional

from core.models import TrackedObject


class QQSSTargetSelector:
    """
    Selects a real QQSS target from tracked objects.
    Preference order:
    1) person-like labels
    2) closer to frame center
    3) larger area
    4) higher confidence
    """

    PERSON_LABELS = {"person", "human", "pedestrian"}

    def select(
        self,
        video_id: str,
        tracked_objects: List[TrackedObject],
        frame_width: int,
        frame_height: int,
    ) -> Optional[TrackedObject]:
        if not tracked_objects:
            return None

        cx = frame_width / 2.0
        cy = frame_height / 2.0
        frame_diag = max(1.0, ((frame_width ** 2) + (frame_height ** 2)) ** 0.5)
        frame_area = max(1.0, float(frame_width * frame_height))

        best = None
        best_score = None

        for item in tracked_objects:
            x1, y1, x2, y2 = item.bbox
            bx = (float(x1) + float(x2)) / 2.0
            by = (float(y1) + float(y2)) / 2.0
            area = max(0.0, float(max(0, x2 - x1) * max(0, y2 - y1)))

            dist = (((bx - cx) ** 2) + ((by - cy) ** 2)) ** 0.5
            center_score = 1.0 - min(1.0, dist / frame_diag)
            area_score = min(1.0, area / frame_area)
            label_score = 1.0 if str(item.label).lower() in self.PERSON_LABELS else 0.2
            conf_score = max(0.0, min(1.0, float(item.confidence)))

            score = (
                label_score * 0.45 +
                center_score * 0.30 +
                area_score * 0.15 +
                conf_score * 0.10
            )

            if best is None or score > best_score:
                best = item
                best_score = score

        return best