from __future__ import annotations

from dataclasses import asdict

from qqss.delta_gamma import DeltaGammaComputer
from qqss.grid_mapper import GridMapper
from qqss.models import CellTrace, QQSSSummary, TargetContext


class SpatialReasoner:
    def __init__(self, grid: GridMapper):
        self.grid = grid
        self.delta_gamma = DeltaGammaComputer(grid)

    def analyze(self, prev_trace: CellTrace | None, curr_trace: CellTrace, target: TargetContext) -> QQSSSummary:
        signal = self.delta_gamma.compute(prev_trace, curr_trace, target)

        if curr_trace.primary_cell == target.primary_cell:
            relation = "on_target"
        elif curr_trace.primary_cell in target.neighbor_cells:
            relation = "near_target"
        else:
            relation = "far_target"

        if prev_trace is None:
            pattern = "appeared"
        elif signal.entered_target:
            pattern = "target_entry"
        elif relation == "on_target" and signal.delta_cell_steps == 0:
            pattern = "on_target_hold"
        elif signal.delta_target_distance > 0:
            pattern = "approaching"
        elif signal.delta_target_distance < 0:
            pattern = "retreating"
        elif signal.delta_cell_steps == 0:
            pattern = "stationary"
        else:
            pattern = "crossing"

        return QQSSSummary(
            track_id=curr_trace.track_id,
            frame_id=curr_trace.frame_id,
            timestamp=curr_trace.timestamp,
            relation=relation,
            pattern=pattern,
            risk_score=signal.gamma_risk,
            current_cell=curr_trace.primary_cell,
            target_cell=target.primary_cell,
            signal=asdict(signal),
        )