import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional
from analysis.pose_adapter import PoseAdapter
from scene.qqss_pipeline_fuser import QQSSPipelineFuser
import cv2

from core.logger import PipelineLogger
from core.paths import paths
from core.models import (
    BodyMetrics,
    FaceObservation,
    IdentityRecord,
    MotionObservation,
    ObjectObservation,
    PoseObservation,
    TrackedObject,
)
from perception.video_reader import inspect_video
from perception.frame_extractor import extract_frames
from perception.face_detector import FaceDetector
from perception.object_detector import ObjectDetector
from perception.object_tracker import ObjectTracker
from perception.motion_detector import MotionDetector
from identity.face_quality import FaceQualityScorer
from identity.face_embedder import FaceEmbedder
from identity.identity_vault import IdentityVault
from analysis.lower_body_analyzer import LowerBodyAnalyzer
from analysis.pose_adapter import PoseAdapter
from qqss.qqss_engine import QQSSEngine
from qqss.target_selector import QQSSTargetSelector
from scene.qqss_event_bridge import QQSSEventBridge
from scene.brain import AlTheebBrain
from scene.event_builder import EventBuilder
from scene.scene_builder import SceneBuilder
from scene.scene_validator import SceneValidator


class AnalyzePipeline:
    def __init__(self, video_path: str, logger: PipelineLogger):
        self.video_path = video_path
        self.logger = logger
        self.config = paths.config

        self.workspace_dir = paths.ensure_dir("workspace_dir", "data/workspace")
        self.indices_dir = paths.ensure_dir("indices_dir", "data/indices")
        self.reports_dir = paths.ensure_dir("reports_dir", "reports")
        self.logs_dir = paths.ensure_dir("logs_dir", "logs")

        gait_cfg = self.config.get("gait", {})
        brain_cfg = self.config.get("brain", {})
        face_cfg = self.config.get("face", {})
        video_cfg = self.config.get("video", {})
        object_cfg = self.config.get("object", {})
        motion_cfg = self.config.get("motion", {})
        identity_cfg = self.config.get("identity", {})
        tracker_cfg = self.config.get("tracker", {})
        scene_cfg = self.config.get("scene", {})
        scene_val_cfg = self.config.get("scene_validation", {})
        qqss_cfg = self.config.get("qqss", {})

        self.target_fps = float(video_cfg.get("target_fps", 5))
        self.face_enabled = bool(face_cfg.get("enabled", True))
        self.gait_enabled = bool(gait_cfg.get("enabled", True))
        self.object_enabled = bool(object_cfg.get("enabled", True))
        self.identity_enabled = bool(identity_cfg.get("enabled", True))

        self.qqss_enabled = bool(qqss_cfg.get("enabled", True))
        self.qqss_rows = int(qqss_cfg.get("rows", 6))
        self.qqss_cols = int(qqss_cfg.get("cols", 8))
        self.qqss_target_neighbor_radius = int(qqss_cfg.get("target_neighbor_radius", 1))
        self.qqss_min_risk_score = float(qqss_cfg.get("min_risk_score", 0.70))

        self.face_detector = FaceDetector(
            min_confidence=float(face_cfg.get("min_confidence", 0.5)),
            min_face_size=int(face_cfg.get("min_face_size", 40)),
        )

        self.object_detector = ObjectDetector(
            detect_people=bool(object_cfg.get("detect_people", True)),
            min_motion_area_ratio=float(object_cfg.get("min_motion_area_ratio", 0.005)),
            max_motion_objects=int(object_cfg.get("max_motion_objects", 8)),
        )

        self.motion_detector = MotionDetector(
            min_motion_area_ratio=float(
                motion_cfg.get("min_motion_area_ratio", object_cfg.get("min_motion_area_ratio", 0.005))
            ),
            max_regions=int(motion_cfg.get("max_regions", 8)),
            threshold_value=int(motion_cfg.get("threshold_value", 25)),
            dilate_iterations=int(motion_cfg.get("dilate_iterations", 2)),
        )

        self.object_tracker = ObjectTracker(
            max_distance_px=float(tracker_cfg.get("max_distance_px", 80.0)),
            max_missing_frames=int(tracker_cfg.get("max_missing_frames", 10)),
        )

        self.face_quality = FaceQualityScorer()
        self.face_embedder = FaceEmbedder()

        self.identity_vault = IdentityVault(
            vault_path=str(self.indices_dir / "identity_vault.json"),
            min_quality=float(identity_cfg.get("min_quality", 0.35)),
            match_threshold=float(identity_cfg.get("match_threshold", 0.90)),
            embedder=self.face_embedder,
        )

        self.gait = LowerBodyAnalyzer(
            fps=float(gait_cfg.get("fps_default", 30.0)),
            max_history=int(gait_cfg.get("history_length", 300)),
            min_step_interval_sec=float(gait_cfg.get("min_step_interval_sec", 0.35)),
            min_global_interval_sec=float(gait_cfg.get("min_global_interval_sec", 0.15)),
        )

        self.pose_adapter = PoseAdapter(
            logger=self.logger,
            backend="auto",
            task_model_path="models/mediapipe/pose_landmarker_full.task",
            ultralytics_model="",
        )
        self.qqss_fuser = QQSSPipelineFuser(
            min_attention_risk=getattr(self, "qqss_min_risk_score", 0.70),
            scene_gap_sec=0.80,
        )
        self.event_builder = EventBuilder(
            motion_event_threshold=float(scene_cfg.get("motion_event_threshold", 0.10)),
            event_gap_sec=float(scene_cfg.get("event_gap_sec", 1.0)),
        )

        self.scene_builder = SceneBuilder(
            scene_gap_sec=float(scene_cfg.get("scene_gap_sec", 2.0)),
            min_scene_duration_sec=float(scene_cfg.get("min_scene_duration_sec", 1.5)),
        )

        self.scene_validator = SceneValidator(
            min_scene_confidence=float(scene_val_cfg.get("min_scene_confidence", 0.30)),
            min_events_per_scene=int(scene_val_cfg.get("min_events_per_scene", 1)),
            min_scene_duration_sec=float(scene_val_cfg.get("min_scene_duration_sec", 1.50)),
            require_any_faces_or_objects=bool(scene_val_cfg.get("require_any_faces_or_objects", False)),
        )

    def _write_json(self, path: Path, data: Any):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def run(self) -> dict:
        video = inspect_video(self.video_path)
        self.logger.info("pipeline", "video inspected", video_id=video.video_id)

        frames = extract_frames(
            video=video,
            target_fps=self.target_fps,
            workspace_dir=str(self.workspace_dir),
            logger=self.logger,
        )

        qqss_engine: Optional[QQSSEngine] = None
        qqss_target = None
        qqss_target_track_id = ""
        qqss_events: List[Dict[str, Any]] = []

        if self.qqss_enabled:
            qqss_engine = QQSSEngine(
                width=int(video.width),
                height=int(video.height),
                rows=self.qqss_rows,
                cols=self.qqss_cols,
            )

        all_faces: List[FaceObservation] = []
        all_objects: List[ObjectObservation] = []
        all_tracks: List[TrackedObject] = []
        all_motion: List[MotionObservation] = []
        all_pose: List[PoseObservation] = []
        all_body_metrics: List[BodyMetrics] = []
        identity_events: List[IdentityRecord] = []
        decisions = []
        frame_rows: List[Dict[str, Any]] = []

        prev_gray = None
        prev_num_faces = 0
        prev_num_objects = 0

        for frame_rec in frames:
            image = cv2.imread(frame_rec.image_path)
            if image is None:
                self.logger.warning(
                    "pipeline",
                    "failed to load extracted frame",
                    image_path=frame_rec.image_path,
                )
                continue

            frame_motion, curr_gray, motion_score = self.motion_detector.process_frame_motion(
                frame=frame_rec,
                image=image,
                prev_gray=prev_gray,
                logger=self.logger,
            )
            all_motion.extend(frame_motion)

            frame_objects: List[ObjectObservation] = []
            tracked_objects: List[TrackedObject] = []

            if self.object_enabled:
                frame_objects, _ = self.object_detector.process_frame_objects(
                    frame=frame_rec,
                    image=image,
                    prev_gray=prev_gray,
                    logger=self.logger,
                )
                all_objects.extend(frame_objects)

                tracked_objects = self.object_tracker.update(frame_objects)
                all_tracks.extend(tracked_objects)

            if self.qqss_enabled and qqss_engine is not None and qqss_target is None and tracked_objects:
                selected_target = self.qqss_target_selector.select(
                    video_id=frame_rec.video_id,
                    tracked_objects=tracked_objects,
                    frame_width=image.shape[1],
                    frame_height=image.shape[0],
                )
                if selected_target is not None:
                    qqss_target_track_id = selected_target.track_id
                    qqss_target = qqss_engine.set_target(
                        target_id=selected_target.track_id,
                        bbox=selected_target.bbox,
                        radius=self.qqss_target_neighbor_radius,
                    )
                    self.logger.info(
                        "qqss",
                        "qqss target selected from tracks",
                        track_id=selected_target.track_id,
                        primary_cell=qqss_target.get("primary_cell", ""),
                        frame_id=frame_rec.frame_id,
                    )

            if self.qqss_enabled and qqss_engine is not None and qqss_target is not None:
                for track in tracked_objects:
                    if track.track_id == qqss_target_track_id:
                        continue
                    qqss_summary = qqss_engine.analyze_track(
                        track_id=track.track_id,
                        bbox=track.bbox,
                        frame_id=frame_rec.frame_id,
                        timestamp=frame_rec.timestamp,
                    )
                    qqss_events.append(qqss_summary)

            frame_faces: List[FaceObservation] = []
            if self.face_enabled:
                frame_faces = self.face_detector.process_frame_faces(
                    frame=frame_rec,
                    workspace_dir=str(self.workspace_dir),
                    logger=self.logger,
                )

                for obs in frame_faces:
                    q = self.face_quality.score(
                        image,
                        bbox=obs.bbox,
                        frame_shape=image.shape,
                    )
                    obs.quality_score = q["quality_score"]

                all_faces.extend(frame_faces)

                if self.identity_enabled:
                    for face_obs in frame_faces:
                        identity_event = self.identity_vault.register_face(face_obs)
                        identity_events.append(identity_event)

            pose_obs = None
            if self.gait_enabled:
            pose_obs = self.pose_adapter.extract(
                frame_bgr=frame_bgr,
                video_id=video.video_id,
                frame_id=frame_rec.frame_id,
                timestamp=frame_rec.timestamp,
            )
            if pose_obs is not None:
                all_pose.append(pose_obs)

            gait_landmarks = self.pose_adapter.to_gait_landmarks(pose_obs)
            if gait_landmarks is not None:
                self.gait.update(
                    frame_id=frame_rec.frame_id,
                    timestamp=frame_rec.timestamp,
                    landmarks=gait_landmarks,
                )

            body_metrics = self.pose_adapter.to_body_metrics(pose_obs)
            if body_metrics is not None:
                all_body_metrics.append(body_metrics)
                    gait_landmarks = self.pose_adapter.to_gait_landmarks(pose_obs)
                    if gait_landmarks is not None:
                        self.gait.update(gait_landmarks, frame_rec.timestamp)

            num_faces = len(frame_faces)
            num_objects = len(tracked_objects)
            face_jump = abs(num_faces - prev_num_faces)
            object_jump = abs(num_objects - prev_num_objects)

            decision = self.brain.perceive(
                {
                    "frame_id": frame_rec.frame_id,
                    "timestamp": frame_rec.timestamp,
                    "motion_score": motion_score,
                    "num_faces": num_faces,
                    "num_objects": num_objects,
                    "face_jump": float(face_jump),
                    "object_jump": float(object_jump),
                }
            )
            if decision is not None:
                decisions.append(decision)

            frame_rows.append(
                {
                    "frame_id": frame_rec.frame_id,
                    "timestamp": frame_rec.timestamp,
                    "motion_score": motion_score,
                    "motion_regions_count": len(frame_motion),
                    "num_faces": num_faces,
                    "num_objects": num_objects,
                    "pose_available": pose_obs is not None,
                    "face_jump": float(face_jump),
                    "object_jump": float(object_jump),
                    "decision_emitted": decision is not None,
                }
            )

            prev_gray = curr_gray
            prev_num_faces = num_faces
            prev_num_objects = num_objects

        best_faces = sorted(all_faces, key=lambda x: x.quality_score, reverse=True)[:5]
        gait_metrics = self.gait.get_metrics()
        vault_snapshot = self.identity_vault.snapshot()

        qqss_bridge_events = self.qqss_event_bridge.build(
            video_id=video.video_id,
            qqss_events=qqss_events,
        )

        base_events = self.event_builder.build(video.video_id, frame_rows)
        events = base_events + qqss_bridge_events
        scenes = self.scene_builder.build(video.video_id, events)
        scene_validations, scene_validation_summary = self.scene_validator.validate(
            [asdict(x) for x in scenes]
        )

        unique_track_ids = sorted({x.track_id for x in all_tracks})

        video_json = self.indices_dir / f"{video.video_id}_video.json"
        frames_json = self.indices_dir / f"{video.video_id}_frames.json"
        faces_json = self.indices_dir / f"{video.video_id}_faces.json"
        objects_json = self.indices_dir / f"{video.video_id}_objects.json"
        tracks_json = self.indices_dir / f"{video.video_id}_tracks.json"
        motion_json = self.indices_dir / f"{video.video_id}_motion.json"
        pose_json = self.indices_dir / f"{video.video_id}_pose.json"
        body_metrics_json = self.indices_dir / f"{video.video_id}_body_metrics.json"
        identity_json = self.indices_dir / f"{video.video_id}_identity.json"
        best_faces_json = self.indices_dir / f"{video.video_id}_best_faces.json"
        gait_json = self.indices_dir / f"{video.video_id}_gait.json"
        decisions_json = self.indices_dir / f"{video.video_id}_decisions.json"
        qqss_target_json = self.indices_dir / f"{video.video_id}_qqss_target.json"
        qqss_events_json = self.indices_dir / f"{video.video_id}_qqss_events.json"
        qqss_summary_json = self.indices_dir / f"{video.video_id}_qqss_summary.json"
        qqss_bridge_events_json = self.indices_dir / f"{video.video_id}_qqss_bridge_events.json"
        events_json = self.indices_dir / f"{video.video_id}_events.json"
        scenes_json = self.indices_dir / f"{video.video_id}_scenes.json"
        scene_validation_json = self.indices_dir / f"{video.video_id}_scene_validation.json"
        scene_validation_summary_json = self.indices_dir / f"{video.video_id}_scene_validation_summary.json"
        vault_json = self.indices_dir / f"{video.video_id}_vault_snapshot.json"
        report_json = self.indices_dir / f"{video.video_id}_report.json"

        self._write_json(video_json, asdict(video))
        self._write_json(frames_json, [asdict(x) for x in frames])
        self._write_json(faces_json, [asdict(x) for x in all_faces])
        self._write_json(objects_json, [asdict(x) for x in all_objects])
        self._write_json(tracks_json, [asdict(x) for x in all_tracks])
        self._write_json(motion_json, [asdict(x) for x in all_motion])
        self._write_json(pose_json, [asdict(x) for x in all_pose])
        self._write_json(body_metrics_json, [asdict(x) for x in all_body_metrics])
        self._write_json(identity_json, [asdict(x) for x in identity_events])
        self._write_json(best_faces_json, [asdict(x) for x in best_faces])
        self._write_json(gait_json, asdict(gait_metrics))
        self._write_json(decisions_json, [asdict(x) for x in decisions])
        self._write_json(qqss_target_json, qqss_target if qqss_target is not None else {})
        self._write_json(qqss_events_json, qqss_events)
        self._write_json(qqss_bridge_events_json, [asdict(x) for x in qqss_bridge_events])

        qqss_summary = {
            "enabled": self.qqss_enabled,
            "target": qqss_target,
            "target_track_id": qqss_target_track_id,
            "events_count": len(qqss_events),
            "tracks_seen": len({x["track_id"] for x in qqss_events}) if qqss_events else 0,
            "high_risk_count": len([x for x in qqss_events if float(x.get("risk_score", 0.0)) >= self.qqss_min_risk_score]),
            "on_target_count": len([x for x in qqss_events if x.get("relation") == "on_target"]),
            "near_target_count": len([x for x in qqss_events if x.get("relation") == "near_target"]),
            "bridge_events_count": len(qqss_bridge_events),
        }
        self._write_json(qqss_summary_json, qqss_summary)
        qqss_merge = self.qqss_fuser.fuse(
            video_id=video.video_id,
            qqss_summary=qqss_summary,
            qqss_bridge_events=qqss_bridge_events,
            events=events,
            scenes=scenes,
            decisions=decisions,
        )

        events = qqss_merge["events"]
        scenes = qqss_merge["scenes"]
        decisions = qqss_merge["decisions"]
        qqss_scenes = qqss_merge["qqss_scenes"]
        qqss_brain_decisions = qqss_merge["qqss_brain_decisions"]

        qqss_scenes_json = self.indices_dir / f"{video.video_id}_qqss_scenes.json"
        qqss_brain_decisions_json = self.indices_dir / f"{video.video_id}_qqss_brain_decisions.json"

        self._write_json(events_json, [asdict(x) for x in events])
        self._write_json(scenes_json, [asdict(x) for x in scenes])
        self._write_json(decisions_json, [asdict(x) for x in decisions])
        self._write_json(qqss_scenes_json, [asdict(x) for x in qqss_scenes])
        self._write_json(qqss_brain_decisions_json, [asdict(x) for x in qqss_brain_decisions])
        qqss_merge = self.qqss_fuser.fuse(
            video_id=video.video_id,
            qqss_summary=qqss_summary,
            qqss_bridge_events=qqss_bridge_events,
            events=events,
            scenes=scenes,
            decisions=decisions,
        )

        events = qqss_merge["events"]
        scenes = qqss_merge["scenes"]
        decisions = qqss_merge["decisions"]
        qqss_scenes = qqss_merge["qqss_scenes"]
        qqss_brain_decisions = qqss_merge["qqss_brain_decisions"]

        qqss_scenes_json = self.indices_dir / f"{video.video_id}_qqss_scenes.json"
        qqss_brain_decisions_json = self.indices_dir / f"{video.video_id}_qqss_brain_decisions.json"

        self._write_json(qqss_scenes_json, [asdict(x) for x in qqss_scenes])
        self._write_json(qqss_brain_decisions_json, [asdict(x) for x in qqss_brain_decisions])

        self._write_json(events_json, [asdict(x) for x in events])
        self._write_json(scenes_json, [asdict(x) for x in scenes])
        self._write_json(scene_validation_json, scene_validations)
        self._write_json(scene_validation_summary_json, scene_validation_summary)
        self._write_json(vault_json, vault_snapshot)

        report = {
            "video_id": video.video_id,
            "frames_count": len(frames),
            "faces_count": len(all_faces),
            "objects_count": len(all_objects),
            "tracks_count": len(unique_track_ids),
            "motion_count": len(all_motion),
            "pose_count": len(all_pose),
            "body_metrics_count": len(all_body_metrics),
            "identity_events_count": len(identity_events),
            "qqss_events_count": len(qqss_events),
            "qqss_high_risk_count": qqss_summary["high_risk_count"],
            "qqss_bridge_events_count": len(qqss_bridge_events),
            "qqss_scenes_count": len(qqss_scenes),
            "qqss_brain_decisions_count": len(qqss_brain_decisions),
            "events_count": len(events),
            "scenes_count": len(scenes),
            "scenes_valid_count": scene_validation_summary.get("scenes_valid", 0),
            "scenes_invalid_count": scene_validation_summary.get("scenes_invalid", 0),
            "best_face_available": bool(best_faces),
            "gait_available": gait_metrics.confidence > 0.0,
            "decisions_count": len(decisions),
            "outputs": {
                "video_json": str(video_json),
                "frames_json": str(frames_json),
                "faces_json": str(faces_json),
                "objects_json": str(objects_json),
                "tracks_json": str(tracks_json),
                "motion_json": str(motion_json),
                "pose_json": str(pose_json),
                "body_metrics_json": str(body_metrics_json),
                "identity_json": str(identity_json),
                "best_faces_json": str(best_faces_json),
                "gait_json": str(gait_json),
                "decisions_json": str(decisions_json),
                "qqss_target_json": str(qqss_target_json),
                "qqss_events_json": str(qqss_events_json),
                "qqss_summary_json": str(qqss_summary_json),
                "qqss_bridge_events_json": str(qqss_bridge_events_json),
                "qqss_scenes_json": str(qqss_scenes_json),
                "qqss_brain_decisions_json": str(qqss_brain_decisions_json),
                "events_json": str(events_json),
                "scenes_json": str(scenes_json),
                "scene_validation_json": str(scene_validation_json),
                "scene_validation_summary_json": str(scene_validation_summary_json),
                "vault_json": str(vault_json),
                "report_json": str(report_json),
            },
        }
        self._write_json(report_json, report)

        self.logger.info(
            "pipeline",
            "pipeline completed",
            video_id=video.video_id,
            frames_count=len(frames),
            faces_count=len(all_faces),
            objects_count=len(all_objects),
            tracks_count=len(unique_track_ids),
            motion_count=len(all_motion),
            pose_count=len(all_pose),
            body_metrics_count=len(all_body_metrics),
            identity_events_count=len(identity_events),
            qqss_events_count=len(qqss_events),
            qqss_bridge_events_count=len(qqss_bridge_events),
            qqss_scenes_count=len(qqss_scenes),
            qqss_brain_decisions_count=len(qqss_brain_decisions),
            events_count=len(events),
            scenes_count=len(scenes),
            scenes_valid=scene_validation_summary.get("scenes_valid", 0),
            scenes_invalid=scene_validation_summary.get("scenes_invalid", 0),
            decisions_count=len(decisions),
        )
        return report