from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


class KnowledgeEngine:
    def __init__(self, base_dir: str | None = None):
        root = Path(base_dir) if base_dir else Path(__file__).resolve().parent
        self.base_dir = root
        self.entity_defs = _load_json(root / "entity_defs.json")
        self.body_defs = _load_json(root / "body_defs.json")
        self.relation_defs = _load_json(root / "relation_defs.json")
        self.pattern_defs = _load_json(root / "pattern_defs.json")
        self.anomaly_defs = _load_json(root / "anomaly_defs.json")
        self.scene_priors = _load_json(root / "scene_priors.json")

    def analyze(
        self,
        report: Dict[str, Any],
        qqss_target: Dict[str, Any],
        qqss_events: List[Dict[str, Any]],
        qqss_summary: Dict[str, Any],
        qqss_scenes: List[Dict[str, Any]] | None = None,
    ) -> Dict[str, Any]:
        qqss_scenes = qqss_scenes or []

        relation_counter = Counter(str(x.get("relation", "unknown")) for x in qqss_events)
        pattern_counter = Counter(str(x.get("pattern", "unknown")) for x in qqss_events)
        track_ids = sorted({str(x.get("track_id", "")) for x in qqss_events if x.get("track_id")})

        entities_present = []
        if int(report.get("tracks_count", 0)) > 0:
            entities_present.append("person")
        if qqss_target:
            entities_present.append("target")

        anomalies: List[Dict[str, Any]] = []

        high_risk_count = int(qqss_summary.get("high_risk_count", 0))
        on_target_count = int(qqss_summary.get("on_target_count", 0))
        on_target_hold_count = int(pattern_counter.get("on_target_hold", 0))
        target_entry_count = int(pattern_counter.get("target_entry", 0))

        if high_risk_count >= int(self.anomaly_defs["repeated_high_risk_presence"]["min_count"]):
            anomalies.append(
                {
                    "anomaly_type": "repeated_high_risk_presence",
                    "severity": float(self.anomaly_defs["repeated_high_risk_presence"]["severity"]),
                    "count": high_risk_count
                }
            )

        if on_target_hold_count >= int(self.anomaly_defs["persistent_target_hold"]["min_count"]):
            anomalies.append(
                {
                    "anomaly_type": "persistent_target_hold",
                    "severity": float(self.anomaly_defs["persistent_target_hold"]["severity"]),
                    "count": on_target_hold_count
                }
            )

        if on_target_count > 0 or target_entry_count > 0:
            anomalies.append(
                {
                    "anomaly_type": "target_pressure",
                    "severity": float(self.anomaly_defs["target_pressure"]["severity"]),
                    "count": on_target_count + target_entry_count
                }
            )

        pressure_score = min(
            1.0,
            (0.08 * high_risk_count) +
            (0.06 * on_target_count) +
            (0.04 * int(qqss_summary.get("near_target_count", 0)))
        )

        dominant_relation = relation_counter.most_common(1)[0][0] if relation_counter else "unknown"
        dominant_pattern = pattern_counter.most_common(1)[0][0] if pattern_counter else "unknown"

        scene_prior = dict(self.scene_priors.get("surveillance_general", {}))
        zones = {
            "target_primary_cell": qqss_target.get("primary_cell", ""),
            "target_cells": list(qqss_target.get("covered_cells", [])),
            "neighbor_cells": list(qqss_target.get("neighbor_cells", []))
        }

        return {
            "knowledge_version": "v1",
            "entities_present": entities_present,
            "track_ids": track_ids,
            "dominant_relation": dominant_relation,
            "dominant_pattern": dominant_pattern,
            "relation_counts": dict(relation_counter),
            "pattern_counts": dict(pattern_counter),
            "anomalies": anomalies,
            "pressure_score": round(pressure_score, 4),
            "scene_prior": scene_prior,
            "zones": zones,
            "scene_count": len(qqss_scenes),
            "support_signals": {
                "tracks_count": int(report.get("tracks_count", 0)),
                "motion_count": int(report.get("motion_count", 0)),
                "qqss_events_count": int(report.get("qqss_events_count", 0)),
                "qqss_high_risk_count": high_risk_count,
                "qqss_on_target_count": on_target_count
            }
        }