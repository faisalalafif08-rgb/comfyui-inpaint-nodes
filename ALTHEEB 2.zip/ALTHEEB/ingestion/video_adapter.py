from __future__ import annotations
import json
import os
import subprocess
from pathlib import Path
import cv2
from ..core.models import VideoRecord
from ..core.logger import PipelineLogger


def build_video_id(source_path: str) -> str:
    base = os.path.basename(source_path)
    name, _ = os.path.splitext(base)
    safe = "".join(ch if ch.isalnum() or ch in ('_', '-') else '_' for ch in name)
    return f"vid_{safe}"


def detect_audio_stream(source_path: str) -> bool:
    try:
        proc = subprocess.run(
            [
                'ffprobe', '-v', 'error', '-select_streams', 'a',
                '-show_entries', 'stream=index', '-of', 'csv=p=0', source_path,
            ],
            capture_output=True, text=True, check=False,
        )
        return bool(proc.stdout.strip())
    except FileNotFoundError:
        return False


def inspect_video(source_path: str, logger: PipelineLogger) -> VideoRecord:
    if not os.path.exists(source_path):
        logger.error('video_adapter', f'الملف غير موجود: {source_path}')
        raise FileNotFoundError(source_path)

    cap = cv2.VideoCapture(source_path)
    if not cap.isOpened():
        logger.error('video_adapter', f'فشل فتح الفيديو: {source_path}')
        raise IOError(f'Cannot open video: {source_path}')

    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = frame_count / fps if fps > 0 else 0.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.release()

    has_audio = detect_audio_stream(source_path)
    video_id = build_video_id(source_path)
    video = VideoRecord(
        video_id=video_id,
        source_path=source_path,
        fps=fps,
        duration_sec=duration,
        width=width,
        height=height,
        has_audio=has_audio,
        audio_path=None,
    )
    logger.info('video_adapter', 'تم فحص الفيديو', video_id=video_id, duration=duration, fps=fps, has_audio=has_audio)
    return video


def save_video_index(video: VideoRecord, out_path: str | Path) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(video.__dict__, ensure_ascii=False, indent=2), encoding='utf-8')
