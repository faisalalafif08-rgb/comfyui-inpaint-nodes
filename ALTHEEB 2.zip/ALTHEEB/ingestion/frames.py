from __future__ import annotations
import json
from pathlib import Path
import cv2
from ..core.models import FrameRecord, VideoRecord
from ..core.logger import PipelineLogger


def extract_frames(video: VideoRecord, target_fps: float, workspace_dir: str | Path, logger: PipelineLogger) -> list[FrameRecord]:
    workspace_dir = Path(workspace_dir)
    frame_dir = workspace_dir / video.video_id / 'frames'
    frame_dir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(video.source_path)
    if not cap.isOpened():
        raise IOError(f'Cannot open video: {video.source_path}')

    source_fps = video.fps if video.fps > 0 else float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    if target_fps <= 0:
        target_fps = source_fps if source_fps > 0 else 1.0
    step = max(1, round(source_fps / target_fps)) if source_fps > 0 else 1

    frames: list[FrameRecord] = []
    idx = 0
    out_idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % step == 0:
            ts = idx / source_fps if source_fps > 0 else float(out_idx)
            out_path = frame_dir / f'frame_{out_idx:06d}.jpg'
            cv2.imwrite(str(out_path), frame)
            frames.append(FrameRecord(frame_id=out_idx, video_id=video.video_id, timestamp=ts, image_path=str(out_path)))
            out_idx += 1
        idx += 1
    cap.release()
    logger.info('frames', 'تم استخراج الفريمات', video_id=video.video_id, count=len(frames), target_fps=target_fps)
    return frames


def save_frames_index(frames: list[FrameRecord], out_path: str | Path) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        'video_id': frames[0].video_id if frames else None,
        'frames': [f.__dict__ for f in frames],
    }
    out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
