from __future__ import annotations
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional
from ..core.models import AudioChunkRecord
from ..core.logger import PipelineLogger


def _require_ffmpeg() -> None:
    if shutil.which('ffmpeg') is None:
        raise RuntimeError('ffmpeg is required but was not found in PATH')


def extract_audio_track(video_path: str, out_audio_path: str) -> str:
    _require_ffmpeg()
    out = Path(out_audio_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ['ffmpeg', '-y', '-i', video_path, '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', str(out)]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f'ffmpeg failed: {proc.stderr.strip()}')
    return str(out)


def split_audio_chunks(video_id: str, full_audio_path: Optional[str], chunk_seconds: float, out_dir: str | Path, logger: PipelineLogger) -> list[AudioChunkRecord]:
    if not full_audio_path or not os.path.exists(full_audio_path):
        logger.warning('audio_chunks', 'لا يوجد مسار صوت صالح، تم تخطي تقسيم الصوت', video_id=video_id)
        return []
    try:
        from pydub import AudioSegment
    except Exception as exc:
        raise RuntimeError('pydub is required to split audio chunks') from exc

    audio = AudioSegment.from_file(full_audio_path)
    duration_ms = len(audio)
    chunk_ms = max(1, int(chunk_seconds * 1000))
    chunks: list[AudioChunkRecord] = []
    base_dir = Path(out_dir) / video_id / 'audio_chunks'
    base_dir.mkdir(parents=True, exist_ok=True)

    for i, start_ms in enumerate(range(0, duration_ms, chunk_ms)):
        end_ms = min(start_ms + chunk_ms, duration_ms)
        chunk = audio[start_ms:end_ms]
        chunk_path = base_dir / f'chunk_{i:04d}.wav'
        chunk.export(chunk_path, format='wav')
        has_speech = chunk.dBFS > -40 if chunk.dBFS != float('-inf') else False
        chunks.append(AudioChunkRecord(
            chunk_id=f'chunk_{i:04d}',
            video_id=video_id,
            start_time=start_ms / 1000.0,
            end_time=end_ms / 1000.0,
            audio_path=str(chunk_path),
            has_speech=bool(has_speech),
        ))

    logger.info('audio_chunks', f'تم تقسيم الصوت إلى {len(chunks)} مقطع', video_id=video_id)
    return chunks


def save_audio_chunks_index(chunks: list[AudioChunkRecord], out_path: str | Path) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    data = {'video_id': chunks[0].video_id if chunks else None, 'chunks': [c.__dict__ for c in chunks]}
    out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
