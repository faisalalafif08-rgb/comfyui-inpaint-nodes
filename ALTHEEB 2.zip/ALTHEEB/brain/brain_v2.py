from __future__ import annotations

from typing import Any, Dict


class BrainV2:
    def __init__(self):
        pass

    def _phase(self, pressure_score: float, anomaly_count: int, high_risk_count: int) -> str:
        if anomaly_count >= 2 or pressure_score >= 0.85:
            return "alert"
        if high_risk_count > 0 or pressure_score >= 0.60:
            return "pressure"
        if pressure_score >= 0.35:
            return "watch"
        return "monitor"

    def _action(self, phase: str) -> str:
        if phase == "alert":
            return "ALERT"
        if phase == "pressure":
            return "INVESTIGATE"
        if phase == "watch":
            return "LOG"
        return "LOG"

    def _camera_hint(self, phase: str) -> Dict[str, Any]:
        if phase == "alert":
            return {
                "shot_type": "medium_close",
                "camera_angle": "eye_level_locked",
                "focus_mode": "target_pressure_focus",
                "lighting_hint": "high contrast surveillance emphasis"
            }
        if phase == "pressure":
            return {
                "shot_type": "medium",
                "camera_angle": "eye_level",
                "focus_mode": "target_subject_pair",
                "lighting_hint": "neutral with subject emphasis"
            }
        if phase == "watch":
            return {
                "shot_type": "medium_wide",
                "camera_angle": "eye_level",
                "focus_mode": "track_and_target",
                "lighting_hint": "neutral documentary lighting"
            }
        return {
            "shot_type": "wide",
            "camera_angle": "eye_level",
            "focus_mode": "scene_overview",
            "lighting_hint": "flat observation lighting"
        }

    def reason(
        self,
        report: Dict[str, Any],
        knowledge_context: Dict[str, Any],
        scene_graph: Dict[str, Any]
    ) -> Dict[str, Any]:
        pressure_score = float(knowledge_context.get("pressure_score", 0.0))
        anomalies = list(knowledge_context.get("anomalies", []))
        anomaly_count = len(anomalies)
        high_risk_count = int(report.get("qqss_high_risk_count", 0))
        phase = self._phase(pressure_score, anomaly_count, high_risk_count)
        action = self._action(phase)

        attention_level = min(
            1.0,
            0.20 +
            pressure_score +
            (0.08 * anomaly_count) +
            (0.03 * int(report.get("qqss_bridge_events_count", 0)))
        )

        reasoning = []
        reasoning.append(f"phase={phase}")
        reasoning.append(f"pressure_score={pressure_score:.2f}")
        reasoning.append(f"anomaly_count={anomaly_count}")
        reasoning.append(f"qqss_events_count={int(report.get('qqss_events_count', 0))}")

        return {
            "brain_version": "v2",
            "scene_phase": phase,
            "action": action,
            "attention_level": round(attention_level, 4),
            "tension_score": round(attention_level, 4),
            "reasoning": " | ".join(reasoning),
            "dominant_relation": knowledge_context.get("dominant_relation", "unknown"),
            "dominant_pattern": knowledge_context.get("dominant_pattern", "unknown"),
            "anomalies": anomalies,
            "camera_hint": self._camera_hint(phase),
            "graph_stats": {
                "nodes_count": len(scene_graph.get("nodes", [])),
                "edges_count": len(scene_graph.get("edges", []))
            }
        }