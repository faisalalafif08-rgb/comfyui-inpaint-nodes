from __future__ import annotations

from typing import Dict, List


class WorldPlausibility:
    def evaluate(self, report: Dict, qqss_summary: Dict, qqss_scenes: List[Dict]) -> Dict:
        score = 1.0
        reasons: List[str] = []

        frames_count = int(report.get("frames_count", 0))
        objects_count = int(report.get("objects_count", 0))
        tracks_count = int(report.get("tracks_count", 0))
        qqss_events_count = int(report.get("qqss_events_count", 0))
        high_risk_count = int(qqss_summary.get("high_risk_count", 0))
        bridge_events_count = int(qqss_summary.get("bridge_events_count", 0))

        if frames_count <= 0:
            score -= 0.50
            reasons.append("no_frames")

        if objects_count < 0 or tracks_count < 0:
            score -= 0.25
            reasons.append("negative_counts")

        if tracks_count > 0 and objects_count == 0:
            score -= 0.20
            reasons.append("tracks_without_objects")

        if qqss_events_count > 0 and tracks_count == 0:
            score -= 0.20
            reasons.append("qqss_without_tracks")

        if high_risk_count > qqss_events_count and qqss_events_count > 0:
            score -= 0.20
            reasons.append("invalid_risk_distribution")

        if qqss_scenes and bridge_events_count == 0:
            score -= 0.10
            reasons.append("scenes_without_bridge")

        score = max(0.0, min(1.0, round(score, 4)))

        if score >= 0.85:
            status = "stable"
        elif score >= 0.65:
            status = "acceptable"
        else:
            status = "fragile"

        return {
            "score": score,
            "status": status,
            "reasons": reasons
        }