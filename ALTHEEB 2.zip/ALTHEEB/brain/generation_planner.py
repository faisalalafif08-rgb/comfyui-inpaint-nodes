from __future__ import annotations

from typing import Dict, List


class GenerationPlanner:
    def build(
        self,
        report: Dict,
        knowledge_summary: Dict,
        brain_state: Dict
    ) -> Dict:
        video_id = str(report.get("video_id", ""))
        dominant_relation = str(knowledge_summary.get("dominant_relation", "unknown"))
        dominant_pattern = str(knowledge_summary.get("dominant_pattern", "unknown"))
        top_tags = knowledge_summary.get("top_tags", [])
        environment = knowledge_summary.get("environment", {})
        zone_type = str(environment.get("zone_type", "center_zone"))

        phase = str(brain_state.get("scene_phase", "observe"))
        shot_hint = str(brain_state.get("shot_hint", "wide_observation"))
        camera_hint = str(brain_state.get("camera_hint", "neutral_overview"))

        visual_focus = "target and dominant subject"
        if phase == "pressure":
            lighting_hint = "high contrast with target emphasis"
        elif phase == "approach":
            lighting_hint = "directional focus toward target path"
        else:
            lighting_hint = "balanced documentary lighting"

        prompt_lines: List[str] = [
            f"video_id={video_id}",
            f"scene_phase={phase}",
            f"dominant_relation={dominant_relation}",
            f"dominant_pattern={dominant_pattern}",
            f"zone_type={zone_type}",
            f"shot_hint={shot_hint}",
            f"camera_hint={camera_hint}",
            f"visual_focus={visual_focus}",
            f"lighting_hint={lighting_hint}",
        ]

        if top_tags:
            prompt_lines.append("tags=" + ", ".join(top_tags))

        return {
            "video_id": video_id,
            "mode": "scene_grounded_generation",
            "shot_plan": {
                "shot_type": shot_hint,
                "camera_behavior": camera_hint,
                "visual_focus": visual_focus,
                "lighting_hint": lighting_hint
            },
            "prompt_contract": {
                "scene_phase": phase,
                "dominant_relation": dominant_relation,
                "dominant_pattern": dominant_pattern,
                "zone_type": zone_type,
                "tags": top_tags
            },
            "prompt_text": " | ".join(prompt_lines)
        }