from __future__ import annotations

from typing import Dict


class CinematicReasoner:
    def reason(
        self,
        report: Dict,
        qqss_summary: Dict,
        knowledge_summary: Dict,
        plausibility: Dict
    ) -> Dict:
        high_risk_count = int(qqss_summary.get("high_risk_count", 0))
        on_target_count = int(qqss_summary.get("on_target_count", 0))
        near_target_count = int(qqss_summary.get("near_target_count", 0))
        dominant_pattern = str(knowledge_summary.get("dominant_pattern", "unknown"))
        dominant_relation = str(knowledge_summary.get("dominant_relation", "unknown"))

        if high_risk_count >= 3 or on_target_count >= 3:
            scene_phase = "pressure"
        elif near_target_count > 0 or dominant_pattern == "approaching":
            scene_phase = "approach"
        elif dominant_pattern == "stationary":
            scene_phase = "watch"
        else:
            scene_phase = "observe"

        if high_risk_count >= 5 or (on_target_count >= 3 and plausibility.get("score", 0.0) >= 0.70):
            action = "ALERT"
            attention = "high"
            severity = "high"
        elif high_risk_count > 0 or near_target_count > 0:
            action = "INVESTIGATE"
            attention = "medium"
            severity = "medium"
        else:
            action = "LOG"
            attention = "low"
            severity = "low"

        if scene_phase == "pressure":
            shot_hint = "medium_close_up"
            camera_hint = "target_isolation"
        elif scene_phase == "approach":
            shot_hint = "medium_tracking"
            camera_hint = "approach_follow"
        elif scene_phase == "watch":
            shot_hint = "static_wide"
            camera_hint = "balanced_frame"
        else:
            shot_hint = "wide_observation"
            camera_hint = "neutral_overview"

        reasoning = (
            f"phase={scene_phase} | relation={dominant_relation} | pattern={dominant_pattern} "
            f"| high_risk={high_risk_count} | on_target={on_target_count}"
        )

        return {
            "scene_phase": scene_phase,
            "attention_level": attention,
            "severity": severity,
            "action": action,
            "shot_hint": shot_hint,
            "camera_hint": camera_hint,
            "reasoning": reasoning
        }