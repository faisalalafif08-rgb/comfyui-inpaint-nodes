﻿import argparse

from core.logger import PipelineLogger
from core.paths import paths
from orchestration.pipeline import AnalyzePipeline


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True, help="Path to input video")
    args = parser.parse_args()

    logs_dir = paths.ensure_dir("logs_dir", "logs")
    logger = PipelineLogger(str(logs_dir / "pipeline.log"))

    pipe = AnalyzePipeline(video_path=args.video, logger=logger)
    report = pipe.run()

    print("\n=== ALTHEEB REPORT ===")
    for k, v in report.items():
        if k == "outputs":
            print("outputs:")
            for ok, ov in v.items():
                print(f"  {ok}: {ov}")
        else:
            print(f"{k}: {v}")


if __name__ == "__main__":
    main()