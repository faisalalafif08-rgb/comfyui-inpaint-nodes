import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from logging.handlers import RotatingFileHandler


class PipelineLogger:
    def __init__(self, log_path: str, level: str = "INFO"):
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

        logger_name = f"altheeb::{self.log_path.resolve()}"
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(getattr(logging, level.upper(), logging.INFO))
        self.logger.propagate = False

        if not self.logger.handlers:
            file_handler = RotatingFileHandler(
                self.log_path,
                maxBytes=10_485_760,
                backupCount=5,
                encoding="utf-8",
            )
            file_handler.setFormatter(logging.Formatter("%(message)s"))
            self.logger.addHandler(file_handler)

            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(
                logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
            )
            self.logger.addHandler(console_handler)

    def _emit(self, level: str, stage: str, message: str, **meta):
        record = {
            "ts": datetime.utcnow().isoformat() + "Z",
            "level": level.upper(),
            "stage": stage,
            "message": message,
            "meta": meta,
        }
        self.logger.log(
            getattr(logging, level.upper(), logging.INFO),
            json.dumps(record, ensure_ascii=False),
        )

    def info(self, stage: str, message: str, **meta):
        self._emit("INFO", stage, message, **meta)

    def warning(self, stage: str, message: str, **meta):
        self._emit("WARNING", stage, message, **meta)

    def error(self, stage: str, message: str, **meta):
        self._emit("ERROR", stage, message, **meta)