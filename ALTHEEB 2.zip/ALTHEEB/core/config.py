from __future__ import annotations

import os
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


DEFAULT_CONFIG: Dict[str, Any] = {
    "system": {
        "name": "ALTHEEB",
        "version": "0.1.0",
        "debug": False,
    },
    "paths": {
        "input_videos_dir": "data/input/videos",
        "workspace_dir": "data/workspace",
        "indices_dir": "data/indices",
        "reports_dir": "reports",
        "logs_dir": "logs",
    },
    "video": {
        "target_fps": 5.0,
        "save_frames": True,
        "image_format": "jpg",
    },
    "face": {
        "enabled": True,
        "min_confidence": 0.50,
        "min_face_size": 40,
    },
    "object": {
        "enabled": True,
        "detect_people": True,
        "min_motion_area_ratio": 0.005,
        "max_motion_objects": 8,
    },
    "identity": {
        "enabled": True,
        "min_quality": 0.35,
        "match_threshold": 0.90,
    },
    "tracker": {
        "max_distance_px": 80,
        "max_missing_frames": 10,
    },
    "gait": {
        "enabled": True,
        "fps_default": 30.0,
        "history_length": 300,
        "min_step_interval_sec": 0.35,
        "min_global_interval_sec": 0.15,
    },
    "brain": {
        "qqss_window": 30,
        "qqss_threshold": 0.18,
        "cooldown_sec": 1.5,
    },
    "scene": {
        "enabled": True,
        "motion_event_threshold": 0.10,
        "event_gap_sec": 1.0,
        "scene_gap_sec": 2.0,
        "min_scene_duration_sec": 1.5,
    },
    "scene_validation": {
        "enabled": True,
        "min_scene_confidence": 0.30,
        "min_events_per_scene": 1,
        "min_scene_duration_sec": 1.5,
        "require_any_faces_or_objects": False,
    },
    "memory": {
        "enabled": True,
        "recent_frames_limit": 300,
        "recent_events_limit": 200,
        "recent_decisions_limit": 100,
    },
    "reports": {
        "enabled": True,
        "export_markdown": True,
        "export_html": True,
        "top_faces_limit": 5,
        "top_scenes_limit": 10,
    },
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, dict)
        ):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


class ConfigManager:
    def __init__(self, project_root: Optional[Path] = None, config_path: Optional[Path] = None):
        self.project_root = Path(project_root).resolve() if project_root else Path(__file__).resolve().parents[1]
        self.config_path = self._resolve_config_path(config_path)
        self._config: Dict[str, Any] = {}
        self.reload()

    def _resolve_config_path(self, config_path: Optional[Path]) -> Path:
        if config_path is not None:
            return Path(config_path).resolve()
        return (self.project_root / "config" / "system.yaml").resolve()

    def _load_yaml_file(self, path: Path) -> Dict[str, Any]:
        if not path.exists():
            return {}
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        if not isinstance(data, dict):
            raise ValueError(f"Config file must contain a mapping at root: {path}")
        return data

    def reload(self) -> Dict[str, Any]:
        file_data = self._load_yaml_file(self.config_path)
        self._config = _deep_merge(DEFAULT_CONFIG, file_data)
        return self._config

    @property
    def data(self) -> Dict[str, Any]:
        return self._config

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def section(self, key: str) -> Dict[str, Any]:
        value = self._config.get(key, {})
        return value if isinstance(value, dict) else {}

    def as_dict(self) -> Dict[str, Any]:
        return deepcopy(self._config)

    def save(self, path: Optional[Path] = None) -> Path:
        target = Path(path).resolve() if path else self.config_path
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", encoding="utf-8") as f:
            yaml.safe_dump(self._config, f, allow_unicode=True, sort_keys=False)
        return target