from pathlib import Path

import yaml


class AlTheebPaths:
    def __init__(self, config_path: str = "config/system.yaml"):
        self.root = Path(__file__).resolve().parents[1]
        self.config_path = self.root / config_path
        self.config = self._load_config()

    def _load_config(self) -> dict:
        if self.config_path.exists():
            with open(self.config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        return {}

    def get(self, key: str, default: str = "") -> Path:
        rel = self.config.get("paths", {}).get(key, default)
        return (self.root / rel).resolve()

    def ensure_dir(self, key: str, default: str = "") -> Path:
        p = self.get(key, default)
        p.mkdir(parents=True, exist_ok=True)
        return p


paths = AlTheebPaths()