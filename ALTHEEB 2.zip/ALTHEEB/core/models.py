from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class VideoRecord:
    video_id: str
    source_path: str
    fps: float
    duration_sec: float
    width: int
    height: int
    has_audio: bool


@dataclass
class FrameRecord:
    frame_id: int
    video_id: str
    timestamp: float
    image_path: str


@dataclass
class FaceObservation:
    face_obs_id: str
    video_id: str
    frame_id: int
    timestamp: float
    bbox: List[int]
    crop_path: str
    confidence: float
    quality_score: float = 0.0


@dataclass
class ObjectObservation:
    object_obs_id: str
    video_id: str
    frame_id: int
    timestamp: float
    label: str
    bbox: List[int]
    confidence: float
    source: str = "unknown"


@dataclass
class TrackedObject:
    track_id: str
    video_id: str
    frame_id: int
    timestamp: float
    label: str
    bbox: List[int]
    confidence: float
    source: str = "tracker"


@dataclass
class MotionObservation:
    motion_obs_id: str
    video_id: str
    frame_id: int
    timestamp: float
    bbox: List[int]
    area_ratio: float
    mean_diff: float
    confidence: float
    source: str = "frame_diff"


@dataclass
class PoseObservation:
    pose_obs_id: str
    video_id: str
    frame_id: int
    timestamp: float
    backend: str
    landmarks: Dict[str, float] = field(default_factory=dict)
    confidence: float = 0.0
    available: bool = False


@dataclass
class BodyMetrics:
    body_obs_id: str
    video_id: str
    frame_id: int
    timestamp: float
    hip_span_px: float = 0.0
    heel_span_px: float = 0.0
    toe_span_px: float = 0.0
    pelvis_mid_x: float = 0.0
    lower_body_visible: bool = False
    confidence: float = 0.0


@dataclass
class IdentityRecord:
    event_id: str
    video_id: str
    face_obs_id: str
    person_id: str
    action: str
    similarity: float
    quality_score: float
    best_face_path: str = ""


@dataclass
class FaceEmbeddingRecord:
    face_obs_id: str
    video_id: str
    vector_dim: int
    backend: str
    quality_score: float


@dataclass
class GaitMetrics:
    cadence_spm: float = 0.0
    forward_speed: float = 0.0
    timing_symmetry: float = 100.0
    heel_strikes_left: int = 0
    heel_strikes_right: int = 0
    toe_offs_left: int = 0
    toe_offs_right: int = 0
    confidence: float = 0.0


@dataclass
class BrainDecision:
    decision_id: str
    timestamp: float
    event_type: str
    confidence: float
    reasoning: str
    payload: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EventRecord:
    event_id: str
    video_id: str
    start_time: float
    end_time: float
    frame_start_id: int
    frame_end_id: int
    event_type: str
    faces_count: int = 0
    objects_count: int = 0
    max_motion_score: float = 0.0
    confidence: float = 0.0
    notes: str = ""


@dataclass
class SceneRecord:
    scene_id: str
    video_id: str
    start_time: float
    end_time: float
    event_ids: List[str] = field(default_factory=list)
    faces_count: int = 0
    objects_count: int = 0
    summary: str = ""
    confidence: float = 0.0