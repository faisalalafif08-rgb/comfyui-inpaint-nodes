from pathlib import Path
from typing import List

import cv2

from core.models import FrameRecord, FaceObservation
from core.logger import PipelineLogger


class FaceDetector:
    def __init__(self, min_confidence: float = 0.5, min_face_size: int = 40):
        self.min_confidence = float(min_confidence)
        self.min_face_size = int(min_face_size)

        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self.detector = cv2.CascadeClassifier(cascade_path)
        if self.detector.empty():
            raise RuntimeError("Failed to load face cascade.")

    def process_frame_faces(
        self,
        frame: FrameRecord,
        workspace_dir: str,
        logger: PipelineLogger,
    ) -> List[FaceObservation]:
        image = cv2.imread(frame.image_path)
        if image is None:
            return []

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        rects = self.detector.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(self.min_face_size, self.min_face_size),
        )

        faces_dir = Path(workspace_dir) / frame.video_id / "faces"
        faces_dir.mkdir(parents=True, exist_ok=True)

        out: List[FaceObservation] = []

        for idx, (x, y, w, h) in enumerate(rects):
            x1, y1, x2, y2 = int(x), int(y), int(x + w), int(y + h)
            crop = image[y1:y2, x1:x2]
            if crop.size == 0:
                continue

            crop_path = faces_dir / f"face_{frame.frame_id:06d}_{idx:02d}.jpg"
            ok = cv2.imwrite(str(crop_path), crop)
            if not ok:
                continue

            obs = FaceObservation(
                face_obs_id=f"{frame.video_id}_face_{frame.frame_id:06d}_{idx:02d}",
                video_id=frame.video_id,
                frame_id=frame.frame_id,
                timestamp=frame.timestamp,
                bbox=[x1, y1, x2, y2],
                crop_path=str(crop_path),
                confidence=1.0,
                quality_score=0.0,
            )
            out.append(obs)

        logger.info(
            "face_detector",
            "frame face detection completed",
            frame_id=frame.frame_id,
            faces_count=len(out),
        )
        return out