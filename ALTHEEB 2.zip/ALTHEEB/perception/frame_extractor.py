from pathlib import Path
from typing import List

import cv2

from core.models import VideoRecord, FrameRecord
from core.logger import PipelineLogger


def extract_frames(
    video: VideoRecord,
    target_fps: float,
    workspace_dir: str,
    logger: PipelineLogger,
) -> List[FrameRecord]:
    workspace_root = Path(workspace_dir)
    frames_dir = workspace_root / video.video_id / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(video.source_path)
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open video: {video.source_path}")

    source_fps = video.fps if video.fps > 0 else 30.0
    if target_fps <= 0:
        target_fps = source_fps

    frame_step = max(1, round(source_fps / target_fps))
    frame_records: List[FrameRecord] = []

    read_index = 0
    saved_index = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if read_index % frame_step == 0:
            timestamp = read_index / source_fps
            image_path = frames_dir / f"frame_{saved_index:06d}.jpg"
            ok = cv2.imwrite(str(image_path), frame)
            if not ok:
                read_index += 1
                continue

            frame_records.append(
                FrameRecord(
                    frame_id=saved_index,
                    video_id=video.video_id,
                    timestamp=float(timestamp),
                    image_path=str(image_path),
                )
            )
            saved_index += 1

        read_index += 1

    cap.release()

    logger.info(
        "frame_extractor",
        "frame extraction completed",
        video_id=video.video_id,
        extracted_frames=len(frame_records),
        source_fps=source_fps,
        target_fps=target_fps,
    )

    return frame_records