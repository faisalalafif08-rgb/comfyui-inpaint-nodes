from typing import List, Optional, Tuple

import cv2
import numpy as np

from core.models import FrameRecord, ObjectObservation
from core.logger import PipelineLogger


class ObjectDetector:
    """
    Baseline object detector:
    - HOG person detector
    - motion regions from frame differencing
    """

    def __init__(
        self,
        detect_people: bool = True,
        min_motion_area_ratio: float = 0.005,
        max_motion_objects: int = 8,
    ):
        self.detect_people = detect_people
        self.min_motion_area_ratio = float(min_motion_area_ratio)
        self.max_motion_objects = int(max_motion_objects)

        self.hog = None
        if self.detect_people:
            self.hog = cv2.HOGDescriptor()
            self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

    def _iou(self, a: List[int], b: List[int]) -> float:
        ax1, ay1, ax2, ay2 = a
        bx1, by1, bx2, by2 = b

        inter_x1 = max(ax1, bx1)
        inter_y1 = max(ay1, by1)
        inter_x2 = min(ax2, bx2)
        inter_y2 = min(ay2, by2)

        inter_w = max(0, inter_x2 - inter_x1)
        inter_h = max(0, inter_y2 - inter_y1)
        inter_area = inter_w * inter_h

        area_a = max(1, (ax2 - ax1) * (ay2 - ay1))
        area_b = max(1, (bx2 - bx1) * (by2 - by1))
        union = area_a + area_b - inter_area
        return inter_area / max(1, union)

    def process_frame_objects(
        self,
        frame: FrameRecord,
        image: np.ndarray,
        prev_gray: Optional[np.ndarray],
        logger: PipelineLogger,
    ) -> Tuple[List[ObjectObservation], np.ndarray]:
        observations: List[ObjectObservation] = []
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        h, w = image.shape[:2]
        person_boxes: List[List[int]] = []

        if self.hog is not None:
            rects, weights = self.hog.detectMultiScale(
                image,
                winStride=(8, 8),
                padding=(8, 8),
                scale=1.05,
            )
            weights = weights.flatten().tolist() if len(weights) else []

            for idx, (x, y, rw, rh) in enumerate(rects):
                x1, y1, x2, y2 = int(x), int(y), int(x + rw), int(y + rh)
                bbox = [x1, y1, x2, y2]
                person_boxes.append(bbox)

                conf = float(weights[idx]) if idx < len(weights) else 1.0
                conf = max(0.0, min(1.0, conf / 2.0))

                observations.append(
                    ObjectObservation(
                        object_obs_id=f"{frame.video_id}_obj_person_{frame.frame_id:06d}_{idx:02d}",
                        video_id=frame.video_id,
                        frame_id=frame.frame_id,
                        timestamp=frame.timestamp,
                        label="person",
                        bbox=bbox,
                        confidence=round(conf, 4),
                        source="hog",
                    )
                )

        if prev_gray is not None:
            blur_prev = cv2.GaussianBlur(prev_gray, (5, 5), 0)
            blur_curr = cv2.GaussianBlur(gray, (5, 5), 0)

            diff = cv2.absdiff(blur_prev, blur_curr)
            _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
            thresh = cv2.dilate(thresh, None, iterations=2)

            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            min_area = int((w * h) * self.min_motion_area_ratio)
            motion_idx = 0

            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < min_area:
                    continue

                x, y, rw, rh = cv2.boundingRect(cnt)
                bbox = [int(x), int(y), int(x + rw), int(y + rh)]

                overlaps_person = any(self._iou(bbox, pb) > 0.35 for pb in person_boxes)
                if overlaps_person:
                    continue

                conf = max(0.0, min(1.0, float(area / max(1, (w * h) * 0.10))))

                observations.append(
                    ObjectObservation(
                        object_obs_id=f"{frame.video_id}_obj_motion_{frame.frame_id:06d}_{motion_idx:02d}",
                        video_id=frame.video_id,
                        frame_id=frame.frame_id,
                        timestamp=frame.timestamp,
                        label="motion_object",
                        bbox=bbox,
                        confidence=round(conf, 4),
                        source="motion",
                    )
                )
                motion_idx += 1

                if motion_idx >= self.max_motion_objects:
                    break

        logger.info(
            "object_detector",
            "frame object detection completed",
            frame_id=frame.frame_id,
            objects_count=len(observations),
        )
        return observations, gray