from typing import List, Optional, Tuple

import cv2
import numpy as np

from core.logger import PipelineLogger
from core.models import FrameRecord, MotionObservation


class MotionDetector:
    """
    Dedicated motion detector:
    - frame differencing
    - motion regions output as formal observations
    - returns motion score for event/scene logic
    """

    def __init__(
        self,
        min_motion_area_ratio: float = 0.005,
        max_regions: int = 8,
        threshold_value: int = 25,
        dilate_iterations: int = 2,
    ):
        self.min_motion_area_ratio = float(min_motion_area_ratio)
        self.max_regions = int(max_regions)
        self.threshold_value = int(threshold_value)
        self.dilate_iterations = int(dilate_iterations)

    def process_frame_motion(
        self,
        frame: FrameRecord,
        image: np.ndarray,
        prev_gray: Optional[np.ndarray],
        logger: PipelineLogger,
    ) -> Tuple[List[MotionObservation], np.ndarray, float]:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape[:2]

        if prev_gray is None:
            logger.info(
                "motion_detector",
                "frame motion detection completed",
                frame_id=frame.frame_id,
                motion_regions_count=0,
                motion_score=0.0,
            )
            return [], gray, 0.0

        blur_prev = cv2.GaussianBlur(prev_gray, (5, 5), 0)
        blur_curr = cv2.GaussianBlur(gray, (5, 5), 0)

        diff = cv2.absdiff(blur_prev, blur_curr)
        mean_diff = float(diff.mean() / 255.0)

        _, thresh = cv2.threshold(diff, self.threshold_value, 255, cv2.THRESH_BINARY)
        thresh = cv2.dilate(thresh, None, iterations=self.dilate_iterations)

        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        min_area = int((w * h) * self.min_motion_area_ratio)
        items = []

        for cnt in contours:
            area = float(cv2.contourArea(cnt))
            if area < min_area:
                continue
            x, y, rw, rh = cv2.boundingRect(cnt)
            area_ratio = area / max(1.0, float(w * h))
            items.append((area, [int(x), int(y), int(x + rw), int(y + rh)], area_ratio))

        items.sort(key=lambda x: x[0], reverse=True)
        items = items[: self.max_regions]

        observations: List[MotionObservation] = []
        for idx, (_, bbox, area_ratio) in enumerate(items):
            confidence = min(1.0, max(mean_diff, area_ratio * 10.0))
            observations.append(
                MotionObservation(
                    motion_obs_id=f"{frame.video_id}_motion_{frame.frame_id:06d}_{idx:02d}",
                    video_id=frame.video_id,
                    frame_id=frame.frame_id,
                    timestamp=frame.timestamp,
                    bbox=bbox,
                    area_ratio=round(area_ratio, 6),
                    mean_diff=round(mean_diff, 6),
                    confidence=round(confidence, 4),
                    source="frame_diff",
                )
            )

        logger.info(
            "motion_detector",
            "frame motion detection completed",
            frame_id=frame.frame_id,
            motion_regions_count=len(observations),
            motion_score=round(mean_diff, 6),
        )
        return observations, gray, mean_diff