import math
from typing import Dict, List, Tuple

from core.models import ObjectObservation, TrackedObject


class ObjectTracker:
    """
    Lightweight centroid tracker.
    """

    def __init__(self, max_distance_px: float = 80.0, max_missing_frames: int = 10):
        self.max_distance_px = float(max_distance_px)
        self.max_missing_frames = int(max_missing_frames)

        self.next_track_id = 1
        self.tracks: Dict[str, Dict] = {}

    def _center(self, bbox: List[int]) -> Tuple[float, float]:
        x1, y1, x2, y2 = bbox
        return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)

    def _distance(self, a: List[int], b: List[int]) -> float:
        ax, ay = self._center(a)
        bx, by = self._center(b)
        return math.hypot(ax - bx, ay - by)

    def _new_track_id(self) -> str:
        tid = f"track_{self.next_track_id:05d}"
        self.next_track_id += 1
        return tid

    def update(self, observations: List[ObjectObservation]) -> List[TrackedObject]:
        active_snapshots: List[TrackedObject] = []

        unmatched_track_ids = set(self.tracks.keys())
        used_track_ids = set()

        for obs in observations:
            best_track_id = None
            best_dist = float("inf")

            for track_id, track in self.tracks.items():
                if track_id in used_track_ids:
                    continue
                if track["label"] != obs.label:
                    continue

                dist = self._distance(track["bbox"], obs.bbox)
                if dist < best_dist and dist <= self.max_distance_px:
                    best_dist = dist
                    best_track_id = track_id

            if best_track_id is None:
                best_track_id = self._new_track_id()
                self.tracks[best_track_id] = {
                    "label": obs.label,
                    "bbox": obs.bbox,
                    "confidence": obs.confidence,
                    "last_frame_id": obs.frame_id,
                    "last_timestamp": obs.timestamp,
                    "missed": 0,
                }
            else:
                self.tracks[best_track_id]["bbox"] = obs.bbox
                self.tracks[best_track_id]["confidence"] = obs.confidence
                self.tracks[best_track_id]["last_frame_id"] = obs.frame_id
                self.tracks[best_track_id]["last_timestamp"] = obs.timestamp
                self.tracks[best_track_id]["missed"] = 0

            if best_track_id in unmatched_track_ids:
                unmatched_track_ids.remove(best_track_id)
            used_track_ids.add(best_track_id)

            active_snapshots.append(
                TrackedObject(
                    track_id=best_track_id,
                    video_id=obs.video_id,
                    frame_id=obs.frame_id,
                    timestamp=obs.timestamp,
                    label=obs.label,
                    bbox=obs.bbox,
                    confidence=obs.confidence,
                    source=obs.source,
                )
            )

        to_delete = []
        for track_id in unmatched_track_ids:
            self.tracks[track_id]["missed"] += 1
            if self.tracks[track_id]["missed"] > self.max_missing_frames:
                to_delete.append(track_id)

        for track_id in to_delete:
            del self.tracks[track_id]

        return active_snapshots