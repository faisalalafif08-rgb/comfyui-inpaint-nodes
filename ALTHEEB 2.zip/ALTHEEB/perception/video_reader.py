import hashlib
from pathlib import Path

import cv2

from core.models import VideoRecord


def _make_video_id(video_path: str) -> str:
    p = Path(video_path)
    stat = p.stat()
    raw = f"{p.resolve()}|{stat.st_size}|{int(stat.st_mtime)}"
    return "vid_" + hashlib.md5(raw.encode("utf-8")).hexdigest()[:10]


def inspect_video(video_path: str) -> VideoRecord:
    p = Path(video_path)
    if not p.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")

    cap = cv2.VideoCapture(str(p))
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)

    duration_sec = (frame_count / fps) if fps > 0 else 0.0
    has_audio = p.suffix.lower() in {".mp4", ".mov", ".mkv", ".avi", ".webm"}

    cap.release()

    return VideoRecord(
        video_id=_make_video_id(video_path),
        source_path=str(p.resolve()),
        fps=float(fps if fps > 0 else 30.0),
        duration_sec=float(duration_sec),
        width=width,
        height=height,
        has_audio=has_audio,
    )