from __future__ import annotations

from collections import Counter
from typing import List

from core.models import EventRecord, SceneRecord


class QQSSSceneBuilder:
    def __init__(
        self,
        max_gap_sec: float = 0.8,
        min_events_per_scene: int = 1,
        min_scene_confidence: float = 0.60,
    ):
        self.max_gap_sec = float(max_gap_sec)
        self.min_events_per_scene = int(min_events_per_scene)
        self.min_scene_confidence = float(min_scene_confidence)

    def _make_scene(self, video_id: str, scene_idx: int, bucket: List[EventRecord]) -> SceneRecord:
        bucket = sorted(bucket, key=lambda x: (x.start_time, x.frame_start_id))
        start_time = float(bucket[0].start_time)
        end_time = float(bucket[-1].end_time)
        frame_start_id = int(bucket[0].frame_start_id)
        frame_end_id = int(bucket[-1].frame_end_id)

        event_types = [x.event_type for x in bucket]
        dominant_type = Counter(event_types).most_common(1)[0][0]
        confidence = max(float(x.confidence) for x in bucket)
        summary = f"qqss scene | dominant={dominant_type} | events={len(bucket)}"

        return SceneRecord(
            scene_id=f"{video_id}_qqss_scene_{scene_idx:04d}",
            video_id=video_id,
            start_time=start_time,
            end_time=end_time,
            event_ids=[x.event_id for x in bucket],
            faces_count=0,
            objects_count=0,
            summary=summary,
            confidence=max(self.min_scene_confidence, round(confidence, 4)),
        )

    def build(self, video_id: str, qqss_bridge_events: List[EventRecord]) -> List[SceneRecord]:
        if not qqss_bridge_events:
            return []

        rows = sorted(qqss_bridge_events, key=lambda x: (x.start_time, x.frame_start_id))
        scenes: List[SceneRecord] = []

        bucket: List[EventRecord] = [rows[0]]
        scene_idx = 1

        for item in rows[1:]:
            prev = bucket[-1]
            gap = float(item.start_time) - float(prev.end_time)
            if gap <= self.max_gap_sec:
                bucket.append(item)
            else:
                if len(bucket) >= self.min_events_per_scene:
                    scenes.append(self._make_scene(video_id, scene_idx, bucket))
                    scene_idx += 1
                bucket = [item]

        if bucket and len(bucket) >= self.min_events_per_scene:
            scenes.append(self._make_scene(video_id, scene_idx, bucket))

        return scenes