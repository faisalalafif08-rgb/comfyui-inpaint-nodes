from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, List


class SceneGraphBuilder:
    def __init__(self):
        pass

    def build(
        self,
        report: Dict[str, Any],
        qqss_target: Dict[str, Any],
        qqss_events: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        by_track: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for item in qqss_events:
            track_id = str(item.get("track_id", "")).strip()
            if track_id:
                by_track[track_id].append(item)

        nodes: List[Dict[str, Any]] = []
        edges: List[Dict[str, Any]] = []

        target_id = str(qqss_target.get("target_id", "qqss_target"))
        nodes.append(
            {
                "node_id": target_id,
                "node_type": "target",
                "primary_cell": qqss_target.get("primary_cell", ""),
                "covered_cells": list(qqss_target.get("covered_cells", [])),
                "neighbor_cells": list(qqss_target.get("neighbor_cells", []))
            }
        )

        for track_id, rows in sorted(by_track.items()):
            relation_counter = Counter(str(x.get("relation", "unknown")) for x in rows)
            pattern_counter = Counter(str(x.get("pattern", "unknown")) for x in rows)
            max_risk = max(float(x.get("risk_score", 0.0)) for x in rows)
            dominant_relation = relation_counter.most_common(1)[0][0]
            dominant_pattern = pattern_counter.most_common(1)[0][0]
            current_cell = str(rows[-1].get("current_cell", ""))

            nodes.append(
                {
                    "node_id": track_id,
                    "node_type": "subject",
                    "current_cell": current_cell,
                    "max_risk_score": round(max_risk, 4),
                    "dominant_relation": dominant_relation,
                    "dominant_pattern": dominant_pattern,
                    "events_count": len(rows)
                }
            )

            edges.append(
                {
                    "edge_id": f"{track_id}__to__{target_id}",
                    "from": track_id,
                    "to": target_id,
                    "relation": dominant_relation,
                    "pattern": dominant_pattern,
                    "max_risk_score": round(max_risk, 4)
                }
            )

        return {
            "scene_graph_version": "v1",
            "video_id": str(report.get("video_id", "")),
            "nodes": nodes,
            "edges": edges,
            "zones": {
                "target_primary_cell": qqss_target.get("primary_cell", ""),
                "target_cells": list(qqss_target.get("covered_cells", [])),
                "neighbor_cells": list(qqss_target.get("neighbor_cells", []))
            }
        }