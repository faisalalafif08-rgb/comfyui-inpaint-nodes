from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.models import EventRecord


class EventBuilder:
    """
    Builds simple events from frame stream.
    """

    def __init__(
        self,
        motion_event_threshold: float = 0.10,
        event_gap_sec: float = 1.0,
    ):
        self.motion_event_threshold = float(motion_event_threshold)
        self.event_gap_sec = float(event_gap_sec)

    def _is_active(self, row: Dict[str, Any]) -> bool:
        motion_score = float(row.get("motion_score", 0.0))
        face_jump = float(row.get("face_jump", 0.0))
        object_jump = float(row.get("object_jump", 0.0))
        decision_emitted = bool(row.get("decision_emitted", False))

        return (
            motion_score >= self.motion_event_threshold
            or face_jump > 0
            or object_jump > 0
            or decision_emitted
        )

    def build(self, video_id: str, frame_rows: List[Dict[str, Any]]) -> List[EventRecord]:
        if not frame_rows:
            return []

        events: List[EventRecord] = []
        active: Optional[Dict[str, Any]] = None

        for row in frame_rows:
            is_active = self._is_active(row)

            if is_active:
                if active is None:
                    active = {
                        "start_time": float(row["timestamp"]),
                        "end_time": float(row["timestamp"]),
                        "frame_start_id": int(row["frame_id"]),
                        "frame_end_id": int(row["frame_id"]),
                        "faces_count": int(row.get("num_faces", 0)),
                        "objects_count": int(row.get("num_objects", 0)),
                        "max_motion_score": float(row.get("motion_score", 0.0)),
                        "last_active_time": float(row["timestamp"]),
                        "had_decision": bool(row.get("decision_emitted", False)),
                    }
                else:
                    active["end_time"] = float(row["timestamp"])
                    active["frame_end_id"] = int(row["frame_id"])
                    active["faces_count"] = max(active["faces_count"], int(row.get("num_faces", 0)))
                    active["objects_count"] = max(active["objects_count"], int(row.get("num_objects", 0)))
                    active["max_motion_score"] = max(active["max_motion_score"], float(row.get("motion_score", 0.0)))
                    active["last_active_time"] = float(row["timestamp"])
                    active["had_decision"] = active["had_decision"] or bool(row.get("decision_emitted", False))
            else:
                if active is not None:
                    current_ts = float(row["timestamp"])
                    if current_ts - float(active["last_active_time"]) > self.event_gap_sec:
                        event_idx = len(events)
                        event_type = "decision_event" if active["had_decision"] else "motion_event"
                        confidence = min(0.99, 0.30 + float(active["max_motion_score"]) + (0.15 if active["had_decision"] else 0.0))

                        events.append(
                            EventRecord(
                                event_id=f"{video_id}_event_{event_idx:04d}",
                                video_id=video_id,
                                start_time=float(active["start_time"]),
                                end_time=float(active["end_time"]),
                                frame_start_id=int(active["frame_start_id"]),
                                frame_end_id=int(active["frame_end_id"]),
                                event_type=event_type,
                                faces_count=int(active["faces_count"]),
                                objects_count=int(active["objects_count"]),
                                max_motion_score=round(float(active["max_motion_score"]), 4),
                                confidence=round(float(confidence), 4),
                                notes="auto-built from frame activity",
                            )
                        )
                        active = None

        if active is not None:
            event_idx = len(events)
            event_type = "decision_event" if active["had_decision"] else "motion_event"
            confidence = min(0.99, 0.30 + float(active["max_motion_score"]) + (0.15 if active["had_decision"] else 0.0))

            events.append(
                EventRecord(
                    event_id=f"{video_id}_event_{event_idx:04d}",
                    video_id=video_id,
                    start_time=float(active["start_time"]),
                    end_time=float(active["end_time"]),
                    frame_start_id=int(active["frame_start_id"]),
                    frame_end_id=int(active["frame_end_id"]),
                    event_type=event_type,
                    faces_count=int(active["faces_count"]),
                    objects_count=int(active["objects_count"]),
                    max_motion_score=round(float(active["max_motion_score"]), 4),
                    confidence=round(float(confidence), 4),
                    notes="auto-built from frame activity",
                )
            )

        return events