from __future__ import annotations

from typing import Dict, List

from core.models import BrainDecision, EventRecord


class QQSSBrainReasoner:
    def __init__(self, min_attention_risk: float = 0.70):
        self.min_attention_risk = float(min_attention_risk)

    def build(
        self,
        video_id: str,
        qqss_summary: Dict,
        qqss_bridge_events: List[EventRecord],
    ) -> List[BrainDecision]:
        decisions: List[BrainDecision] = []

        high_risk_count = int(qqss_summary.get("high_risk_count", 0))
        on_target_count = int(qqss_summary.get("on_target_count", 0))
        near_target_count = int(qqss_summary.get("near_target_count", 0))
        bridge_events_count = int(qqss_summary.get("bridge_events_count", 0))

        top_ts = 0.0
        if qqss_bridge_events:
            top_ts = max(float(x.end_time) for x in qqss_bridge_events)

        if high_risk_count > 0:
            decisions.append(
                BrainDecision(
                    decision_id=f"{video_id}_qqss_attention",
                    timestamp=top_ts,
                    event_type="qqss_attention",
                    confidence=min(1.0, 0.60 + (0.05 * high_risk_count)),
                    reasoning=f"QQSS high-risk events detected: {high_risk_count}",
                    payload={
                        "high_risk_count": high_risk_count,
                        "min_attention_risk": self.min_attention_risk,
                    },
                )
            )

        if on_target_count > 0:
            decisions.append(
                BrainDecision(
                    decision_id=f"{video_id}_qqss_target_hold",
                    timestamp=top_ts,
                    event_type="qqss_target_hold",
                    confidence=min(1.0, 0.60 + (0.04 * on_target_count)),
                    reasoning=f"QQSS on-target persistence detected: {on_target_count}",
                    payload={
                        "on_target_count": on_target_count,
                        "near_target_count": near_target_count,
                    },
                )
            )

        if bridge_events_count > 0:
            decisions.append(
                BrainDecision(
                    decision_id=f"{video_id}_qqss_event_fusion",
                    timestamp=top_ts,
                    event_type="qqss_event_fusion",
                    confidence=min(1.0, 0.55 + (0.03 * bridge_events_count)),
                    reasoning=f"QQSS bridge events ready for scene/brain use: {bridge_events_count}",
                    payload={
                        "bridge_events_count": bridge_events_count,
                    },
                )
            )

        return decisions