from __future__ import annotations

from typing import Dict, List, Tuple


class SceneValidator:
    """
    Scene validator: checks duration, event count, confidence, faces/objects.
    """

    def __init__(
        self,
        min_scene_confidence: float = 0.30,
        min_events_per_scene: int = 1,
        min_scene_duration_sec: float = 1.50,
        require_any_faces_or_objects: bool = False,
    ):
        self.min_scene_confidence = float(min_scene_confidence)
        self.min_events_per_scene = int(min_events_per_scene)
        self.min_scene_duration_sec = float(min_scene_duration_sec)
        self.require_any_faces_or_objects = bool(require_any_faces_or_objects)

    def validate_scene(self, scene: Dict) -> Dict:
        start_time = float(scene.get("start_time", 0.0))
        end_time = float(scene.get("end_time", 0.0))
        duration = max(0.0, end_time - start_time)

        event_ids = scene.get("event_ids", []) or []
        faces_count = int(scene.get("faces_count", 0))
        objects_count = int(scene.get("objects_count", 0))
        confidence = float(scene.get("confidence", 0.0))

        reasons: List[str] = []
        is_valid = True

        if confidence < self.min_scene_confidence:
            is_valid = False
            reasons.append(
                f"low_confidence:{confidence:.4f}<{self.min_scene_confidence:.4f}"
            )

        if len(event_ids) < self.min_events_per_scene:
            is_valid = False
            reasons.append(
                f"low_event_count:{len(event_ids)}<{self.min_events_per_scene}"
            )

        if duration < self.min_scene_duration_sec:
            is_valid = False
            reasons.append(
                f"short_duration:{duration:.4f}<{self.min_scene_duration_sec:.4f}"
            )

        if self.require_any_faces_or_objects and faces_count <= 0 and objects_count <= 0:
            is_valid = False
            reasons.append("no_faces_or_objects")

        return {
            "scene_id": scene.get("scene_id"),
            "is_valid": is_valid,
            "duration_sec": round(duration, 4),
            "confidence": round(confidence, 4),
            "events_count": len(event_ids),
            "faces_count": faces_count,
            "objects_count": objects_count,
            "reasons": reasons,
        }

    def validate(self, scenes: List[Dict]) -> Tuple[List[Dict], Dict]:
        validations = [self.validate_scene(scene) for scene in scenes]

        valid_count = sum(1 for row in validations if row["is_valid"])
        invalid_count = len(validations) - valid_count

        summary = {
            "scenes_total": len(validations),
            "scenes_valid": valid_count,
            "scenes_invalid": invalid_count,
            "valid_ratio": round(valid_count / max(1, len(validations)), 4),
        }
        return validations, summary