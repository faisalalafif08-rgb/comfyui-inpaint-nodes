import time
from collections import deque
from typing import Optional, Dict, Any

from core.models import BrainDecision
from core.logger import PipelineLogger


class AlTheebBrain:
    """
    Simple QQSS-like decision engine.
    """

    def __init__(
        self,
        logger: PipelineLogger,
        qqss_window: int = 30,
        qqss_threshold: float = 0.18,
        cooldown_sec: float = 1.5,
    ):
        self.logger = logger
        self.qqss_window = deque(maxlen=qqss_window)
        self.qqss_threshold = qqss_threshold
        self.cooldown_sec = cooldown_sec
        self.last_decision_ts = 0.0

    def _compute_score(self, frame_data: Dict[str, Any]) -> float:
        motion_score = float(frame_data.get("motion_score", 0.0))
        num_faces = int(frame_data.get("num_faces", 0))
        num_objects = int(frame_data.get("num_objects", 0))
        face_jump = float(frame_data.get("face_jump", 0.0))
        object_jump = float(frame_data.get("object_jump", 0.0))

        score = (
            (motion_score * 0.60)
            + (face_jump * 0.20)
            + (object_jump * 0.15)
            + (0.05 if num_faces > 0 else 0.0)
            + (0.05 if num_objects > 0 else 0.0)
        )
        return float(score)

    def perceive(self, frame_data: Dict[str, Any]) -> Optional[BrainDecision]:
        self.qqss_window.append(frame_data)
        if len(self.qqss_window) < 3:
            return None

        score = self._compute_score(frame_data)
        now = time.time()

        if score < self.qqss_threshold:
            return None

        if now - self.last_decision_ts < self.cooldown_sec:
            return None

        self.last_decision_ts = now

        decision = BrainDecision(
            decision_id=f"dec_{int(now * 1000)}",
            timestamp=float(frame_data.get("timestamp", 0.0)),
            event_type="INVESTIGATE" if score >= (self.qqss_threshold * 1.5) else "LOG",
            confidence=round(min(0.99, 0.5 + score), 4),
            reasoning=f"qqss_score={score:.4f} exceeded threshold={self.qqss_threshold:.4f}",
            payload={
                "frame_id": frame_data.get("frame_id"),
                "motion_score": frame_data.get("motion_score"),
                "num_faces": frame_data.get("num_faces"),
                "num_objects": frame_data.get("num_objects"),
                "face_jump": frame_data.get("face_jump"),
                "object_jump": frame_data.get("object_jump"),
            },
        )

        self.logger.info(
            "brain",
            "decision emitted",
            decision_id=decision.decision_id,
            event_type=decision.event_type,
            confidence=decision.confidence,
            reasoning=decision.reasoning,
        )
        return decision