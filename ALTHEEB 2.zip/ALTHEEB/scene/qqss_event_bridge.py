from __future__ import annotations

from typing import Dict, List

from core.models import EventRecord


class QQSSEventBridge:
    def __init__(self, min_risk_score: float = 0.70):
        self.min_risk_score = float(min_risk_score)

    def _event_type_for(self, item: Dict) -> str | None:
        relation = str(item.get("relation", ""))
        pattern = str(item.get("pattern", ""))
        risk = float(item.get("risk_score", 0.0))

        if relation == "on_target" and pattern == "target_entry":
            return "qqss_target_entry"

        if relation == "on_target" and pattern == "on_target_hold" and risk >= self.min_risk_score:
            return "qqss_on_target_hold"

        if risk >= self.min_risk_score:
            return "qqss_high_risk_presence"

        return None

    def build(self, video_id: str, qqss_events: List[Dict]) -> List[EventRecord]:
        out: List[EventRecord] = []

        for idx, item in enumerate(qqss_events):
            event_type = self._event_type_for(item)
            if event_type is None:
                continue

            frame_id = int(item.get("frame_id", 0))
            timestamp = float(item.get("timestamp", 0.0))
            risk = float(item.get("risk_score", 0.0))
            relation = str(item.get("relation", "unknown"))
            pattern = str(item.get("pattern", "unknown"))
            track_id = str(item.get("track_id", "unknown"))

            out.append(
                EventRecord(
                    event_id=f"{video_id}_qqss_event_{idx:06d}",
                    video_id=video_id,
                    start_time=timestamp,
                    end_time=timestamp,
                    frame_start_id=frame_id,
                    frame_end_id=frame_id,
                    event_type=event_type,
                    faces_count=0,
                    objects_count=1,
                    max_motion_score=round(risk, 4),
                    confidence=round(risk, 4),
                    notes=f"track={track_id}; relation={relation}; pattern={pattern}",
                )
            )

        return out