from __future__ import annotations

from typing import List, Optional

from core.models import EventRecord, SceneRecord


class SceneBuilder:
    """
    Groups events into scenes.
    """

    def __init__(
        self,
        scene_gap_sec: float = 2.0,
        min_scene_duration_sec: float = 1.5,
    ):
        self.scene_gap_sec = float(scene_gap_sec)
        self.min_scene_duration_sec = float(min_scene_duration_sec)

    def build(self, video_id: str, events: List[EventRecord]) -> List[SceneRecord]:
        if not events:
            return []

        scenes: List[SceneRecord] = []
        current: Optional[dict] = None

        for event in events:
            if current is None:
                current = {
                    "start_time": event.start_time,
                    "end_time": event.end_time,
                    "event_ids": [event.event_id],
                    "faces_count": event.faces_count,
                    "objects_count": event.objects_count,
                    "confidences": [event.confidence],
                }
                continue

            gap = event.start_time - current["end_time"]
            if gap <= self.scene_gap_sec:
                current["end_time"] = event.end_time
                current["event_ids"].append(event.event_id)
                current["faces_count"] = max(current["faces_count"], event.faces_count)
                current["objects_count"] = max(current["objects_count"], event.objects_count)
                current["confidences"].append(event.confidence)
            else:
                duration = current["end_time"] - current["start_time"]
                if duration >= self.min_scene_duration_sec:
                    idx = len(scenes)
                    avg_conf = sum(current["confidences"]) / max(1, len(current["confidences"]))
                    summary = (
                        f"scene with {len(current['event_ids'])} events, "
                        f"max_faces={current['faces_count']}, "
                        f"max_objects={current['objects_count']}"
                    )

                    scenes.append(
                        SceneRecord(
                            scene_id=f"{video_id}_scene_{idx:04d}",
                            video_id=video_id,
                            start_time=round(float(current["start_time"]), 4),
                            end_time=round(float(current["end_time"]), 4),
                            event_ids=list(current["event_ids"]),
                            faces_count=int(current["faces_count"]),
                            objects_count=int(current["objects_count"]),
                            summary=summary,
                            confidence=round(float(avg_conf), 4),
                        )
                    )

                current = {
                    "start_time": event.start_time,
                    "end_time": event.end_time,
                    "event_ids": [event.event_id],
                    "faces_count": event.faces_count,
                    "objects_count": event.objects_count,
                    "confidences": [event.confidence],
                }

        if current is not None:
            duration = current["end_time"] - current["start_time"]
            if duration >= self.min_scene_duration_sec:
                idx = len(scenes)
                avg_conf = sum(current["confidences"]) / max(1, len(current["confidences"]))
                summary = (
                    f"scene with {len(current['event_ids'])} events, "
                    f"max_faces={current['faces_count']}, "
                    f"max_objects={current['objects_count']}"
                )

                scenes.append(
                    SceneRecord(
                        scene_id=f"{video_id}_scene_{idx:04d}",
                        video_id=video_id,
                        start_time=round(float(current["start_time"]), 4),
                        end_time=round(float(current["end_time"]), 4),
                        event_ids=list(current["event_ids"]),
                        faces_count=int(current["faces_count"]),
                        objects_count=int(current["objects_count"]),
                        summary=summary,
                        confidence=round(float(avg_conf), 4),
                    )
                )

        return scenes