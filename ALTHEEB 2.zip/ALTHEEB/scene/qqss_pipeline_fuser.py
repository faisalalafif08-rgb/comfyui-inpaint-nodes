from __future__ import annotations

from typing import Dict, List

from core.models import BrainDecision, EventRecord, SceneRecord
from scene.qqss_brain_reasoner import QQSSBrainReasoner
from scene.qqss_scene_builder import QQSSSceneBuilder


class QQSSPipelineFuser:
    def __init__(
        self,
        min_attention_risk: float = 0.70,
        scene_gap_sec: float = 0.80,
    ):
        self.qqss_scene_builder = QQSSSceneBuilder(max_gap_sec=scene_gap_sec)
        self.qqss_brain_reasoner = QQSSBrainReasoner(min_attention_risk=min_attention_risk)

    def fuse(
        self,
        video_id: str,
        qqss_summary: Dict,
        qqss_bridge_events: List[EventRecord],
        events: List[EventRecord],
        scenes: List[SceneRecord],
        decisions: List[BrainDecision],
    ) -> Dict:
        qqss_scenes = self.qqss_scene_builder.build(
            video_id=video_id,
            qqss_bridge_events=qqss_bridge_events,
        )
        qqss_brain_decisions = self.qqss_brain_reasoner.build(
            video_id=video_id,
            qqss_summary=qqss_summary,
            qqss_bridge_events=qqss_bridge_events,
        )

        merged_events = list(events) + list(qqss_bridge_events)
        merged_events = sorted(merged_events, key=lambda x: (float(x.start_time), int(x.frame_start_id)))

        merged_scenes = list(scenes) + list(qqss_scenes)
        merged_scenes = sorted(merged_scenes, key=lambda x: (float(x.start_time), float(x.end_time)))

        merged_decisions = list(decisions) + list(qqss_brain_decisions)
        merged_decisions = sorted(merged_decisions, key=lambda x: float(x.timestamp))

        return {
            "events": merged_events,
            "scenes": merged_scenes,
            "decisions": merged_decisions,
            "qqss_scenes": qqss_scenes,
            "qqss_brain_decisions": qqss_brain_decisions,
        }