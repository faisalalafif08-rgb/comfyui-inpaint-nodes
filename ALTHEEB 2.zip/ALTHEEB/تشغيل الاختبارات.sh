python tests/sanity_check.py
python -m unittest tests.test_identity_vault
python -m unittest tests.test_event_scene_builders