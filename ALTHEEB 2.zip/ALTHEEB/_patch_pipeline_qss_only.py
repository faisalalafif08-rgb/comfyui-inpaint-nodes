﻿from pathlib import Path
import re
import shutil
import sys

p = Path("orchestration/pipeline.py")
text = p.read_text(encoding="utf-8")
orig = text

def fail(msg: str):
    raise SystemExit(msg)

def ensure_import(text: str, import_line: str) -> str:
    if import_line in text:
        return text

    # preferred: insert after PoseAdapter import if it exists
    marker = "from analysis.pose_adapter import PoseAdapter"
    if marker in text:
        return text.replace(marker, marker + "\n" + import_line, 1)

    # fallback: insert after future import
    m = re.search(r"from __future__ import annotations\s*\n", text)
    if m:
        return text[:m.end()] + import_line + "\n" + text[m.end():]

    return import_line + "\n" + text

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        fail(f"REPLACE_TARGET_NOT_FOUND::{label}")
    return text.replace(old, new, 1)

def insert_after(text: str, marker: str, block: str, label: str) -> str:
    if block.strip() in text:
        return text
    idx = text.find(marker)
    if idx < 0:
        fail(f"MARKER_NOT_FOUND::{label}")
    idx += len(marker)
    return text[:idx] + "\n" + block + text[idx:]

def replace_block_regex(text: str, pattern: str, replacement: str, label: str) -> str:
    if replacement.strip() in text:
        return text
    new_text, n = re.subn(pattern, replacement, text, count=1, flags=re.M | re.S)
    if n == 0:
        fail(f"BLOCK_NOT_FOUND::{label}")
    return new_text

# ---------------------------------------------------------
# 1) import QQSSPipelineFuser only
# ---------------------------------------------------------
text = ensure_import(text, "from scene.qqss_pipeline_fuser import QQSSPipelineFuser")

# ---------------------------------------------------------
# 2) init block for qqss fuser only
#    insert after self.pose_adapter block if present
# ---------------------------------------------------------
fuser_init_block = """        self.qqss_fuser = QQSSPipelineFuser(
            min_attention_risk=getattr(self, "qqss_min_risk_score", 0.70),
            scene_gap_sec=0.80,
        )"""

if fuser_init_block not in text:
    pose_init_pat = r'^[ \t]*self\.pose_adapter\s*=\s*PoseAdapter\([\s\S]*?^[ \t]*\)[ \t]*$'
    if re.search(pose_init_pat, text, flags=re.M | re.S):
        m = re.search(pose_init_pat, text, flags=re.M | re.S)
        idx = m.end()
        text = text[:idx] + "\n" + fuser_init_block + text[idx:]
    else:
        # fallback after self.gait or self.brain
        m = re.search(r'(?m)^([ \t]*)self\.gait\s*=.*$', text)
        if not m:
            m = re.search(r'(?m)^([ \t]*)self\.brain\s*=.*$', text)
        if not m:
            fail("INIT_MARKER_NOT_FOUND::QQSS_FUSER")
        idx = m.end()
        text = text[:idx] + "\n" + fuser_init_block + text[idx:]

# ---------------------------------------------------------
# 3) merge block after qqss summary write
#    overwrite events/scenes/decisions JSON after merge
# ---------------------------------------------------------
merge_block = """        qqss_merge = self.qqss_fuser.fuse(
            video_id=video.video_id,
            qqss_summary=qqss_summary,
            qqss_bridge_events=qqss_bridge_events,
            events=events,
            scenes=scenes,
            decisions=decisions,
        )

        events = qqss_merge["events"]
        scenes = qqss_merge["scenes"]
        decisions = qqss_merge["decisions"]
        qqss_scenes = qqss_merge["qqss_scenes"]
        qqss_brain_decisions = qqss_merge["qqss_brain_decisions"]

        qqss_scenes_json = self.indices_dir / f"{video.video_id}_qqss_scenes.json"
        qqss_brain_decisions_json = self.indices_dir / f"{video.video_id}_qqss_brain_decisions.json"

        self._write_json(events_json, [asdict(x) for x in events])
        self._write_json(scenes_json, [asdict(x) for x in scenes])
        self._write_json(decisions_json, [asdict(x) for x in decisions])
        self._write_json(qqss_scenes_json, [asdict(x) for x in qqss_scenes])
        self._write_json(qqss_brain_decisions_json, [asdict(x) for x in qqss_brain_decisions])"""

text = insert_after(
    text,
    '        self._write_json(qqss_summary_json, qqss_summary)',
    merge_block,
    "QQSS_MERGE_BLOCK"
)

# ---------------------------------------------------------
# 4) report counters
# ---------------------------------------------------------
text = replace_once(
    text,
    '            "qqss_bridge_events_count": len(qqss_bridge_events),\n',
    '            "qqss_bridge_events_count": len(qqss_bridge_events),\n'
    '            "qqss_scenes_count": len(qqss_scenes),\n'
    '            "qqss_brain_decisions_count": len(qqss_brain_decisions),\n',
    "REPORT_COUNTERS"
)

# ---------------------------------------------------------
# 5) report outputs
# ---------------------------------------------------------
text = replace_once(
    text,
    '                "qqss_bridge_events_json": str(qqss_bridge_events_json),\n',
    '                "qqss_bridge_events_json": str(qqss_bridge_events_json),\n'
    '                "qqss_scenes_json": str(qqss_scenes_json),\n'
    '                "qqss_brain_decisions_json": str(qqss_brain_decisions_json),\n',
    "REPORT_OUTPUTS"
)

# ---------------------------------------------------------
# 6) logger fields
# ---------------------------------------------------------
text = replace_once(
    text,
    '            qqss_bridge_events_count=len(qqss_bridge_events),\n',
    '            qqss_bridge_events_count=len(qqss_bridge_events),\n'
    '            qqss_scenes_count=len(qqss_scenes),\n'
    '            qqss_brain_decisions_count=len(qqss_brain_decisions),\n',
    "LOGGER_FIELDS"
)

if text == orig:
    print("NO_CHANGES")
else:
    p.write_text(text, encoding="utf-8")
    print(f"PATCHED_OK: {p}")
