﻿import cv2
from pathlib import Path

files = [
    r"C:\ALTHEEB\data\input\videos\sample3.MOV",
    r"C:\ALTHEEB\data\input\videos\sample.mp4",
    r"C:\ALTHEEB\data\input\videos\sample2.mp4",
]

for p in files:
    path = Path(p)
    print("=" * 80)
    print("FILE:", path)
    print("exists:", path.exists())

    if not path.exists():
        continue

    cap = cv2.VideoCapture(str(path))
    opened = cap.isOpened()
    fps = cap.get(cv2.CAP_PROP_FPS) if opened else 0
    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) if opened else 0

    ok, frame = cap.read() if opened else (False, None)
    print("opened:", opened)
    print("fps:", fps)
    print("frames:", frames)
    print("first_read:", ok)
    print("frame_is_none:", frame is None)

    cap.release()
