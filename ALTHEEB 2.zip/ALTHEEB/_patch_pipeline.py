from pathlib import Path
import re
import shutil
import sys

p = Path("orchestration/pipeline.py")
if not p.exists():
    raise SystemExit("PIPELINE_NOT_FOUND")

text = p.read_text(encoding="utf-8")
orig = text

backup = p.with_name(p.name + ".bak")
shutil.copy2(p, backup)

def fail(msg: str):
    raise SystemExit(msg)

def ensure_import(text: str, import_line: str) -> str:
    if import_line in text:
        return text
    m = re.search(r"from __future__ import annotations\s*\n", text)
    if m:
        return text[:m.end()] + import_line + "\n" + text[m.end():]
    return import_line + "\n" + text

def insert_after(text: str, marker: str, block: str, label: str) -> str:
    if block.strip() in text:
        return text
    idx = text.find(marker)
    if idx < 0:
        fail(f"MARKER_NOT_FOUND::{label}")
    idx += len(marker)
    return text[:idx] + "\n" + block + text[idx:]

def replace_block_regex(text: str, pattern: str, replacement: str, label: str) -> str:
    if replacement.strip() in text:
        return text
    new_text, n = re.subn(pattern, replacement, text, count=1, flags=re.M | re.S)
    if n == 0:
        fail(f"BLOCK_NOT_FOUND::{label}")
    return new_text

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        fail(f"REPLACE_TARGET_NOT_FOUND::{label}")
    return text.replace(old, new, 1)

# imports
text = ensure_import(text, "from analysis.pose_adapter import PoseAdapter")
text = ensure_import(text, "from scene.qqss_pipeline_fuser import QQSSPipelineFuser")

# __init__ blocks
pose_init_block = """        self.pose_adapter = PoseAdapter(
            logger=self.logger,
            backend="auto",
            task_model_path="models/mediapipe/pose_landmarker_full.task",
            ultralytics_model="",
        )"""

fuser_init_block = """        self.qqss_fuser = QQSSPipelineFuser(
            min_attention_risk=getattr(self, "qqss_min_risk_score", 0.70),
            scene_gap_sec=0.80,
        )"""

if pose_init_block not in text:
    old_pose_pat = r'^[ \t]*self\.pose_adapter\s*=\s*PoseAdapter\([\s\S]*?^[ \t]*\)[ \t]*$'
    if re.search(old_pose_pat, text, flags=re.M | re.S):
        text = replace_block_regex(text, old_pose_pat, pose_init_block, "POSE_INIT")
    else:
        m = re.search(r'(?m)^([ \t]*)self\.gait\s*=.*$', text)
        if not m:
            m = re.search(r'(?m)^([ \t]*)self\.brain\s*=.*$', text)
        if not m:
            fail("INIT_MARKER_NOT_FOUND::POSE")
        idx = m.end()
        text = text[:idx] + "\n" + pose_init_block + text[idx:]

if fuser_init_block not in text:
    old_fuser_pat = r'^[ \t]*self\.qqss_fuser\s*=\s*QQSSPipelineFuser\([\s\S]*?^[ \t]*\)[ \t]*$'
    if re.search(old_fuser_pat, text, flags=re.M | re.S):
        text = replace_block_regex(text, old_fuser_pat, fuser_init_block, "QQSS_FUSER_INIT")
    else:
        if pose_init_block in text:
            text = text.replace(pose_init_block, pose_init_block + "\n" + fuser_init_block, 1)
        else:
            fail("POSE_INIT_NOT_FOUND_FOR_FUSER_INSERT")

# pose loop block
pose_loop_block = """            pose_obs = self.pose_adapter.extract(
                frame_bgr=frame_bgr,
                video_id=video.video_id,
                frame_id=frame_rec.frame_id,
                timestamp=frame_rec.timestamp,
            )
            if pose_obs is not None:
                all_pose.append(pose_obs)

            gait_landmarks = self.pose_adapter.to_gait_landmarks(pose_obs)
            if gait_landmarks is not None:
                self.gait.update(
                    frame_id=frame_rec.frame_id,
                    timestamp=frame_rec.timestamp,
                    landmarks=gait_landmarks,
                )

            body_metrics = self.pose_adapter.to_body_metrics(pose_obs)
            if body_metrics is not None:
                all_body_metrics.append(body_metrics)"""

if pose_loop_block not in text:
    old_pose_loop_pat = r'^[ \t]*pose_obs\s*=\s*self\.pose_adapter\.extract\([\s\S]*?^[ \t]*all_body_metrics\.append\(body_metrics\)[ \t]*$'
    if re.search(old_pose_loop_pat, text, flags=re.M | re.S):
        text = replace_block_regex(text, old_pose_loop_pat, pose_loop_block, "POSE_LOOP")
    else:
        fail("POSE_LOOP_MARKER_NOT_FOUND")

# merge block after qqss_summary write
merge_block = """        qqss_merge = self.qqss_fuser.fuse(
            video_id=video.video_id,
            qqss_summary=qqss_summary,
            qqss_bridge_events=qqss_bridge_events,
            events=events,
            scenes=scenes,
            decisions=decisions,
        )

        events = qqss_merge["events"]
        scenes = qqss_merge["scenes"]
        decisions = qqss_merge["decisions"]
        qqss_scenes = qqss_merge["qqss_scenes"]
        qqss_brain_decisions = qqss_merge["qqss_brain_decisions"]

        qqss_scenes_json = self.indices_dir / f"{video.video_id}_qqss_scenes.json"
        qqss_brain_decisions_json = self.indices_dir / f"{video.video_id}_qqss_brain_decisions.json"

        self._write_json(qqss_scenes_json, [asdict(x) for x in qqss_scenes])
        self._write_json(qqss_brain_decisions_json, [asdict(x) for x in qqss_brain_decisions])
        self._write_json(decisions_json, [asdict(x) for x in decisions])"""

text = insert_after(
    text,
    '        self._write_json(qqss_summary_json, qqss_summary)',
    merge_block,
    "QQSS_MERGE_BLOCK"
)

# report counters
text = replace_once(
    text,
    '            "qqss_bridge_events_count": len(qqss_bridge_events),\n',
    '            "qqss_bridge_events_count": len(qqss_bridge_events),\n'
    '            "qqss_scenes_count": len(qqss_scenes),\n'
    '            "qqss_brain_decisions_count": len(qqss_brain_decisions),\n',
    "REPORT_COUNTERS"
)

# report outputs
text = replace_once(
    text,
    '                "qqss_bridge_events_json": str(qqss_bridge_events_json),\n',
    '                "qqss_bridge_events_json": str(qqss_bridge_events_json),\n'
    '                "qqss_scenes_json": str(qqss_scenes_json),\n'
    '                "qqss_brain_decisions_json": str(qqss_brain_decisions_json),\n',
    "REPORT_OUTPUTS"
)

# logger fields
text = replace_once(
    text,
    '            qqss_bridge_events_count=len(qqss_bridge_events),\n',
    '            qqss_bridge_events_count=len(qqss_bridge_events),\n'
    '            qqss_scenes_count=len(qqss_scenes),\n'
    '            qqss_brain_decisions_count=len(qqss_brain_decisions),\n',
    "LOGGER_FIELDS"
)

if text == orig:
    print("NO_CHANGES")
else:
    p.write_text(text, encoding="utf-8")
    print(f"PATCHED_OK: {p}")
    print(f"BACKUP_OK: {backup}")