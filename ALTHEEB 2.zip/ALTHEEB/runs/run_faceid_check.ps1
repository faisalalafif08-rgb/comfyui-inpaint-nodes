$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv_faceid\Scripts\python.exe"
if (!(Test-Path $py)) { throw "FACEID_PYTHON_NOT_FOUND: $py" }

& $py -c "import sys; print(sys.executable)"
& $py -c "import insightface, onnxruntime; print('FACEID OK')"