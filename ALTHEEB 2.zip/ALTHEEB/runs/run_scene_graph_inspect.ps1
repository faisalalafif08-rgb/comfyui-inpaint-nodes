param(
    [string]$SceneGraphJson = ""
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv\Scripts\python.exe"
if (!(Test-Path $py)) { throw "BASELINE_PYTHON_NOT_FOUND: $py" }

if ([string]::IsNullOrWhiteSpace($SceneGraphJson)) {
    $latest = Get-ChildItem .\data\indices\*_scene_graph.json | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($null -eq $latest) { throw "NO_SCENE_GRAPH_JSON_FOUND" }
    $SceneGraphJson = $latest.FullName
}

& $py -m apps.inspect_scene_graph --scene-graph $SceneGraphJson