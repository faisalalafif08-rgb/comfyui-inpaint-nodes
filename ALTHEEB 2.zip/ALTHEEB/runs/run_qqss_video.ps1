param(
    [string]$ReportJson = "",
    [string]$OutPath = ".\reports\qqss_overlay_video.mp4",
    [int]$Rows = 6,
    [int]$Cols = 8,
    [double]$Fps = 0,
    [switch]$ShowLabels
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv\Scripts\python.exe"
if (!(Test-Path $py)) { throw "BASELINE_PYTHON_NOT_FOUND: $py" }

if ([string]::IsNullOrWhiteSpace($ReportJson)) {
    $latest = Get-ChildItem .\data\indices\*_report.json | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($null -eq $latest) { throw "NO_REPORT_JSON_FOUND" }
    $ReportJson = $latest.FullName
}

$args = @(
    "-m", "apps.render_qqss_video",
    "--report", $ReportJson,
    "--out", $OutPath,
    "--rows", "$Rows",
    "--cols", "$Cols"
)

if ($Fps -gt 0) {
    $args += @("--fps", "$Fps")
}
if ($ShowLabels) {
    $args += @("--show-labels")
}

& $py @args