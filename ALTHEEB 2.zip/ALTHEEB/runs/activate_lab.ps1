$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
& .\.venv_lab\Scripts\Activate.ps1
Write-Host "ALTHEEB lab environment activated" -ForegroundColor Green