$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
& .\.venv\Scripts\Activate.ps1
Write-Host "ALTHEEB baseline environment activated" -ForegroundColor Green