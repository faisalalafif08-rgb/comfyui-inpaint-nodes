param(
    [string]$QQSSJson
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if ([string]::IsNullOrWhiteSpace($QQSSJson)) { throw "QQSS_JSON_REQUIRED" }
if (!(Test-Path $QQSSJson)) { throw "QQSS_JSON_NOT_FOUND: $QQSSJson" }

$data = Get-Content $QQSSJson -Raw | ConvertFrom-Json
Write-Host "=== QQSS INSPECT ===" -ForegroundColor Cyan
Write-Host ("events_count: " + @($data).Count)

$high = @($data | Where-Object { $_.risk_score -ge 0.7 })
Write-Host ("high_risk_count: " + $high.Count)

$onTarget = @($data | Where-Object { $_.relation -eq "on_target" })
Write-Host ("on_target_count: " + $onTarget.Count)

$nearTarget = @($data | Where-Object { $_.relation -eq "near_target" })
Write-Host ("near_target_count: " + $nearTarget.Count)

if (@($data).Count -gt 0) {
    Write-Host "`nlast_event:" -ForegroundColor Yellow
    $data[-1] | ConvertTo-Json -Depth 6
}