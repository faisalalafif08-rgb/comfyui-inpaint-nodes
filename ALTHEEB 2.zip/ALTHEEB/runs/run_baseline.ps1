param(
    [string]$Video = ".\data\input\videos\sample.mp4"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv\Scripts\python.exe"
if (!(Test-Path $py)) { throw "BASELINE_PYTHON_NOT_FOUND: $py" }
if (!(Test-Path $Video)) { throw "VIDEO_NOT_FOUND: $Video" }

Write-Host "Running ALTHEEB baseline..." -ForegroundColor Cyan
Write-Host "Video: $Video" -ForegroundColor Yellow
& $py .\run.py --video $Video