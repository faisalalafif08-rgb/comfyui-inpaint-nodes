param(
    [string]$Video = ".\data\input\videos\sample.mp4"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

powershell -ExecutionPolicy Bypass -File .\runs\run_baseline.ps1 -Video $Video
powershell -ExecutionPolicy Bypass -File .\runs\run_qqss_fuse.ps1
powershell -ExecutionPolicy Bypass -File .\runs\run_world_fuse.ps1
powershell -ExecutionPolicy Bypass -File .\runs\run_world_inspect.ps1