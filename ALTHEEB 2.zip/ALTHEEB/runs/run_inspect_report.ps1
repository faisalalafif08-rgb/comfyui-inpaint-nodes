param(
    [string]$ReportJson
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv\Scripts\python.exe"
if (!(Test-Path $py)) { throw "BASELINE_PYTHON_NOT_FOUND: $py" }
if ([string]::IsNullOrWhiteSpace($ReportJson)) { throw "REPORT_JSON_REQUIRED" }
if (!(Test-Path $ReportJson)) { throw "REPORT_JSON_NOT_FOUND: $ReportJson" }

& $py .\apps\inspect_run.py $ReportJson