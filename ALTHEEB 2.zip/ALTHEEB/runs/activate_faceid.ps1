$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
& .\.venv_faceid\Scripts\Activate.ps1
Write-Host "ALTHEEB faceid environment activated" -ForegroundColor Green