$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv\Scripts\python.exe"
if (!(Test-Path $py)) { throw "BASELINE_PYTHON_NOT_FOUND: $py" }

& $py -m unittest `
    tests.test_knowledge_engine `
    tests.test_world_plausibility `
    tests.test_cinematic_reasoner `
    tests.test_generation_planner -v