$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv_vision\Scripts\python.exe"
if (!(Test-Path $py)) { throw "VISION_PYTHON_NOT_FOUND: $py" }

& $py -c "import sys; print(sys.executable)"
& $py -c "import ultralytics, onnxruntime; print('VISION OK')"