$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "=== BASELINE ===" -ForegroundColor Cyan
& (Join-Path $root ".venv\Scripts\python.exe") -c "import sys; print(sys.executable)"

Write-Host "`n=== VISION ===" -ForegroundColor Cyan
& (Join-Path $root ".venv_vision\Scripts\python.exe") -c "import sys; print(sys.executable)"

Write-Host "`n=== FACEID ===" -ForegroundColor Cyan
& (Join-Path $root ".venv_faceid\Scripts\python.exe") -c "import sys; print(sys.executable)"