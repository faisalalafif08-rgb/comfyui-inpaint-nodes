param(
    [string]$ReportJson = "",
    [int]$FrameId = -1,
    [string]$OutPath = "",
    [switch]$ShowLabels
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$py = Join-Path $root ".venv\Scripts\python.exe"
if (!(Test-Path $py)) { throw "BASELINE_PYTHON_NOT_FOUND: $py" }

if ([string]::IsNullOrWhiteSpace($ReportJson)) {
    $latest = Get-ChildItem .\data\indices\*_report.json | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($null -eq $latest) { throw "NO_REPORT_JSON_FOUND" }
    $ReportJson = $latest.FullName
}

$args = @("-m", "apps.render_qqss_overlay", "--report", $ReportJson)

if ($FrameId -ge 0) {
    $args += @("--frame-id", "$FrameId")
}
if (![string]::IsNullOrWhiteSpace($OutPath)) {
    $args += @("--out", $OutPath)
}
if ($ShowLabels) {
    $args += @("--show-labels")
}

& $py @args