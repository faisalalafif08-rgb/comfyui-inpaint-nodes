$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
& .\.venv_gen\Scripts\Activate.ps1
Write-Host "ALTHEEB gen environment activated" -ForegroundColor Green