$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
& .\.venv_vision\Scripts\Activate.ps1
Write-Host "ALTHEEB vision environment activated" -ForegroundColor Green