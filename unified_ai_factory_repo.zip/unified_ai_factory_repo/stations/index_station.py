# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import zipfile, shutil

TEXT_EXTS = {".txt", ".md", ".csv", ".log", ".json"}
CODE_EXTS = {".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cpp", ".c", ".h", ".go", ".rs", ".swift"}
PDF_EXTS  = {".pdf"}
MEDIA_EXTS= {".png",".jpg",".jpeg",".webp",".mp3",".wav",".mp4",".mov"}

def index_bundle(bundle_zip: Path, batch_dir: Path):
    work = batch_dir / "__index_work__"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(bundle_zip, "r") as z:
        z.extractall(work)

    items = []
    for p in work.rglob("*"):
        if not p.is_file():
            continue
        items.append({
            "path": str(p),
            "rel": str(p.relative_to(work)).replace("\\", "/"),
            "ext": p.suffix.lower(),
            "size": p.stat().st_size,
        })

    return {"root": str(work), "items": items, "ext_sets": {"text": TEXT_EXTS, "code": CODE_EXTS, "media": MEDIA_EXTS, "pdf": PDF_EXTS}}
