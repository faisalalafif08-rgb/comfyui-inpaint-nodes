# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import re, json
from collections import Counter

BRAILLE_RE = re.compile(r"[\u2800-\u28FF]")

BRAILLE_TO_LATIN = {
    "⠁":"a","⠃":"b","⠉":"c","⠙":"d","⠑":"e","⠋":"f","⠛":"g","⠓":"h","⠊":"i","⠚":"j",
    "⠅":"k","⠇":"l","⠍":"m","⠝":"n","⠕":"o","⠏":"p","⠟":"q","⠗":"r","⠎":"s","⠞":"t",
    "⠥":"u","⠧":"v","⠺":"w","⠭":"x","⠽":"y","⠵":"z",
    "⠀":" ", "⠠":"", "⠰":"",
}

def decode_braille_line(s: str) -> str:
    out = []
    for ch in s.strip():
        if ch in BRAILLE_TO_LATIN:
            out.append(BRAILLE_TO_LATIN[ch])
        elif BRAILLE_RE.match(ch):
            out.append(f"[{ord(ch):04X}]")
        else:
            out.append(ch)
    return re.sub(r"\s+", " ", "".join(out)).strip()

def run_braille_station(files: list[str], batch_dir: Path) -> Path:
    out = batch_dir / "stations_out" / "braille"
    out.mkdir(parents=True, exist_ok=True)

    decoded_all = []
    word_counter = Counter()

    for fp in files:
        txt = Path(fp).read_text(encoding="utf-8", errors="replace")
        for ln in txt.splitlines():
            if not BRAILLE_RE.search(ln):
                continue
            dec = decode_braille_line(ln)
            if dec:
                decoded_all.append(dec)
                for w in dec.split():
                    word_counter[w.lower()] += 1

    (out / "braille_decoded_all.txt").write_text("\n".join(decoded_all), encoding="utf-8")
    top = [{"term":t,"count":c} for t,c in word_counter.most_common(200)]
    (out / "report.json").write_text(json.dumps({"station":"braille","files":len(files),"decoded_lines":len(decoded_all),"top_terms":top[:20]}, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
