# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import re

BRAILLE_RE = re.compile(r"[\u2800-\u28FF]")
ARABIC_RE  = re.compile(r"[\u0600-\u06FF]")

def _peek_text(path: Path, max_chars=20000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:max_chars]
    except Exception:
        return ""

def route_items(index: dict):
    root = Path(index["root"])
    items = index["items"]
    exts = index["ext_sets"]

    routes = {"text": [], "braille": [], "arabic": [], "code": [], "media": [], "pdf": []}

    for it in items:
        p = root / it["rel"]
        ext = it["ext"]

        if ext in exts["code"]:
            routes["code"].append(str(p)); continue
        if ext in exts["media"]:
            routes["media"].append(str(p)); continue
        if ext in exts["pdf"]:
            routes["pdf"].append(str(p)); continue

        if ext in exts["text"]:
            sample = _peek_text(p)
            if BRAILLE_RE.search(sample):
                routes["braille"].append(str(p))
            if ARABIC_RE.search(sample):
                routes["arabic"].append(str(p))
            routes["text"].append(str(p))

    return routes
