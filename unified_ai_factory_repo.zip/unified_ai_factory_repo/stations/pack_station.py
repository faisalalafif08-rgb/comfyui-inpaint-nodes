# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path

TEXTLIKE_EXTS = {".txt", ".md", ".csv", ".log", ".json", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cpp", ".c", ".h", ".go", ".rs", ".swift"}
SEP = "\n" + "_"*10 + "\n"

def pack_files(files: list[str], batch_dir: Path, out_name: str = "PACK_ALL.txt") -> Path:
    out_dir = batch_dir / "stations_out" / "pack"
    out_dir.mkdir(parents=True, exist_ok=True)

    out_path = out_dir / out_name
    chunks = []

    for fp in files:
        p = Path(fp)
        if p.suffix.lower() not in TEXTLIKE_EXTS:
            continue
        try:
            content = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        chunks.append(f"{p.name}\n{content.rstrip()}{SEP}")

    out_path.write_text("".join(chunks), encoding="utf-8")
    return out_path
