# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import zipfile, shutil, json, hashlib

def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def ingest_to_bundle(input_path: Path, batch_dir: Path):
    """Folder/Zip/File -> bundle.zip + manifest.json"""
    work = batch_dir / "__ingest_work__"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)

    temp_root = work / "root"
    temp_root.mkdir(parents=True, exist_ok=True)

    if input_path.is_dir():
        shutil.copytree(input_path, temp_root, dirs_exist_ok=True)
        mode = "folder"
    elif input_path.is_file() and input_path.suffix.lower() == ".zip":
        with zipfile.ZipFile(input_path, "r") as z:
            z.extractall(temp_root)
        mode = "zip"
    else:
        shutil.copy2(input_path, temp_root / input_path.name)
        mode = "file"

    files = [p for p in temp_root.rglob("*") if p.is_file()]

    manifest = {"source": str(input_path), "mode": mode, "file_count": len(files), "files": []}

    for p in files:
        rel = str(p.relative_to(temp_root)).replace("\\", "/")
        manifest["files"].append({
            "rel": rel,
            "name": p.name,
            "ext": p.suffix.lower(),
            "size": p.stat().st_size,
            "sha256": _sha256(p),
        })

    bundle_zip = batch_dir / "bundle.zip"
    if bundle_zip.exists():
        bundle_zip.unlink()
    with zipfile.ZipFile(bundle_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:
            rel = str(p.relative_to(temp_root)).replace("\\", "/")
            z.write(p, arcname=rel)

    manifest_path = batch_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    shutil.rmtree(work, ignore_errors=True)
    return bundle_zip, manifest_path
