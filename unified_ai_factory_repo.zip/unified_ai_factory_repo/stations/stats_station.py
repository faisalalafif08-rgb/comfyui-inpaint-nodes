# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import re, json
from collections import Counter, defaultdict

STOP_EN = {"the","a","an","and","or","to","of","in","on","for","with","is","are","was","were","be","as","at","by","it","this","that","from"}
STOP_AR = {"في","على","من","الى","إلى","عن","مع","هذا","هذه","ذلك","تلك","و","او","أو","هو","هي","كان","كانت","يكون","تكون","تم","ما","لا","نعم","كل","أي"}

RE_CODE_IDENT = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]{2,}\b")
RE_AR_WORD     = re.compile(r"[\u0600-\u06FF]{2,}")
RE_EN_WORD     = re.compile(r"\b[a-zA-Z]{3,}\b")

def _normalize_token(t: str) -> str:
    return t.strip().lower()

def extract_concepts(text: str) -> list[str]:
    toks = []
    toks += RE_CODE_IDENT.findall(text)
    toks += RE_EN_WORD.findall(text)
    toks += RE_AR_WORD.findall(text)
    out = []
    for t in toks:
        nt = _normalize_token(t)
        if not nt or nt.isdigit():
            continue
        if nt in STOP_EN or nt in STOP_AR:
            continue
        out.append(nt)
    return out

def build_stats(files: list[str], batch_dir: Path, top_k_terms: int = 400, top_k_per_file: int = 80) -> Path:
    out_dir = batch_dir / "stations_out" / "stats"
    out_dir.mkdir(parents=True, exist_ok=True)

    global_counter = Counter()
    per_file_counter = defaultdict(Counter)
    edges = []

    for fp in files:
        p = Path(fp)
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        concepts = extract_concepts(text)
        if not concepts:
            continue
        c = Counter(concepts)
        per_file_counter[p.name] = c
        global_counter.update(c)
        for concept, w in c.most_common(top_k_per_file):
            edges.append({"file": p.name, "concept": concept, "weight": int(w)})

    top_terms = [{"term": t, "count": int(n)} for t, n in global_counter.most_common(top_k_terms)]
    (out_dir / "db_terms.json").write_text(json.dumps(top_terms, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "db_edges.json").write_text(json.dumps(edges, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "report.json").write_text(json.dumps({
        "station": "stats",
        "files_scanned": len(files),
        "files_with_terms": len(per_file_counter),
        "unique_terms": len(global_counter),
        "top10": top_terms[:10],
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_dir
