# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import json, re
from collections import Counter

IDENT_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]{2,}\b")

def run_code_station(files: list[str], batch_dir: Path) -> Path:
    out = batch_dir / "stations_out" / "code"
    out.mkdir(parents=True, exist_ok=True)

    idents = Counter()
    readmes = []

    for fp in files:
        p = Path(fp)
        txt = p.read_text(encoding="utf-8", errors="replace")
        for tok in IDENT_RE.findall(txt):
            idents[tok.lower()] += 1
        if p.name.lower() in {"readme.md","readme.txt"}:
            readmes.append(f"### {p.name}\n{txt}\n")

    (out / "readmes.txt").write_text("\n\n".join(readmes), encoding="utf-8")
    top = [{"ident":t,"count":c} for t,c in idents.most_common(300)]
    (out / "report.json").write_text(json.dumps({"station":"code","files":len(files),"top_idents":top[:30]}, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
