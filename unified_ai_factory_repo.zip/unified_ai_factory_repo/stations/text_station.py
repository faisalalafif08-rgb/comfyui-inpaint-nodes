# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import re, json

BRAILLE_RE = re.compile(r"[\u2800-\u28FF]")
ARABIC_RE  = re.compile(r"[\u0600-\u06FF]")

def classify_line(line: str) -> str:
    if BRAILLE_RE.search(line): return "braille"
    if ARABIC_RE.search(line):  return "arabic"
    if re.search(r"[A-Za-z]", line): return "latin"
    return "other"

def run_text_station(files: list[str], batch_dir: Path) -> Path:
    out = batch_dir / "stations_out" / "text"
    out.mkdir(parents=True, exist_ok=True)

    buckets = {"latin": [], "arabic": [], "braille": [], "other": []}
    for fp in files:
        p = Path(fp)
        txt = p.read_text(encoding="utf-8", errors="replace")
        for raw in txt.splitlines():
            s = raw.strip()
            if not s:
                continue
            buckets[classify_line(s)].append(s)

    for k, v in buckets.items():
        (out / f"{k}.txt").write_text("\n".join(v), encoding="utf-8")

    counts = {k: len(v) for k, v in buckets.items()}
    (out / "report.json").write_text(json.dumps({"station":"text","files":len(files),"counts":counts}, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
