# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import sqlite3, json, time
from collections import Counter, defaultdict

def _connect(db_path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(db_path))
    con.execute("PRAGMA journal_mode=WAL;")
    con.execute("PRAGMA synchronous=NORMAL;")
    return con

def _init_schema(con: sqlite3.Connection):
    con.executescript("""
    CREATE TABLE IF NOT EXISTS batches(
      batch_id TEXT PRIMARY KEY,
      created_at TEXT,
      source TEXT
    );

    CREATE TABLE IF NOT EXISTS terms(
      term_id INTEGER PRIMARY KEY AUTOINCREMENT,
      lang TEXT,
      norm TEXT,
      first_seen_batch TEXT,
      total_count INTEGER DEFAULT 0,
      UNIQUE(lang, norm)
    );

    CREATE TABLE IF NOT EXISTS file_terms(
      batch_id TEXT,
      file TEXT,
      lang TEXT,
      term_norm TEXT,
      count INTEGER,
      PRIMARY KEY(batch_id, file, lang, term_norm)
    );

    CREATE TABLE IF NOT EXISTS cooccur(
      lang TEXT,
      a TEXT,
      b TEXT,
      weight INTEGER,
      PRIMARY KEY(lang, a, b)
    );
    """)

def ingest_edges_json(con: sqlite3.Connection, batch_id: str, edges_path: Path):
    edges = json.loads(edges_path.read_text(encoding="utf-8"))
    for e in edges:
        file = e["file"]
        term = e["concept"]
        w = int(e["weight"])
        lang = "ar" if any("\u0600" <= ch <= "\u06FF" for ch in term) else "en"
        con.execute("INSERT OR REPLACE INTO file_terms(batch_id,file,lang,term_norm,count) VALUES(?,?,?,?,?)",
                    (batch_id, file, lang, term, w))

def upsert_terms(con: sqlite3.Connection, batch_id: str):
    rows = con.execute("SELECT lang, term_norm, SUM(count) FROM file_terms WHERE batch_id=? GROUP BY lang, term_norm",
                       (batch_id,)).fetchall()
    new_terms = 0
    for lang, norm, cnt in rows:
        r = con.execute("SELECT total_count FROM terms WHERE lang=? AND norm=?", (lang, norm)).fetchone()
        if r is None:
            con.execute("INSERT INTO terms(lang,norm,first_seen_batch,total_count) VALUES(?,?,?,?)",
                        (lang, norm, batch_id, int(cnt)))
            new_terms += 1
        else:
            con.execute("UPDATE terms SET total_count = total_count + ? WHERE lang=? AND norm=?", (int(cnt), lang, norm))
    return new_terms

def infer_cooccurrence(con: sqlite3.Connection, batch_id: str, min_shared_files: int = 2):
    cur = con.execute("SELECT file, lang, term_norm FROM file_terms WHERE batch_id=?", (batch_id,))
    per_file = defaultdict(set)
    for file, lang, term in cur.fetchall():
        per_file[(file, lang)].add(term)

    pair_counter = Counter()
    for (file, lang), terms in per_file.items():
        terms = sorted(terms)
        for i in range(len(terms)):
            for j in range(i+1, len(terms)):
                pair_counter[(lang, terms[i], terms[j])] += 1

    new_links = 0
    for (lang, a, b), shared in pair_counter.items():
        if shared < min_shared_files:
            continue
        r = con.execute("SELECT weight FROM cooccur WHERE lang=? AND a=? AND b=?", (lang, a, b)).fetchone()
        if r is None:
            con.execute("INSERT INTO cooccur(lang,a,b,weight) VALUES(?,?,?,?)", (lang, a, b, int(shared)))
            new_links += 1
        else:
            con.execute("UPDATE cooccur SET weight = weight + ? WHERE lang=? AND a=? AND b=?", (int(shared), lang, a, b))
    return new_links

def run_knowledge_station(batch_dir: Path, batch_id: str, source: str):
    edges_path = batch_dir / "stations_out" / "stats" / "db_edges.json"
    if not edges_path.exists():
        raise FileNotFoundError(f"Missing stats edges: {edges_path}")

    out = batch_dir / "stations_out" / "knowledge"
    out.mkdir(parents=True, exist_ok=True)
    db_path = out / "knowledge.db"

    con = _connect(db_path)
    _init_schema(con)
    con.execute("INSERT OR REPLACE INTO batches(batch_id,created_at,source) VALUES(?,?,?)",
                (batch_id, time.strftime("%Y-%m-%d %H:%M:%S"), source))

    ingest_edges_json(con, batch_id, edges_path)
    new_terms = upsert_terms(con, batch_id)
    new_links = infer_cooccurrence(con, batch_id, min_shared_files=2)

    con.commit()
    con.close()

    rep = {"batch_id": batch_id, "time": time.strftime("%Y-%m-%d %H:%M:%S"), "new_terms": new_terms, "new_cooccur_links": new_links}
    (out / "expansion_report.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
