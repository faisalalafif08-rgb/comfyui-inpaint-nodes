# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import re, json
from collections import Counter

ARABIC_RE = re.compile(r"[\u0600-\u06FF]")
TASHKEEL_RE = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")

def normalize_arabic(s: str) -> str:
    s = TASHKEEL_RE.sub("", s)
    s = s.replace("أ","ا").replace("إ","ا").replace("آ","ا")
    s = s.replace("ة","ه").replace("ى","ي")
    return s

def run_arabic_station(files: list[str], batch_dir: Path) -> Path:
    out = batch_dir / "stations_out" / "arabic"
    out.mkdir(parents=True, exist_ok=True)

    tokens = Counter()
    collected = []

    for fp in files:
        txt = Path(fp).read_text(encoding="utf-8", errors="replace")
        lines = [ln.strip() for ln in txt.splitlines() if ARABIC_RE.search(ln)]
        if not lines:
            continue
        block = "\n".join(lines)
        collected.append(block)
        norm = normalize_arabic(block)
        for t in re.findall(r"[\u0600-\u06FF]{2,}", norm):
            tokens[t] += 1

    (out / "arabic_all.txt").write_text("\n\n".join(collected), encoding="utf-8")
    top = [{"term":t,"count":c} for t,c in tokens.most_common(200)]
    (out / "report.json").write_text(json.dumps({"station":"arabic","files":len(files),"top_terms":top[:20]}, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
