# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import json

def aggregate_reports(station_dirs: list[Path], batch_dir: Path) -> Path:
    out = batch_dir / "stations_out" / "aggregate"
    out.mkdir(parents=True, exist_ok=True)

    summary = {"stations": [str(Path(d)) for d in station_dirs]}
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
