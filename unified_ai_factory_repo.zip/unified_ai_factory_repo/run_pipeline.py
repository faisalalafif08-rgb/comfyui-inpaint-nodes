# -*- coding: utf-8 -*-
from pathlib import Path
import argparse

from stations.ingest_station import ingest_to_bundle
from stations.index_station import index_bundle
from stations.route_station import route_items

from stations.text_station import run_text_station
from stations.braille_station import run_braille_station
from stations.arabic_station import run_arabic_station
from stations.code_station import run_code_station

from stations.pack_station import pack_files
from stations.stats_station import build_stats
from stations.knowledge_station import run_knowledge_station
from stations.aggregate_station import aggregate_reports

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="file/folder/zip")
    ap.add_argument("--vault", default="vault", help="storage root")
    args = ap.parse_args()

    inp = Path(args.input).expanduser().resolve()
    vault = Path(args.vault).expanduser().resolve()
    batch_dir = vault / inp.stem
    batch_dir.mkdir(parents=True, exist_ok=True)

    bundle_zip, _manifest = ingest_to_bundle(inp, batch_dir)
    index = index_bundle(bundle_zip, batch_dir)
    routes = route_items(index)

    station_dirs = []

    if routes["text"]:
        station_dirs.append(run_text_station(routes["text"], batch_dir))
    if routes["braille"]:
        station_dirs.append(run_braille_station(routes["braille"], batch_dir))
    if routes["arabic"]:
        station_dirs.append(run_arabic_station(routes["arabic"], batch_dir))
    if routes["code"]:
        station_dirs.append(run_code_station(routes["code"], batch_dir))

    pack_files(routes["text"] + routes["code"], batch_dir)
    station_dirs.append(build_stats(routes["text"] + routes["code"], batch_dir))
    station_dirs.append(run_knowledge_station(batch_dir, batch_id=inp.stem, source=str(inp)))

    station_dirs.append(aggregate_reports(station_dirs, batch_dir))

    print("✅ Pipeline complete:", batch_dir)

if __name__ == "__main__":
    main()
