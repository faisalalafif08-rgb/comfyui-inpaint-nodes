Unified AI Factory (Stations)
Run:
  python run_pipeline.py <input_path>
Outputs:
  vault/<batch>/stations_out/
Includes Pack + Stats + Knowledge(SQLite)
