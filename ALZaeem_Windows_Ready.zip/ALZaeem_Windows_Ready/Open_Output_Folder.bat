@echo off
cd /d "%~dp0\output"
start .
