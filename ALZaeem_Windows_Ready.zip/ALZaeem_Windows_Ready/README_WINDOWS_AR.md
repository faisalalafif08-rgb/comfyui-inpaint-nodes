# ALZaeem Windows Ready

هذه النسخة مرتبة خصيصًا لويندوز، وبداخلها ملفات تشغيل مباشرة.

## الملفات المهمة
- `Run_ALZaeem_Windows.bat`
  يشغل نظام ALZaeem المحلي مباشرة.
- `Setup_And_Run_Fooocus_Windows.bat`
  ينشئ بيئة Python داخل مجلد Fooocus ثم يثبت الاعتمادات ويشغله.
- `Open_Output_Folder.bat`
  يفتح مجلد المخرجات.
- `main.py`
  ملف النظام النصي الرئيسي.
- `optional_fooocus_source`
  مصدر Fooocus المرفق.

## تشغيل ALZaeem على ويندوز
1. ثبّت Python 3 على ويندوز.
2. أثناء التثبيت فعّل خيار:
   `Add python.exe to PATH`
3. افتح الملف:
   `Run_ALZaeem_Windows.bat`

## تشغيل Fooocus على ويندوز
1. يفضّل Python 3.10.
2. افتح الملف:
   `Setup_And_Run_Fooocus_Windows.bat`
3. في أول تشغيل سيتم:
   - إنشاء venv
   - تثبيت الاعتمادات من `requirements_versions.txt`
   - تشغيل `entry_with_update.py`

## ملاحظات مهمة
- نظام **ALZaeem** لا يحتاج مكتبات خارجية خاصة.
- **Fooocus** قد يحتاج كرت شاشة مناسب، ويفضّل NVIDIA بذاكرة 4GB أو أكثر.
- أول تشغيل لـ Fooocus قد يكون أبطأ من المعتاد.
- لا أستطيع تثبيت الملفات داخل جهازك من هنا، لكن هذه الحزمة جاهزة لتفك الضغط ثم التشغيل.

## تجربة سريعة لـ ALZaeem
بعد تشغيل النظام اكتب مثلًا:
`أنشئ مقدمة سينمائية لشخصية أنثوية واثقة بإضاءة ناعمة`

## أين تخرج الملفات؟
- الصوت التجريبي:
  `output/audio_mock.txt`
- سجل الشخصيات:
  `output/characters/registry.json`
- الذاكرة:
  `output/pattern_memory.json`
