@echo off
setlocal
cd /d "%~dp0\optional_fooocus_source"
title Fooocus - Windows Setup and Run

echo ==========================================
echo      Fooocus Windows Setup and Run
echo ==========================================
echo.
echo Notes:
echo - Recommended: Python 3.10
echo - Recommended: NVIDIA GPU with at least 4GB VRAM
echo - First run may take time to install packages and models
echo.

set PY_CMD=
where py >nul 2>nul
if %errorlevel%==0 (
    py -3.10 -V >nul 2>nul
    if %errorlevel%==0 (
        set PY_CMD=py -3.10
    ) else (
        py -3 -V >nul 2>nul
        if %errorlevel%==0 set PY_CMD=py -3
    )
)

if not defined PY_CMD (
    where python >nul 2>nul
    if %errorlevel%==0 set PY_CMD=python
)

if not defined PY_CMD (
    echo [ERROR] Python was not found.
    echo Install Python 3.10 if possible, then run this file again.
    echo Make sure "Add python.exe to PATH" is enabled.
    echo.
    pause
    exit /b 1
)

echo Using Python command: %PY_CMD%
echo.

if not exist venv (
    echo Creating virtual environment...
    %PY_CMD% -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create venv.
        echo Try installing Python 3.10, then run again.
        echo.
        pause
        exit /b 1
    )
)

call venv\Scripts\activate
if errorlevel 1 (
    echo [ERROR] Failed to activate venv.
    echo.
    pause
    exit /b 1
)

echo Upgrading pip...
python -m pip install --upgrade pip

echo Installing Fooocus requirements...
pip install -r requirements_versions.txt
if errorlevel 1 (
    echo [ERROR] Requirements installation failed.
    echo.
    echo Possible reasons:
    echo - Unsupported Python version
    echo - Network issue while downloading packages
    echo - Missing Microsoft Visual C++ runtime
    echo.
    pause
    exit /b 1
)

echo Starting Fooocus...
python entry_with_update.py
echo.
pause
endlocal
