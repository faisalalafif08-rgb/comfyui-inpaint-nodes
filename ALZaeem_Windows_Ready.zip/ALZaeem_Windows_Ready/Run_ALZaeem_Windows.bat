@echo off
setlocal
cd /d "%~dp0"
title ALZaeem - Windows Launcher

echo ==========================================
echo          ALZaeem Local System
echo ==========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 main.py
    goto end
)

where python >nul 2>nul
if %errorlevel%==0 (
    python main.py
    goto end
)

echo [ERROR] Python is not installed or not added to PATH.
echo Please install Python 3 from the official website, then run this file again.
echo During installation, enable: Add python.exe to PATH
echo.
:end
echo.
pause
endlocal
