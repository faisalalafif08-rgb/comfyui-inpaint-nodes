AI_ALGO_CAPABILITIES = [
  {
    "chapter": 1,
    "page_range": "15-44",
    "title": "طرق ومستويات معالجة اللغة في الذكاء الاصطناعي",
    "capability_id": "language_processing_levels",
    "runner": "projects.language_processing_levels.run_chapter_01"
  },
  {
    "chapter": 2,
    "page_range": "45-68",
    "title": "التعلم العميق وتطبيقاته في معالجة اللغة",
    "capability_id": "deep_learning_for_arabic_nlp",
    "runner": "projects.deep_learning_for_arabic_nlp.run_chapter_02"
  },
  {
    "chapter": 3,
    "page_range": "69-94",
    "title": "الترجمة الآلية",
    "capability_id": "machine_translation_brain",
    "runner": "projects.machine_translation_brain.run_chapter_03"
  },
  {
    "chapter": 4,
    "page_range": "95-124",
    "title": "نمذجة الكلمة العربية",
    "capability_id": "arabic_word_modeling",
    "runner": "projects.arabic_word_modeling.run_chapter_04"
  },
  {
    "chapter": 5,
    "page_range": "125-175",
    "title": "المتلازمات اللفظية والتراكيب الاصطلاحية",
    "capability_id": "arabic_multiword_expression_brain",
    "runner": "projects.arabic_multiword_expression_brain.run_chapter_05"
  }
]
def list_capabilities(): return AI_ALGO_CAPABILITIES
