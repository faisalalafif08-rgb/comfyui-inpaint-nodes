AI_ALGO_ROUTE_TABLE = {
  "language_processing_levels": {
    "chapter": 1,
    "runner": "projects.language_processing_levels.run_chapter_01.run_chapter_01",
    "input_key": "text",
    "safe": true,
    "heavy": false
  },
  "deep_learning_for_arabic_nlp": {
    "chapter": 2,
    "runner": "projects.deep_learning_for_arabic_nlp.run_chapter_02.run_chapter_02",
    "input_key": "text",
    "safe": true,
    "heavy": true
  },
  "machine_translation_brain": {
    "chapter": 3,
    "runner": "projects.machine_translation_brain.run_chapter_03.run_chapter_03",
    "input_key": "text",
    "safe": true,
    "heavy": true
  },
  "arabic_word_modeling": {
    "chapter": 4,
    "runner": "projects.arabic_word_modeling.run_chapter_04.run_chapter_04",
    "input_key": "text",
    "safe": true,
    "heavy": true
  },
  "arabic_multiword_expression_brain": {
    "chapter": 5,
    "runner": "projects.arabic_multiword_expression_brain.run_chapter_05.run_chapter_05",
    "input_key": "text",
    "safe": true,
    "heavy": true
  }
}
