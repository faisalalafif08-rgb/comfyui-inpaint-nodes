"""AI Arabic Text Analysis Capability Pack."""
