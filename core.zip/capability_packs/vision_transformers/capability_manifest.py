VIT_CAPABILITIES = [
  {
    "chapter": 0,
    "page_range": "intro",
    "title": "Introduction to Vision Transformers",
    "capability_id": "vit_foundations"
  },
  {
    "chapter": 1,
    "page_range": "architecture",
    "title": "What ViT Is and How It Works",
    "capability_id": "vit_architecture_explainer"
  },
  {
    "chapter": 2,
    "page_range": "31-38",
    "title": "Comparison of CNNs and Vision Transformers",
    "capability_id": "vit_vs_cnn"
  },
  {
    "chapter": 3,
    "page_range": "39-53",
    "title": "Understand Vision Transformers with TensorFlow",
    "capability_id": "vit_tensorflow_intro"
  },
  {
    "chapter": 4,
    "page_range": "54-58",
    "title": "Understanding ViT with TensorFlow and Keras",
    "capability_id": "vit_keras_cifar100"
  },
  {
    "chapter": 5,
    "page_range": "59-70",
    "title": "Object Detection using Vision Transformers",
    "capability_id": "vit_object_detection"
  },
  {
    "chapter": 6,
    "page_range": "71-76",
    "title": "Handwritten Digit Recognition using ViT",
    "capability_id": "vit_digit_recognition"
  },
  {
    "chapter": 7,
    "page_range": "77-91",
    "title": "Image Classification using Vision Transformers",
    "capability_id": "vit_image_classification"
  },
  {
    "chapter": 8,
    "page_range": "92-106",
    "title": "Food Classification using Vision Transformers",
    "capability_id": "vit_food_classification"
  },
  {
    "chapter": 9,
    "page_range": "107-114",
    "title": "Satellite Image Classification using Vision Transformers",
    "capability_id": "vit_satellite_classification"
  },
  {
    "chapter": 10,
    "page_range": "115-125",
    "title": "Medical Image Classification using Vision Transformers",
    "capability_id": "vit_medical_image_classification"
  },
  {
    "chapter": 11,
    "page_range": "bridge",
    "title": "General Mind + Data + PDF Extraction Bridge",
    "capability_id": "vit_general_mind_bridge"
  }
]
def list_capabilities(): return VIT_CAPABILITIES
