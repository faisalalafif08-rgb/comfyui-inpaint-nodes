# Vision Transformers Delivery Index
