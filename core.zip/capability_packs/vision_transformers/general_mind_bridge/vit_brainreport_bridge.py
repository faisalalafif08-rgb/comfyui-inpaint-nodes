from dataclasses import dataclass, field
from typing import Any
@dataclass
class ViTBrainReport:
    brain_name: str; capability_id: str; source_type: str; content_type: str; task_type: str; confidence: float=0.0; decision_request: str='review'; findings: list[dict[str,Any]]=field(default_factory=list); errors: list[dict[str,Any]]=field(default_factory=list); recommendations: list[str]=field(default_factory=list); metadata: dict[str,Any]=field(default_factory=dict)
    def to_learning_mind_report(self): return self.__dict__
