from dataclasses import dataclass, field
from typing import Any
@dataclass
class VisionUnifiedUnit:
    unit_type: str; text: str|None=None; image_path: str|None=None; page_number: int|None=None; region: dict[str,Any]=field(default_factory=dict); metadata: dict[str,Any]=field(default_factory=dict)
    def to_dict(self): return self.__dict__
@dataclass
class VisionUnifiedContent:
    source_file: str; source_type: str; content_type: str; units: list[VisionUnifiedUnit]; metadata: dict[str,Any]=field(default_factory=dict)
    def to_learning_mind_payload(self): return {"source_file":self.source_file,"source_type":self.source_type,"content_type":self.content_type,"units":[u.to_dict() for u in self.units],"metadata":self.metadata}
