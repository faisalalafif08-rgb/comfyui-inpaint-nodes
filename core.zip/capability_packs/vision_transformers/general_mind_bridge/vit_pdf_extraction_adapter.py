class ViTPDFExtractionAdapter:
    def adapt_pdf_result(self, pdf_result: dict) -> dict:
        units=[]
        for page in pdf_result.get('pages', pdf_result.get('units', [])):
            n=page.get('page_number') or page.get('unit_number')
            if page.get('text'): units.append({'unit_type':'pdf_text_page','text':page.get('text'),'page_number':n,'metadata':page.get('metadata',{})})
            if page.get('image_path'): units.append({'unit_type':'pdf_page_image','image_path':page.get('image_path'),'page_number':n,'metadata':{'requires_vision_analysis':True}})
        return {'source_file':pdf_result.get('source_file'),'source_type':'pdf','content_type':'mixed_pdf_visual_text','units':units,'metadata':{'adapter':'ViTPDFExtractionAdapter'}}
