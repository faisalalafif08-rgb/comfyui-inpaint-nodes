class ViTErrorMemoryAdapter:
    def build_error_record(self, source_file, error_origin, wrong_output, expected_output=None, page_number=None, region=None, confidence=0.0, metadata=None):
        return {'source_file':source_file,'error_origin':error_origin,'wrong_output':wrong_output,'expected_output':expected_output,'page_number':page_number,'region':region or {},'confidence':confidence,'metadata':metadata or {},'decision_request':'review'}
