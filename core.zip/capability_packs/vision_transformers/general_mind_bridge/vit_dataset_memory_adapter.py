class ViTDatasetMemoryAdapter:
    def build_dataset_record(self, dataset_id, task_type, source_path, classes=None, image_shape=None, metadata=None):
        return {'record_type':'vision_dataset','dataset_id':dataset_id,'task_type':task_type,'source_path':source_path,'classes':classes or [],'image_shape':image_shape,'metadata':metadata or {},'learning_targets':['dataset_readiness','vision_task_routing','model_selection','error_analysis']}
