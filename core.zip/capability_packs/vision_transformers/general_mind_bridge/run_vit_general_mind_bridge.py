from .vit_pdf_extraction_adapter import ViTPDFExtractionAdapter
from .vit_dataset_memory_adapter import ViTDatasetMemoryAdapter
from .vit_brainreport_bridge import ViTBrainReport
from .vit_learning_commit import ViTLearningCommit

def run_vit_general_mind_bridge(pdf_result=None):
    unified = ViTPDFExtractionAdapter().adapt_pdf_result(pdf_result) if pdf_result else {'source_file':'manual_input','source_type':'manual','content_type':'vision_transformer_methodology','units':[],'metadata':{}}
    dataset = ViTDatasetMemoryAdapter().build_dataset_record('vit_capability_pack_sources','vision_transformer_training_and_analysis','capability_packs/vision_transformers/runtime/data',metadata={'supports_pdf_extraction':True,'supports_ocr':True})
    report = ViTBrainReport('Vision Transformer Brain','vision_transformers',unified['source_type'],unified['content_type'],'general_vision_understanding',0.80,'review',[{'type':'integration','message':'ViT capability pack is ready to feed Learning Mind Core.'}],[],['Use Decision Gate before promoting any model result.']).to_learning_mind_report()
    return ViTLearningCommit().commit(unified, report, dataset_records=[dataset])
if __name__=='__main__':
    import json; print(json.dumps(run_vit_general_mind_bridge(), ensure_ascii=False, indent=2))
