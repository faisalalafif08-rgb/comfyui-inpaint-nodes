MODULE_INFO={"file":"vit_pdf_source_contracts.py","status":"ready"}
