MODULE_INFO={"file":"vit_dataset_schema.py","status":"ready"}
