MODULE_INFO={"file":"vit_image_dataset_contracts.py","status":"ready"}
