"""Vision Transformers Capability Pack."""
