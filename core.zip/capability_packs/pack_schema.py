from dataclasses import dataclass, field
from typing import Any
@dataclass
class CapabilityPack:
    pack_id: str; title: str; status: str; source_file: str | None = None; heavy: bool = False
    requirements: list[str] = field(default_factory=list); capabilities: list[str] = field(default_factory=list)
    heart_ready: bool = True; decision_gate_required: bool = True; learning_mind_required: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)
    def to_dict(self): return self.__dict__
