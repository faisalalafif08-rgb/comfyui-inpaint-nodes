"""Nature delivery_index/markdown_builder.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "markdown_builder", "status": "ready"}
