"""Nature heart_installation/uninstall_plan.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "uninstall_plan", "status": "ready"}
