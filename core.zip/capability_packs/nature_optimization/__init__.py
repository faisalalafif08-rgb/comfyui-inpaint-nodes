"""Nature Optimization Capability Pack - frozen final manifest."""
