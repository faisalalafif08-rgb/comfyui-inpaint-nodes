"""Nature portable_export/install_instructions.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "install_instructions", "status": "ready"}
