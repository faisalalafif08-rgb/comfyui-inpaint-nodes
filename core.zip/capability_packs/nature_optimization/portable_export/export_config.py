"""Nature portable_export/export_config.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "export_config", "status": "ready"}
