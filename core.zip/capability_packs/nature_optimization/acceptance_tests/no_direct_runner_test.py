"""Nature acceptance_tests/no_direct_runner_test.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "no_direct_runner_test", "status": "ready"}
