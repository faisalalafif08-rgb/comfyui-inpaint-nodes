"""Nature mock_runners/mock_payloads.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "mock_payloads", "status": "ready"}
