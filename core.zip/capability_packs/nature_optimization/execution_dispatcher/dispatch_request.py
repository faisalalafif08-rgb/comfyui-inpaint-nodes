"""Nature execution_dispatcher/dispatch_request.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "dispatch_request", "status": "ready"}
