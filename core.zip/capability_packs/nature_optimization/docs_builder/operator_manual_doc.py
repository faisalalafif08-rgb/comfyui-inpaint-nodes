"""Nature docs_builder/operator_manual_doc.py
Generated complete curriculum file.
Heavy execution is routed through Heart / Execution Gate.
"""

from __future__ import annotations

def info() -> dict:
    return {"file": __file__, "module": "operator_manual_doc", "status": "ready"}
