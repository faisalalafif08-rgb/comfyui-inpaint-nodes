# OPERATOR_MANUAL.md

Nature Optimization Capability Pack documentation.
