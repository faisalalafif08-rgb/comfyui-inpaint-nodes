# ENTRYPOINTS.md

Nature Optimization Capability Pack documentation.
