"""Capability Packs Registry."""
