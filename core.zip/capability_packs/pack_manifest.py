from .pack_schema import CapabilityPack
CAPABILITY_PACKS = [
    CapabilityPack("ai_arabic_text_analysis", "خوارزميات الذكاء الاصطناعي في تحليل النص العربي", "complete_heart_ready", "Ai-algo.pdf", False, ["requirements-core.txt","requirements-nlp.txt"], ['language_processing_levels', 'deep_learning_for_arabic_nlp', 'machine_translation_brain', 'arabic_word_modeling', 'arabic_multiword_expression_brain']),
    CapabilityPack("vision_transformers", "محولات الرؤية", "general_mind_ready", "محولات الرؤية.pdf", True, ["requirements-core.txt","requirements-vision.txt","requirements-deep-tensorflow.txt"], ['vit_foundations', 'vit_architecture_explainer', 'vit_vs_cnn', 'vit_tensorflow_intro', 'vit_keras_cifar100', 'vit_object_detection', 'vit_digit_recognition', 'vit_image_classification', 'vit_food_classification', 'vit_satellite_classification', 'vit_medical_image_classification', 'vit_general_mind_bridge']),
    CapabilityPack("nature_optimization", "تحسين شبكات التعلم العميق بالخوارزميات المستوحاة من الطبيعة", "frozen_final", "تحسين-شبكات-التعلم-العميق.pdf", True, ["requirements-optimization.txt","requirements-deep-torch.txt"], ["hyponic_optimizer_comparison", "gwo_feature_selection", "binary_bat_feature_extraction"]),
]
def list_capability_packs(): return [p.to_dict() for p in CAPABILITY_PACKS]
