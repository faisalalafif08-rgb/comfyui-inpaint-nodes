CAPABILITIES = [
 "pos_tagger", "arabic_preprocessing", "datasets_registry", "sentiment_ml", "tweet_sentiment",
 "poem_generation", "nizar_generation", "quran_topic_modeling", "news_topic_classification",
 "books_classification", "text_summarization", "twitter_bot", "handwritten_digits",
 "handwritten_characters", "keras_tuner_arabic_mnist", "social_pulse"
]
