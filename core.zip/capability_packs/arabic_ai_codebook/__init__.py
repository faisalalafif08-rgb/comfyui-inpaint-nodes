"""Arabic AI Codebook Capability Pack."""
