from .pack_manifest import CAPABILITY_PACKS
class CapabilityPackRegistry:
    def __init__(self): self.packs=CAPABILITY_PACKS
    def list_packs(self): return [p.to_dict() for p in self.packs]
    def find_by_capability(self, capability_id: str):
        for p in self.packs:
            if capability_id in p.capabilities: return p.to_dict()
        return None
    def list_capabilities(self):
        return [{"capability_id": c, "pack_id": p.pack_id, "pack_title": p.title, "heavy": p.heavy, "status": p.status} for p in self.packs for c in p.capabilities]
