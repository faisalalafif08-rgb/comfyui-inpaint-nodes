from .file_gateway import FileGateway
class InterfaceGateway:
    gateway_name='InterfaceGateway'
    def __init__(self): self.file_gateway=FileGateway()
    def upload_file_command(self, file_path, source_role='knowledge_source'):
        return self.file_gateway.ingest_file(file_path, source_role).to_dict()
