from dataclasses import dataclass, field
from typing import Any
@dataclass
class GatewayResult:
    ok: bool; status: str; gateway_name: str; scan_record: dict[str,Any]=field(default_factory=dict); route: dict[str,Any]=field(default_factory=dict); fxs_result: dict[str,Any]=field(default_factory=dict); warnings: list[str]=field(default_factory=list); errors: list[str]=field(default_factory=list)
    def to_dict(self): return self.__dict__
