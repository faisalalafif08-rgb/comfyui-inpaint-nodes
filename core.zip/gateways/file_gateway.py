from filescanner.filescanner import FileScanner
from systems.fxs.fxs_engine import FXSEngine
from systems.fxs.fxs_request import FXSRequest
from .gateway_result import GatewayResult
class FileGateway:
    gateway_name='FileGateway'
    def __init__(self): self.scanner=FileScanner(); self.fxs=FXSEngine()
    def ingest_file(self, file_path, source_role='knowledge_source'):
        scan=self.scanner.scan(file_path)
        if not scan.is_supported: return GatewayResult(False,'unsupported_or_missing_file',self.gateway_name,scan.to_dict(),errors=scan.errors or ['unsupported_file_type'])
        req=FXSRequest(file_path, scan.file_type, scan.route_hint or '', scan.to_dict(), {'source_role':source_role})
        res=self.fxs.process(req)
        return GatewayResult(res.ok,'ingested_through_file_gateway',self.gateway_name,scan.to_dict(),{'route_hint':scan.route_hint,'file_type':scan.file_type},res.to_dict(),scan.warnings+res.warnings,scan.errors+res.errors)
