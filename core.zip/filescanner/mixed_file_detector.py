def detect_mixed_file(path): return {"is_mixed": False, "mixed_kind": None, "notes": []}
