import json
from pathlib import Path
class DuplicateDetector:
    def __init__(self, registry_path='registry/file_state_registry.json'):
        self.registry_path=Path(registry_path); self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.registry_path.exists(): self.registry_path.write_text(json.dumps({'files':[]}, ensure_ascii=False, indent=2), encoding='utf-8')
    def load(self): return json.loads(self.registry_path.read_text(encoding='utf-8'))
    def save(self, data): self.registry_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    def is_duplicate(self, sha256): return any(x.get('sha256')==sha256 for x in self.load().get('files',[]))
    def register(self, record):
        data=self.load();
        if not self.is_duplicate(record['sha256']): data.setdefault('files',[]).append(record); self.save(data)
