from dataclasses import dataclass, field
from typing import Any
@dataclass
class ScanRecord:
    file_path: str; file_name: str; file_type: str; extension: str; size_bytes: int; sha256: str
    is_duplicate: bool=False; is_mixed: bool=False; is_supported: bool=True; route_hint: str|None=None
    warnings: list[str]=field(default_factory=list); errors: list[str]=field(default_factory=list); metadata: dict[str, Any]=field(default_factory=dict)
    def to_dict(self): return self.__dict__
