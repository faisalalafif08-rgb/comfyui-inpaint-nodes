from pathlib import Path
FILE_TYPE_BY_EXTENSION={'.txt':'txt','.pdf':'pdf','.docx':'docx','.xlsx':'xlsx','.xls':'xlsx','.csv':'csv','.png':'image','.jpg':'image','.jpeg':'image','.webp':'image','.mp3':'audio','.wav':'audio','.m4a':'audio','.mp4':'video','.mov':'video','.py':'python','.json':'json','.md':'markdown'}
def detect_file_type(path):
    ext=Path(path).suffix.lower(); ft=FILE_TYPE_BY_EXTENSION.get(ext,'unknown')
    return {'extension':ext,'file_type':ft,'is_supported':ft!='unknown'}
def route_hint_for_type(file_type): return {'pdf':'systems.fxs.pdf','txt':'systems.fxs.text','image':'systems.fxs.image','docx':'systems.fxs.document','xlsx':'systems.fxs.table','csv':'systems.fxs.table'}.get(file_type,'systems.fxs.unsupported')
