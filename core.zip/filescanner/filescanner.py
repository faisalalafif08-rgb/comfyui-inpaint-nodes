from pathlib import Path
from .scan_record import ScanRecord
from .file_type_detector import detect_file_type, route_hint_for_type
from .file_hasher import sha256_file
from .mixed_file_detector import detect_mixed_file
from .duplicate_detector import DuplicateDetector
class FileScanner:
    def __init__(self, registry_path='registry/file_state_registry.json'): self.duplicates=DuplicateDetector(registry_path)
    def scan(self, path, register=True):
        p=Path(path)
        if not p.exists(): return ScanRecord(str(p), p.name, 'unknown', p.suffix.lower(), 0, '', is_supported=False, errors=['file_not_found'])
        info=detect_file_type(str(p)); h=sha256_file(str(p)); mixed=detect_mixed_file(str(p)); dup=self.duplicates.is_duplicate(h)
        rec=ScanRecord(str(p), p.name, info['file_type'], info['extension'], p.stat().st_size, h, dup, mixed['is_mixed'], info['is_supported'], route_hint_for_type(info['file_type']), mixed.get('notes',[]), [], {'mixed_kind':mixed.get('mixed_kind')})
        if register: self.duplicates.register(rec.to_dict())
        return rec
