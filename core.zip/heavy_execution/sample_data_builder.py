from pathlib import Path
import csv, json

RUNTIME = Path("runtime/heavy_samples")

def ensure_heavy_sample_data() -> dict:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    (RUNTIME / "arabic_text_samples.txt").write_text(
        "خرج الوزير عن صمته وقلب الطاولة.
التعلم العميق يعالج اللغة العربية.
",
        encoding="utf-8",
    )
    with (RUNTIME / "translation_pairs.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["source_text", "target_text", "domain"])
        writer.writeheader()
        writer.writerow({"source_text":"معالجة اللغة الطبيعية مهمة", "target_text":"Natural language processing is important", "domain":"nlp"})
    with (RUNTIME / "classification_samples.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["text", "label"])
        writer.writeheader()
        writer.writerow({"text":"النموذج ممتاز", "label":"positive"})
        writer.writerow({"text":"النتيجة ضعيفة", "label":"negative"})
    return {"status":"ready", "path": str(RUNTIME)}
