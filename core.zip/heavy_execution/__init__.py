"""Heavy execution layer for all curriculum packs.

This layer prepares optional heavy runs. It never bypasses Heart Kernel,
Execution Gate, BrainReport, Learning Mind, or Decision Gate.
"""
