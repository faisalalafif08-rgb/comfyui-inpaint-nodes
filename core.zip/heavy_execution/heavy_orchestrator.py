import json
from pathlib import Path
from .dependency_matrix import check_dependencies
from .sample_data_builder import ensure_heavy_sample_data
from .ai_algo_heavy_runner import AIAlgoHeavyRunner
from .vit_heavy_runner import ViTHeavyRunner
from .nature_heavy_runner import NatureHeavyRunner

class HeavyCurriculumOrchestrator:
    def run_all(self, mode: str = "heavy") -> dict:
        sample_data = ensure_heavy_sample_data()
        deps = check_dependencies()
        packs = [
            AIAlgoHeavyRunner().run(mode=mode),
            ViTHeavyRunner().run(mode=mode),
            NatureHeavyRunner().run(mode=mode),
        ]
        result = {
            "status": "completed_heavy_or_safe_fallback",
            "mode_requested": mode,
            "dependency_report": deps,
            "sample_data": sample_data,
            "packs": packs,
            "decision_request": "review",
            "note": "Heavy training requires optional dependencies and real datasets; this runner validates all routes and creates BrainReport-ready outputs.",
        }
        out = Path("runtime/reports/heavy_execution_report.json")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result
