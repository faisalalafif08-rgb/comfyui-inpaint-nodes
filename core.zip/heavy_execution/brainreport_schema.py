from dataclasses import dataclass, field
from typing import Any

@dataclass
class HeavyBrainReport:
    capability_id: str
    pack_id: str
    mode: str
    status: str
    findings: list[dict[str, Any]] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    confidence: float = 0.0
    decision_request: str = "review"

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()
