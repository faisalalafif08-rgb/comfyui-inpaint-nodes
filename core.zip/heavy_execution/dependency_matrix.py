from importlib.util import find_spec

HEAVY_GROUPS = {
    "core": ["numpy", "pandas", "sklearn", "scipy"],
    "pdf": ["fitz", "pypdf", "docx"],
    "nlp": ["nltk", "camel_tools", "gensim"],
    "vision": ["PIL", "cv2", "matplotlib"],
    "tensorflow": ["tensorflow", "keras", "keras_tuner"],
    "torch": ["torch", "torchvision", "torchaudio"],
    "optimization": ["mealpy", "hyponic", "pyswarms"],
    "social": ["requests", "bs4", "feedparser"],
}

def check_dependencies() -> dict:
    groups = {}
    for group, modules in HEAVY_GROUPS.items():
        available, missing = [], []
        for module in modules:
            (available if find_spec(module) else missing).append(module)
        groups[group] = {"ok": not missing, "available": available, "missing": missing}
    return {
        "ok": groups["core"]["ok"],
        "heavy_ready": any(groups[g]["ok"] for g in ("tensorflow", "torch", "optimization")),
        "groups": groups,
    }
