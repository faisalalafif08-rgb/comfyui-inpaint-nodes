from dataclasses import dataclass, field
from typing import Any

@dataclass
class BrainReport:
    brain_name: str
    source_type: str
    content_type: str
    capability_id: str | None = None
    chapter: int | None = None
    findings: list[dict[str, Any]] = field(default_factory=list)
    theories_used: list[str] = field(default_factory=list)
    algorithms_used: list[str] = field(default_factory=list)
    confidence: float = 0.0
    decision_request: str = "review"
    notes: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    def to_dict(self): return self.__dict__

def build_brain_report(**kwargs):
    return BrainReport(**kwargs).to_dict()
