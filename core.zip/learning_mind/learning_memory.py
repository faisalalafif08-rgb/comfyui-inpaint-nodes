class LearningMemory:
    def __init__(self): self.records=[]
    def add(self, record: dict): self.records.append(record); return {"ok": True, "count": len(self.records)}
