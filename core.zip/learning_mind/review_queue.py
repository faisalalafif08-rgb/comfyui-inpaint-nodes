class ReviewQueue:
    def __init__(self): self.items=[]
    def push(self, item: dict): self.items.append(item); return {"queued": True, "count": len(self.items)}
