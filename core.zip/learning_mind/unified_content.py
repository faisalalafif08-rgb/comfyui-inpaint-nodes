from dataclasses import dataclass, field
from typing import Any

@dataclass
class UnifiedContentUnit:
    unit_type: str
    text: str | None = None
    unit_number: int | None = None
    start: float | None = None
    end: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    def to_dict(self): return self.__dict__

@dataclass
class UnifiedContent:
    source_file: str
    source_type: str
    content_type: str
    units: list[UnifiedContentUnit]
    metadata: dict[str, Any] = field(default_factory=dict)
    def to_dict(self):
        return {"source_file": self.source_file, "source_type": self.source_type, "content_type": self.content_type, "units": [u.to_dict() for u in self.units], "metadata": self.metadata}
