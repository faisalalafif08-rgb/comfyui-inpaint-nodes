class DecisionInterface:
    def decide(self, report: dict) -> dict:
        confidence = float(report.get('confidence', 0.0))
        return {"decision": "review_recommended" if confidence >= 0.75 else "review_required", "memory_tier": "bronze_until_approved"}
