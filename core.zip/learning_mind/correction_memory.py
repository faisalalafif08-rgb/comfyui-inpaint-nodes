class CorrectionMemory:
    def __init__(self): self.errors=[]
    def add_error(self, record: dict): self.errors.append(record); return {"ok": True, "count": len(self.errors)}
