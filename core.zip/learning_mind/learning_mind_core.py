from .learning_memory import LearningMemory
from .correction_memory import CorrectionMemory
from .review_queue import ReviewQueue
from .decision_interface import DecisionInterface

class LearningMindCore:
    def __init__(self):
        self.memory=LearningMemory(); self.corrections=CorrectionMemory(); self.review=ReviewQueue(); self.decision=DecisionInterface()
    def ingest_unified_content(self, content: dict): return self.memory.add({"type":"unified_content", "value": content})
    def ingest_brain_report(self, report: dict):
        self.memory.add({"type":"brain_report", "value": report})
        decision = self.decision.decide(report)
        if decision["decision"].startswith("review"): self.review.push(report)
        return {"ok": True, "decision": decision}
