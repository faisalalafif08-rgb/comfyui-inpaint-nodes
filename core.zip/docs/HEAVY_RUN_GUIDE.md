# Heavy Run Guide

1. Install full dependencies:

```powershell
.\installers\install_heavy_all.ps1
```

2. Run heavy orchestrator:

```powershell
.\installersun_heavy_all.ps1
```

3. Review output:

```text
runtime/reports/heavy_execution_report.json
```

Heavy runs remain governed by Heart Kernel, Execution Gate, BrainReport, Learning Mind Core, and Decision Gate.
