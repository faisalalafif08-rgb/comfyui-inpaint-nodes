# Data and PDF extraction

PDF has two cases: text PDF uses direct extraction; scanned PDF uses OCR. Mixed visual+text content is represented as UnifiedContent units.

Databases attached to the general mind:
- ar.txt
- ar_char.txt
- correction_engine.db
- extraction_errors.db
- vision_error_memory.db
- Quran/reference databases when available
