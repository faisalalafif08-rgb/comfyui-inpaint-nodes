# Heart Flow

```text
File Gateway / Interface Gateway
↓
Filescanner
↓
FXS
↓
UnifiedContent
↓
Heart Kernel
↓
Learning Mind Core
↓
Specialized Brains
↓
BrainReport
↓
Decision Gate
↓
Memory / Repository / Registry
```
