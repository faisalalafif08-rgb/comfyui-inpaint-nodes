python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements/requirements-core.txt
pip install -r requirements/requirements-pdf.txt
pip install -r requirements/requirements-nlp.txt
pip install -r requirements/requirements-vision.txt
pip install -r requirements/requirements-social.txt
pip install -r requirements/requirements-optimization.txt
Write-Host "Non-deep dependencies installed. Install TensorFlow/Torch separately when needed."
