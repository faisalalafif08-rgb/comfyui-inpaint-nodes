python toolserify_manifest.py
