.\.venv\Scripts\Activate.ps1
python run_heavy_all.py
