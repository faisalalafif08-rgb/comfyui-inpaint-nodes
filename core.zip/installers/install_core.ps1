python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements/requirements-core.txt
Write-Host "Core installed successfully."
