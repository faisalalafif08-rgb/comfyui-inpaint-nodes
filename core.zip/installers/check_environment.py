import json, sys, platform
from importlib.util import find_spec
GROUPS={'core':['numpy','pandas','sklearn'],'pdf':['fitz','pypdf','docx'],'vision':['PIL','cv2','matplotlib'],'tensorflow':['tensorflow','keras'],'torch':['torch'],'optimization':['mealpy','hyponic','pyswarms']}
def check():
    groups=[]
    for name, mods in GROUPS.items():
        missing=[m for m in mods if find_spec(m) is None]
        groups.append({'group':name,'ok':not missing,'missing':missing})
    return {'python_version':sys.version,'platform':platform.platform(),'groups':groups,'heavy_optional':True}
if __name__=='__main__': print(json.dumps(check(), ensure_ascii=False, indent=2))
