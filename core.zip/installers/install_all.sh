#!/usr/bin/env bash
set -e
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
for f in requirements/requirements-core.txt requirements/requirements-pdf.txt requirements/requirements-nlp.txt requirements/requirements-vision.txt requirements/requirements-social.txt requirements/requirements-optimization.txt; do pip install -r "$f"; done
echo "Non-deep dependencies installed."
