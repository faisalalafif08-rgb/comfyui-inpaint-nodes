param([switch]$TorchCpu)
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirementsequirements-heavy-all.txt
Write-Host "Heavy dependencies requested. If GPU packages fail, install CPU variants manually."
