from dataclasses import dataclass, field
from typing import Any

@dataclass
class PortableResult:
    status: str
    ok: bool
    capability_id: str | None = None
    pack_id: str | None = None
    mode: str = "safe"
    used_mock: bool = False
    heavy_required: bool = False
    data: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    decision_request: str = "review"
    metadata: dict[str, Any] = field(default_factory=dict)
    def to_dict(self): return self.__dict__
