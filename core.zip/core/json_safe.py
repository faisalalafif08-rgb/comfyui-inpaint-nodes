def make_json_safe(value):
    try:
        import numpy as np
    except Exception:
        np = None
    if isinstance(value, dict): return {str(k): make_json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [make_json_safe(v) for v in value]
    if np is not None:
        if isinstance(value, np.integer): return int(value)
        if isinstance(value, np.floating): return float(value)
        if isinstance(value, np.ndarray): return value.tolist()
    if hasattr(value, 'to_dict'): return make_json_safe(value.to_dict())
    return value
