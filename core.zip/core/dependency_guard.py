from importlib.util import find_spec

class DependencyGuard:
    @staticmethod
    def available(package_name: str) -> bool:
        return find_spec(package_name) is not None

    @staticmethod
    def require(package_name: str, feature_name: str) -> dict:
        ok = DependencyGuard.available(package_name)
        return {
            "ok": ok,
            "package": package_name,
            "feature": feature_name,
            "message": "dependency_available" if ok else f"Feature '{feature_name}' requires optional dependency '{package_name}'.",
        }

    @staticmethod
    def check_group(group_name: str, packages: list[str]) -> dict:
        available, missing = [], []
        for p in packages:
            (available if DependencyGuard.available(p) else missing).append(p)
        return {"group": group_name, "ok": not missing, "available": available, "missing": missing}
