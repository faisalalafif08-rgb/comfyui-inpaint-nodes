from pathlib import Path
SYSTEM_CONFIG = {
    "system_id": "mybrain_unified_system",
    "system_name": "MyBrain Unified System",
    "version": "0.1.0",
    "root": str(Path('.').resolve()),
    "rules": {"heart_required": True, "decision_gate_required": True, "direct_runner_allowed": False, "heavy_dependencies_optional": True},
}
def get_system_config(): return SYSTEM_CONFIG
