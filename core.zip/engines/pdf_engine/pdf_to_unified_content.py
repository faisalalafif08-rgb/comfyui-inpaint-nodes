from pathlib import Path
from .pdf_text_extractor import PDFTextExtractor
from .pdf_cleaner import PDFTextCleaner
from .pdf_ocr_stub import PDFOCRStub

def convert_pdf_to_unified_content(pdf_path, source_role='knowledge_source'):
    p=Path(pdf_path)
    if not p.exists(): return {'ok':False,'status':'file_not_found','source_file':str(pdf_path),'source_type':'pdf','errors':['file_not_found']}
    extractor=PDFTextExtractor(pdf_path)
    try: has_text=extractor.has_extractable_text()
    except Exception as exc: return {'ok':False,'status':'pdf_dependency_or_read_error','source_file':str(pdf_path),'source_type':'pdf','errors':[str(exc)]}
    pages=PDFTextCleaner.clean_pages(extractor.extract_pages()) if has_text else PDFOCRStub().extract_pages(pdf_path)
    return {'ok':True,'status':'converted_to_unified_content','source_file':str(pdf_path),'source_name':p.name,'source_type':'pdf','content_type':'text' if has_text else 'ocr_required','source_role':source_role,'extraction_mode':'direct_text' if has_text else 'ocr_stub','units':pages,'metadata':{'pdf_is_source_of_truth':False,'requires_decision_gate':True}}
