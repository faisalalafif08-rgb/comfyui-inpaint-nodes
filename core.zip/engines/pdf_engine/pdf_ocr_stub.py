class PDFOCRStub:
    def extract_pages(self, pdf_path): return [{'unit_type':'page','unit_number':None,'text':None,'metadata':{'ocr_required':True,'ocr_available':False,'message':'Install OCR engine or send to OCR Brain.'}}]
