from pathlib import Path
class PDFTextExtractor:
    def __init__(self, pdf_path): self.pdf_path=Path(pdf_path)
    def _fitz(self):
        try: import fitz
        except Exception as exc: raise RuntimeError('PyMuPDF is required for PDF extraction') from exc
        return fitz
    def extract_pages(self):
        fitz=self._fitz(); doc=fitz.open(self.pdf_path); pages=[]
        for i,page in enumerate(doc, start=1):
            text=page.get_text('text').strip(); pages.append({'unit_type':'page','unit_number':i,'text':text,'metadata':{'char_count':len(text),'extraction_method':'pymupdf_text'}})
        doc.close(); return pages
    def has_extractable_text(self, min_chars=50): return sum(len(p.get('text') or '') for p in self.extract_pages())>=min_chars
