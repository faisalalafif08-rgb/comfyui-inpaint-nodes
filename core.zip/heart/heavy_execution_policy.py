HEAVY_EXECUTION_POLICY = {"default_mode":"safe", "allow_direct_training": False, "allow_mock_without_dependencies": True, "requires_decision_gate": True}
