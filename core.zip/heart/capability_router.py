from capability_packs.pack_registry import CapabilityPackRegistry
class CapabilityRouter:
    def __init__(self): self.registry=CapabilityPackRegistry()
    def list_packs(self): return self.registry.list_packs()
    def list_capabilities(self): return self.registry.list_capabilities()
    def route(self, capability_id: str):
        pack = self.registry.find_by_capability(capability_id)
        if not pack: return {"ok": False, "reason": "capability_not_registered", "capability_id": capability_id}
        return {"ok": True, "capability_id": capability_id, "pack_id": pack["pack_id"], "pack_title": pack["title"], "heavy": pack["heavy"], "requirements": pack["requirements"], "status": pack["status"]}
