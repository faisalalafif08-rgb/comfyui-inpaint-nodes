from core.portable_result import PortableResult
from .capability_router import CapabilityRouter
from .heart_response import HeartResponse

class HeartKernel:
    def __init__(self): self.router=CapabilityRouter()
    def handle(self, request):
        route = self.router.route(request.capability_id)
        if not route.get('ok'):
            return HeartResponse(False, 'rejected', request.capability_id, route=route, errors=[route.get('reason','route_error')], decision_request='none')
        result = PortableResult('ready_for_execution_gate', True, request.capability_id, route.get('pack_id'), mode=request.mode, heavy_required=bool(route.get('heavy')), data={"payload_received": request.payload}).to_dict()
        return HeartResponse(True, 'routed', request.capability_id, route.get('pack_id'), route, result, result.get('warnings', []), [], 'review')
