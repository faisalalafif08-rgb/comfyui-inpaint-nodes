from dataclasses import dataclass, field
from typing import Any
@dataclass
class HeartResponse:
    ok: bool; status: str; capability_id: str | None = None; pack_id: str | None = None; route: dict[str, Any] = field(default_factory=dict); result: dict[str, Any] = field(default_factory=dict); warnings: list[str] = field(default_factory=list); errors: list[str] = field(default_factory=list); decision_request: str = "review"
    def to_dict(self): return self.__dict__
