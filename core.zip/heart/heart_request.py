from dataclasses import dataclass, field
from typing import Any
@dataclass
class HeartRequest:
    capability_id: str; payload: dict[str, Any] = field(default_factory=dict); mode: str = "safe"; requester: str = "interface_gateway"; source_type: str | None = None; content_type: str | None = None
    def to_dict(self): return self.__dict__
