from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tigar.system import TheTigarSystem


system = TheTigarSystem(quran_index_path=ROOT / "data" / "quran_index.sample.csv")
print(system.demo())
