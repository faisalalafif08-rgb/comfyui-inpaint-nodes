from __future__ import annotations

from collections import defaultdict

from tigar.models import DialectAnalysis


class ConversationAI:
    DIALECT_MARKERS = {
        "سعودي": {"وش", "شلون", "وشلون", "هلا", "ابشر", "مره", "وشو", "وشكرا", "يعطيك العافية"},
        "مصري": {"إيه", "ايه", "عامل", "أوي", "اوي", "باشا", "دلوقتي", "عايز", "عاوزه", "ليه"},
        "شامي": {"شو", "كتير", "هلق", "منيح", "ليش", "بدك", "بدي", "مو"},
        "فصحى": {"ما", "الذي", "كيف", "يمكن", "ماذا", "أريد", "سأقوم"},
    }

    RESPONSES = {
        "سعودي": "الله يحييك، فهمت عليك. أعطني المطلوب بالتحديد.",
        "مصري": "تمام يا باشا، قولّي المطلوب وأنا أرتبه لك.",
        "شامي": "أكيد، احكيلي شو بدك وأنا بنظّم لك الأمور.",
        "فصحى": "حسنًا، حدّد طلبك وسأرتبه لك بشكل واضح.",
    }

    def detect_dialect(self, text: str) -> DialectAnalysis:
        text = text or ""
        lowered = text.lower()
        scores = defaultdict(float)

        for dialect, markers in self.DIALECT_MARKERS.items():
            for marker in markers:
                if marker.lower() in lowered:
                    scores[dialect] += 1.0

        if not scores:
            result_scores = {dialect: 0.0 for dialect in self.DIALECT_MARKERS}
            return DialectAnalysis(detected_dialect="فصحى", confidence=0.35, scores=result_scores)

        total = sum(scores.values()) or 1.0
        normalized = {dialect: round(scores.get(dialect, 0.0) / total, 3) for dialect in self.DIALECT_MARKERS}
        best = max(normalized, key=normalized.get)
        confidence = max(0.35, normalized[best])
        return DialectAnalysis(detected_dialect=best, confidence=round(confidence, 3), scores=normalized)

    def respond(self, message: str) -> dict:
        analysis = self.detect_dialect(message)
        response = self.RESPONSES.get(analysis.detected_dialect, self.RESPONSES["فصحى"])
        return {
            "original_message": message,
            "detected_dialect": analysis.detected_dialect,
            "confidence": analysis.confidence,
            "response": response,
            "scores": analysis.scores,
        }
