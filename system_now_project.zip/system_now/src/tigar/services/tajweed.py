from __future__ import annotations

from tigar.models import TajweedAnalysis, TajweedFinding


class TajweedAnalyzer:
    """محلل مبدئي قائم على قواعد بسيطة، وليس نموذج ML."""

    IZHAR = set("ءهعحغخ")
    IDGHAM = set("يرملون")
    IQLAB = {"ب"}
    QALQALA = set("قطبجد")
    TANWEEN = set("ًٌٍ")

    def analyze(self, verse_text: str) -> TajweedAnalysis:
        text = verse_text or ""
        findings: list[TajweedFinding] = []
        notes: list[str] = [
            "التحليل الحالي مبدئي وقائم على القواعد النصية فقط.",
            "قد تختلف الأحكام الدقيقة بحسب الضبط والسياق القرائي.",
        ]

        for i, ch in enumerate(text):
            if ch in self.QALQALA:
                findings.append(
                    TajweedFinding(
                        rule="قلقلة",
                        trigger=ch,
                        index=i,
                        context=text[max(0, i - 4): i + 5],
                    )
                )

        for i in range(len(text) - 1):
            current_char = text[i]
            next_char = text[i + 1]
            context = text[max(0, i - 4): i + 6]

            if current_char == "ن":
                if next_char in self.IZHAR:
                    findings.append(TajweedFinding("إظهار", "ن + حرف حلقي", i, context))
                elif next_char in self.IDGHAM:
                    findings.append(TajweedFinding("إدغام", "ن + يرملون", i, context))
                elif next_char in self.IQLAB:
                    findings.append(TajweedFinding("إقلاب", "ن + ب", i, context))

            if current_char in self.TANWEEN:
                if next_char in self.IZHAR:
                    findings.append(TajweedFinding("إظهار تنوين", "تنوين + حرف حلقي", i, context))
                elif next_char in self.IDGHAM:
                    findings.append(TajweedFinding("إدغام تنوين", "تنوين + يرملون", i, context))
                elif next_char in self.IQLAB:
                    findings.append(TajweedFinding("إقلاب تنوين", "تنوين + ب", i, context))

        return TajweedAnalysis(verse=text, findings=findings, notes=notes)
