from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import csv

from tigar.models import SurahRecord


class QuranIndex:
    def __init__(self, csv_path: str | Path | None = None) -> None:
        self.csv_path = Path(csv_path) if csv_path else None
        self.records: list[SurahRecord] = []
        if self.csv_path and self.csv_path.exists():
            self.load()

    def load(self) -> None:
        if not self.csv_path:
            return
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            self.records = []
            for row in reader:
                self.records.append(
                    SurahRecord(
                        surah_number=int(row.get("surah_number", 0) or 0),
                        surah_name=(row.get("surah_name") or "").strip(),
                        ayah_count=int(row["ayah_count"]) if row.get("ayah_count") else None,
                        revelation_type=(row.get("revelation_type") or None),
                    )
                )

    def get_surah(self, surah_number: int) -> dict | None:
        for record in self.records:
            if record.surah_number == surah_number:
                return asdict(record)
        return None

    def search(self, query: str, max_results: int = 5) -> list[dict]:
        query = query.strip().lower()
        if not query:
            return []
        matches = [
            asdict(record)
            for record in self.records
            if query in record.surah_name.lower() or query == str(record.surah_number)
        ]
        return matches[:max_results]
