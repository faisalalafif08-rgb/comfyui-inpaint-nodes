from __future__ import annotations

from pathlib import Path
import math
import struct
import wave

from tigar.models import AudioAnalysis


class AudioAnalyzer:
    def analyze(self, audio_path: str | Path) -> AudioAnalysis:
        path = Path(audio_path)
        if not path.exists():
            return AudioAnalysis(
                path=str(path),
                format=path.suffix.lower().lstrip(".") or "unknown",
                duration_seconds=None,
                sample_rate=None,
                channels=None,
                sample_width_bytes=None,
                rms=None,
                notes=["الملف غير موجود."],
            )

        fmt = path.suffix.lower().lstrip(".") or "unknown"
        if fmt != "wav":
            return AudioAnalysis(
                path=str(path),
                format=fmt,
                duration_seconds=None,
                sample_rate=None,
                channels=None,
                sample_width_bytes=None,
                rms=None,
                notes=["النسخة الحالية تدعم التحليل المباشر لملفات WAV فقط."],
            )

        with wave.open(str(path), "rb") as wf:
            channels = wf.getnchannels()
            sample_rate = wf.getframerate()
            sample_width = wf.getsampwidth()
            frames = wf.getnframes()
            raw = wf.readframes(frames)

        duration = frames / float(sample_rate) if sample_rate else None
        rms = self._compute_rms(raw, sample_width)
        return AudioAnalysis(
            path=str(path),
            format=fmt,
            duration_seconds=round(duration, 3) if duration is not None else None,
            sample_rate=sample_rate,
            channels=channels,
            sample_width_bytes=sample_width,
            rms=round(rms, 3) if rms is not None else None,
            notes=["تحليل WAV أساسي بدون فصل صوت/موسيقى أو تقدير مقام/Tempo."],
        )

    def _compute_rms(self, raw: bytes, sample_width: int) -> float | None:
        if not raw:
            return None
        if sample_width == 1:
            samples = struct.unpack(f"{len(raw)}B", raw)
            centered = [s - 128 for s in samples]
        elif sample_width == 2:
            count = len(raw) // 2
            samples = struct.unpack(f"<{count}h", raw)
            centered = list(samples)
        else:
            return None
        if not centered:
            return None
        mean_square = sum(s * s for s in centered) / len(centered)
        return math.sqrt(mean_square)
