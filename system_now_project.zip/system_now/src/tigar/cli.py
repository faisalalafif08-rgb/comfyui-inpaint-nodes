from __future__ import annotations

import argparse
import json
from pathlib import Path

from tigar.system import TheTigarSystem


def print_json(data: object) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="THE TIGAR - نظام موحد منظم")
    parser.add_argument("command", choices=["demo", "quran", "audio", "dialect", "reply", "search-surah"])
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--index", default=None, help="مسار ملف quran_index.csv")
    parser.add_argument("--verse", default=None)
    parser.add_argument("--surah", type=int, default=None)
    parser.add_argument("--file", dest="file_path", default=None)
    parser.add_argument("--text", default=None)
    parser.add_argument("--query", default=None)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    system = TheTigarSystem(project_root=args.project_root, quran_index_path=args.index)

    if args.command == "demo":
        print_json(system.demo())
        return 0

    if args.command == "quran":
        if not args.verse:
            parser.error("الأمر quran يحتاج --verse")
        print_json(system.analyze_quran_verse(args.verse, args.surah))
        return 0

    if args.command == "audio":
        if not args.file_path:
            parser.error("الأمر audio يحتاج --file")
        print_json(system.analyze_audio_file(Path(args.file_path)))
        return 0

    if args.command == "dialect":
        if not args.text:
            parser.error("الأمر dialect يحتاج --text")
        print_json(system.detect_dialect(args.text))
        return 0

    if args.command == "reply":
        if not args.text:
            parser.error("الأمر reply يحتاج --text")
        print_json(system.respond(args.text))
        return 0

    if args.command == "search-surah":
        if not args.query:
            parser.error("الأمر search-surah يحتاج --query")
        print_json(system.search_surah(args.query))
        return 0

    parser.error("أمر غير معروف")
    return 2
