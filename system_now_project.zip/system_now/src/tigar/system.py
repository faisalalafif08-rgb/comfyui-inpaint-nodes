from __future__ import annotations

from pathlib import Path

from tigar.config import Config
from tigar.models import to_jsonable
from tigar.services.audio import AudioAnalyzer
from tigar.services.conversation import ConversationAI
from tigar.services.quran_index import QuranIndex
from tigar.services.tajweed import TajweedAnalyzer


class TheTigarSystem:
    def __init__(self, project_root: str | None = None, quran_index_path: str | None = None) -> None:
        self.config = Config.from_env(project_root)
        self.quran_index = QuranIndex(quran_index_path)
        self.tajweed = TajweedAnalyzer()
        self.audio = AudioAnalyzer()
        self.conversation = ConversationAI()

    def analyze_quran_verse(self, verse_text: str, surah_number: int | None = None) -> dict:
        result = {
            "verse": verse_text,
            "surah_info": self.quran_index.get_surah(surah_number) if surah_number else None,
            "tajweed_analysis": to_jsonable(self.tajweed.analyze(verse_text)),
        }
        return result

    def analyze_audio_file(self, path: str | Path) -> dict:
        return to_jsonable(self.audio.analyze(path))

    def detect_dialect(self, text: str) -> dict:
        return to_jsonable(self.conversation.detect_dialect(text))

    def respond(self, text: str) -> dict:
        return self.conversation.respond(text)

    def search_surah(self, query: str) -> list[dict]:
        return self.quran_index.search(query)

    def demo(self) -> dict:
        return {
            "quran_demo": self.analyze_quran_verse("بسم الله الرحمن الرحيم", 1),
            "dialect_demo": self.detect_dialect("وش اخباركم يا شباب"),
            "reply_demo": self.respond("عامل ايه يا باشا"),
        }
