from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os


@dataclass(slots=True)
class Config:
    project_root: Path
    data_dir: Path
    audio_dir: Path

    @classmethod
    def from_env(cls, project_root: str | None = None) -> "Config":
        root = Path(project_root or os.getenv("TIGAR_PROJECT_ROOT", ".")).resolve()
        data_dir = root / "data"
        audio_dir = root / "audio"
        data_dir.mkdir(parents=True, exist_ok=True)
        audio_dir.mkdir(parents=True, exist_ok=True)
        return cls(project_root=root, data_dir=data_dir, audio_dir=audio_dir)
