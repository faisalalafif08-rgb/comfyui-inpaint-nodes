from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any


@dataclass(slots=True)
class TajweedFinding:
    rule: str
    trigger: str
    index: int
    context: str


@dataclass(slots=True)
class TajweedAnalysis:
    verse: str
    findings: list[TajweedFinding] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class AudioAnalysis:
    path: str
    format: str
    duration_seconds: float | None
    sample_rate: int | None
    channels: int | None
    sample_width_bytes: int | None
    rms: float | None
    notes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class DialectAnalysis:
    detected_dialect: str
    confidence: float
    scores: dict[str, float]


@dataclass(slots=True)
class SurahRecord:
    surah_number: int
    surah_name: str
    ayah_count: int | None = None
    revelation_type: str | None = None


def to_jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {k: to_jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {k: to_jsonable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_jsonable(v) for v in value]
    return value
