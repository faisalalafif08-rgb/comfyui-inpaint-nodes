import { motion } from 'motion/react';
import { LetterStats } from '../types';
import { AlertCircle, HelpCircle, FileText, CheckCircle } from 'lucide-react';

interface LetterCardProps {
  key?: string;
  stats: LetterStats;
  isSelected: boolean;
  onSelect: () => void;
}

export default function LetterCard({ stats, isSelected, onSelect }: LetterCardProps) {
  const isAnomalous = stats.isAnomalous;
  const rawFormatted = stats.rawCount.toLocaleString('ar-EG');
  const uniqueFormatted = stats.uniqueCount.toLocaleString('ar-EG');
  
  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      id={`letter-card-${stats.letter}`}
      onClick={onSelect}
      className={`cursor-pointer transition-all duration-200 p-5 rounded-2xl border text-right relative flex flex-col justify-between h-48 ${
        isSelected
          ? isAnomalous
            ? 'border-rose-300 bg-rose-50/40 shadow-sm shadow-rose-100/50'
            : 'border-emerald-500 bg-emerald-50/30 shadow-sm shadow-emerald-100/50'
          : 'border-slate-200/70 bg-white hover:border-slate-300 hover:shadow-sm'
      }`}
    >
      {/* Upper info section */}
      <div>
        <div className="flex md:flex-row-reverse items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className={`text-3xl font-bold font-sans ${isAnomalous ? 'text-rose-600' : 'text-slate-950'}`}>
              « {stats.letter} »
            </span>
          </div>
          
          {isAnomalous ? (
            <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 border border-rose-200">
              <AlertCircle size={12} />
              معطوب / شاذ
            </span>
          ) : stats.rawCount === 0 ? (
            <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 border border-slate-200">
              <HelpCircle size={12} />
              خالٍ تماماً
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
              <CheckCircle size={12} />
              سليم وقابل للفرز
            </span>
          )}
        </div>

        {/* Counts section */}
        <div className="grid grid-cols-2 gap-2 mt-3 text-right" dir="rtl">
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">الكلمات الخام</span>
            <span className="text-base font-bold text-slate-700 font-mono tracking-tight">{rawFormatted}</span>
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">الفريدة (بدون تكرار)</span>
            <span className="text-base font-bold text-slate-700 font-mono tracking-tight">{uniqueFormatted}</span>
          </div>
        </div>
      </div>

      {/* Bottom section showing top specimen words */}
      <div className="mt-3 border-t border-slate-100 pt-2 flex flex-row-reverse items-center justify-between overflow-hidden">
        <span className="text-[10px] text-slate-400 flex items-center gap-1 flex-shrink-0">
          <FileText size={10} />
          أول الكلمات:
        </span>
        <div className="flex flex-row-reverse gap-1 overflow-x-auto whitespace-nowrap no-scrollbar pl-2">
          {stats.topWords.length > 0 ? (
            stats.topWords.slice(0, 4).map((word, i) => (
              <span
                key={i}
                className="text-xs bg-slate-50 border border-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium"
              >
                {word}
              </span>
            ))
          ) : (
            <span className="text-xs text-slate-400 italic">لا يوجد سجل</span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
