import { useState } from 'react';
import { ANOMALY_DICTIONARY } from '../data';
import { WordCorrection } from '../types';
import { Search, Info, HelpCircle, ArrowLeft, Copy, Check, FileCode, MessageSquare, Plus, Trash2 } from 'lucide-react';

interface AnomalyInspectorProps {
  onInsertWord: (word: string) => void;
  currentUser?: any;
  annotations?: Array<{
    id: string;
    userId: string;
    userEmail: string;
    word: string;
    note: string;
    createdAt?: any;
  }>;
  onAddAnnotation?: (word: string, note: string) => Promise<void>;
  onDeleteAnnotation?: (annotationId: string) => Promise<void>;
}

export default function AnomalyInspector({ 
  onInsertWord,
  currentUser,
  annotations = [],
  onAddAnnotation,
  onDeleteAnnotation
}: AnomalyInspectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedWord, setCopiedWord] = useState<string | null>(null);
  const [activeNoteInputWord, setActiveNoteInputWord] = useState<string | null>(null);
  const [newNoteText, setNewNoteText] = useState('');

  const anomalies: WordCorrection[] = Object.values(ANOMALY_DICTIONARY);

  const handleCopy = (word: string) => {
    navigator.clipboard.writeText(word);
    setCopiedWord(word);
    setTimeout(() => setCopiedWord(null), 1500);
  };

  const handleAddNote = async (word: string) => {
    if (!newNoteText.trim() || !onAddAnnotation) return;
    try {
      await onAddAnnotation(word, newNoteText.trim());
      setNewNoteText('');
      setActiveNoteInputWord(null);
    } catch (err) {
      console.error('Failed to add annotation note:', err);
    }
  };

  // Filter anomalies based on search term and selected category
  const filteredAnomalies = anomalies.filter((item) => {
    const matchesSearch =
      item.original.includes(searchTerm) ||
      item.corrected.includes(searchTerm) ||
      item.explanation.includes(searchTerm);
      
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div id="anomaly-inspector" className="p-6 rounded-2xl border border-rose-100 bg-white shadow-sm" dir="rtl">
      {/* Title section with contextual warning badge */}
      <div className="flex md:flex-row items-start justify-between gap-4 border-b border-rose-50/80 pb-4 mb-5">
        <div>
          <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block animate-pulse"></span>
            تحليل وتتبع الكلمات المشوهة والشاذة في لغة المعجم
          </h3>
          <p className="text-sm text-slate-500 mt-1 leading-relaxed">
            يتراكم في ملفات النصوص والمعاجم الكلية مثل <code className="bg-slate-50 px-1 py-0.5 rounded text-rose-600 font-mono text-xs">ar.txt</code> مجموعة من التصحيفات والعيوب الإملائية التي تقع صدراً في الحروف القياسية (مثل <code className="bg-rose-50 text-rose-700 font-bold px-1.5 py-0.5 rounded font-mono">ى، ؤ، ئ، ء، ة</code>) حيث لا تبدأ بها أي كلمة باللغة العربية الفصيحة، مما يدل على تشوه ترميزي مطبعي أو تآكل بنيوي للكلمات.
          </p>
        </div>
      </div>

      {/* Modern Filter controls & Search */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        <div className="relative md:col-span-2">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="البحث في كلمات المعجم المشوهة وتفسيراتها..."
            className="w-full pl-3 pr-10 py-2 bg-slate-50 border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-400 rounded-xl text-sm transition-all text-right font-medium text-slate-700"
          />
          <Search className="absolute top-2.5 right-3 text-slate-400" size={16} />
        </div>

        <div className="flex gap-1 bg-slate-50 p-1 rounded-xl border border-slate-150">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`flex-1 text-center py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
              selectedCategory === 'all'
                ? 'bg-white text-slate-800 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setSelectedCategory('prefix')}
            className={`flex-1 text-center py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
              selectedCategory === 'prefix'
                ? 'bg-rose-100 text-rose-700 border border-rose-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            تنظيف بادئة
          </button>
          <button
            onClick={() => setSelectedCategory('orthography')}
            className={`flex-1 text-center py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
              selectedCategory === 'orthography'
                ? 'bg-amber-100 text-amber-700 border border-amber-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            إملاء وترتيب
          </button>
        </div>
      </div>

      {/* Grid container with corrected list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[500px] overflow-y-auto pr-1">
        {filteredAnomalies.length > 0 ? (
          filteredAnomalies.map((item, index) => {
            const wordNotations = annotations.filter(ann => ann.word === item.original);
            
            return (
              <div
                key={index}
                className="border border-slate-100/80 bg-slate-50/40 p-3.5 rounded-xl hover:border-rose-100 hover:bg-white transition-all flex flex-col justify-between gap-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-sans">
                      <span className="text-sm font-bold text-rose-600 font-mono bg-rose-50 px-2 py-0.5 rounded border border-rose-100">
                        {item.original}
                      </span>
                      <ArrowLeft size={13} className="text-slate-400" />
                      <span className="text-sm font-bold text-emerald-600 font-mono bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                        {item.corrected}
                      </span>
                    </div>
                    
                    <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                      item.category === 'prefix'
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}>
                      {item.category === 'prefix' ? 'بادئة زائدة' : 'تحوير إملائي'}
                    </span>
                  </div>
                  
                  <p className="text-xs text-slate-500 leading-normal flex items-start gap-1">
                    <span className="mt-0.5 block flex-shrink-0"><Info size={11} className="text-slate-400" /></span>
                    <span>{item.explanation}</span>
                  </p>

                  {/* Collaborator annotations / notes list */}
                  {wordNotations.length > 0 && (
                    <div className="bg-rose-50/30 border border-rose-100/60 rounded-lg p-2 space-y-1.5 mt-2">
                      <p className="text-[10px] text-rose-800 font-bold flex items-center gap-1">
                        <MessageSquare size={10} />
                        ملاحظات الباحثين اللغوية ({wordNotations.length}):
                      </p>
                      <div className="space-y-1 max-h-24 overflow-y-auto">
                        {wordNotations.map((note) => (
                          <div key={note.id} className="text-[10px] bg-white border border-rose-50 p-1.5 rounded flex items-start justify-between gap-1">
                            <div className="space-y-0.5">
                              <span className="font-semibold text-slate-500 block text-[9px]">{note.userEmail}</span>
                              <p className="text-slate-800 font-medium whitespace-pre-wrap">{note.note}</p>
                            </div>
                            {currentUser && currentUser.uid === note.userId && onDeleteAnnotation && (
                              <button
                                onClick={() => onDeleteAnnotation(note.id)}
                                className="text-slate-400 hover:text-rose-600 transition-colors p-0.5 rounded"
                                title="حذف الملاحظة"
                              >
                                <Trash2 size={10} />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Add Annotation form */}
                  {activeNoteInputWord === item.original ? (
                    <div className="mt-2 space-y-1 border border-slate-100 bg-slate-50 p-2 rounded-lg">
                      <textarea
                        value={newNoteText}
                        onChange={(e) => setNewNoteText(e.target.value)}
                        placeholder="اكتب تعليقك اللغوي أو التفسير هنا..."
                        className="w-full h-12 p-1.5 border border-slate-200 rounded-md text-[11px] bg-white focus:outline-none focus:ring-1 focus:ring-rose-300 text-right"
                      />
                      <div className="flex gap-1 justify-end">
                        <button
                          onClick={() => {
                            setActiveNoteInputWord(null);
                            setNewNoteText('');
                          }}
                          className="text-[9px] bg-slate-200 text-slate-600 px-2 py-1 rounded transition-colors font-medium"
                        >
                          إلغاء
                        </button>
                        <button
                          onClick={() => handleAddNote(item.original)}
                          className="text-[9px] bg-rose-600 text-white px-2 py-1 rounded hover:bg-rose-500 transition-colors font-semibold"
                        >
                          حفظ الملاحظة
                        </button>
                      </div>
                    </div>
                  ) : (
                    currentUser && (
                      <button
                        onClick={() => {
                          setActiveNoteInputWord(item.original);
                          setNewNoteText('');
                        }}
                        className="text-[10px] text-rose-700 hover:text-rose-900 font-semibold flex items-center gap-1 hover:underline mt-1"
                      >
                        <MessageSquare size={11} />
                        إضافة ملاحظة بحثية...
                      </button>
                    )
                  )}
                </div>

                {/* Action shortcuts */}
                <div className="flex items-center justify-end gap-2 mt-3 border-t border-slate-100/65 pt-2">
                  <button
                    type="button"
                    onClick={() => onInsertWord(item.original)}
                    className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 hover:underline px-1 py-0.5 rounded"
                  >
                    <FileCode size={11} />
                    الحاق للمحرر
                  </button>
                  <div className="h-3 w-[1px] bg-slate-200"></div>
                  <button
                    type="button"
                    onClick={() => handleCopy(item.original)}
                    className="text-[11px] text-slate-400 hover:text-slate-600 p-1 rounded"
                    title="نسخ الأصل"
                  >
                    {copiedWord === item.original ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full py-8 text-center text-slate-400 flex flex-col items-center justify-center gap-2">
            <HelpCircle size={28} className="text-slate-300" />
            <p className="text-sm">لم نجد أي مطابقات لبحثك.</p>
          </div>
        )}
      </div>
      
      {/* Quick Load and Warning Callout */}
      {!currentUser && (
        <div className="mt-4 bg-rose-50/50 border border-rose-100/60 rounded-xl p-3 flex gap-2 items-center">
          <span className="text-rose-500"><Info size={16} /></span>
          <p className="text-[11px] text-rose-850 leading-relaxed">
            <strong>ملاحظة للباحثين والمراجعين:</strong> سجل دخولك باستخدام حساب Google الفعال في الزاوية العلوية لتتاح لك لوحة إضافة ومشاركة الملاحظات والتحليلات اللغوية الفورية معنا في قاعدة بيانات المعجم.
          </p>
        </div>
      )}
      <div className="mt-3 bg-orange-50/50 border border-orange-100 rounded-xl p-3 flex gap-2 items-center">
        <span className="text-orange-500"><Info size={16} /></span>
        <p className="text-[11px] text-orange-850 leading-relaxed">
          <strong>معلومة تقنية:</strong> هذه التشوهات غالباً ما تحدث أثناء الاستيراد الخاطئ لملفات النصوص مجهولة ترميز الـ Unicode، حيث يتم الخلط بين علامات الـ UTF-8 وحقول الـ ASCII.
        </p>
      </div>
    </div>
  );
}
