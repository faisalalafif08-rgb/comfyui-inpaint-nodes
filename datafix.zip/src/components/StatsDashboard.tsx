import { ChartBar, Check, TrendingDown, RefreshCcw } from 'lucide-react';
import { AnalysisSummary } from '../types';

interface StatsDashboardProps {
  summary: AnalysisSummary;
  totalChanges: number;
}

export default function StatsDashboard({ summary, totalChanges }: StatsDashboardProps) {
  const score = summary.cleanlinessScore;
  
  // Color configuration depending on data cleanliness
  const getScoreColor = (sc: number) => {
    if (sc > 90) return { text: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', bar: 'bg-emerald-500' };
    if (sc > 70) return { text: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', bar: 'bg-amber-500' };
    return { text: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-100', bar: 'bg-rose-500' };
  };

  const colors = getScoreColor(score);

  return (
    <div id="stats-dashboard" className="grid grid-cols-1 md:grid-cols-4 gap-4" dir="rtl">
      
      {/* Cleanliness rating */}
      <div className={`p-5 rounded-2xl border ${colors.border} ${colors.bg} flex flex-col justify-between relative overflow-hidden md:col-span-1`}>
        <div>
          <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider mb-1">معدل سلامة النص</span>
          <div className="flex items-baseline gap-1">
            <span className={`text-4xl font-black font-sans ${colors.text}`}>{score}%</span>
          </div>
        </div>
        
        {/* Visual progress bar */}
        <div className="mt-4">
          <div className="w-full bg-slate-200/60 rounded-full h-2 overflow-hidden">
            <div className={`h-full ${colors.bar} rounded-full transition-all duration-500`} style={{ width: `${score}%` }}></div>
          </div>
          <p className="text-[10px] text-slate-500 mt-2">
            {score === 100 
              ? 'البيانات سليمة 100% وخالية من الشوائب الإملائية.' 
              : ` تم تحديد وتحييد تشوهات ترميزية طفيفة بحجم ${100 - score}%.`}
          </p>
        </div>
      </div>

      {/* Raw words compare counter */}
      <div className="p-5 rounded-2xl border border-slate-200/80 bg-white flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider">الكلمات قبل التطهير وبعده</span>
          <span className="text-slate-300"><ChartBar size={16} /></span>
        </div>
        
        <div className="flex items-end justify-between">
          <div>
            <span className="text-2xl font-black font-mono text-slate-800 tracking-tight">
              {summary.correctedWordsCount.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-slate-400 block">بعد التحليل والتصحيح</span>
          </div>

          <div className="text-left">
            <span className="text-sm font-bold text-slate-400 font-mono line-through block">
              {summary.originalWordsCount.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-slate-450 block">النص الأصلي</span>
          </div>
        </div>
      </div>

      {/* Unique vocab preservation compare */}
      <div className="p-5 rounded-2xl border border-slate-200/80 bg-white flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider">الكلمات الفريدة المحفوظة</span>
          <span className="text-slate-350"><RefreshCcw size={15} /></span>
        </div>
        
        <div className="flex items-end justify-between">
          <div>
            <span className="text-2xl font-black font-mono text-indigo-600 tracking-tight">
              {summary.uniqueCorrectedCount.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-slate-400 block">بدون تكرار قياسي</span>
          </div>

          <div className="text-left">
            <span className="text-sm font-bold text-slate-400 font-mono line-through block">
              {summary.uniqueOriginalCount.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-slate-450 block font-normal">المفردات الخام</span>
          </div>
        </div>
      </div>

      {/* Total changes applied */}
      <div className="p-5 rounded-2xl border border-slate-200/80 bg-white flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider">إجمالي التعديلات المنفذة</span>
          {totalChanges > 0 ? (
            <span className="text-rose-500 flex items-center gap-0.5 text-[10px] font-medium"><TrendingDown size={11} /> تصحيح نشط</span>
          ) : (
            <span className="text-emerald-500 flex items-center gap-0.5 text-[10px] font-medium"><Check size={11} /> مطهر</span>
          )}
        </div>
        
        <div className="flex items-baseline gap-1.5 justify-start mt-2">
          <span className={`text-4xl font-extrabold font-mono tracking-tight ${totalChanges > 0 ? 'text-rose-600 animate-pulse' : 'text-slate-700'}`}>
            {totalChanges.toLocaleString('ar-EG')}
          </span>
          <span className="text-xs text-slate-400 font-semibold">{totalChanges > 0 ? 'عملية تبديل' : 'لا تعديلات مطلوبة'}</span>
        </div>
        
        <p className="text-[10px] text-slate-400 mt-2">
          تم فحص كافة تركيبات العبارات والمصطلحات الإملائية المقيدة.
        </p>
      </div>

    </div>
  );
}
