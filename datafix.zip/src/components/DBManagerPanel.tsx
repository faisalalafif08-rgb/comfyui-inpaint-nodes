import React, { useState, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import initSqlJs, { Database } from 'sql.js';
import { 
  Database as DbIcon, 
  Download, 
  Upload, 
  Play, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  RefreshCw, 
  Search, 
  HelpCircle, 
  ChevronRight, 
  ArrowLeft,
  Settings,
  ShieldAlert,
  Terminal,
  FileSpreadsheet
} from 'lucide-react';

// Define the SQLite table structures for scholarly reference in the UI
const SCHEMA_CODE = `
-- 1) Languages Table with strict constraints
CREATE TABLE IF NOT EXISTS Languages (
    language_ID TEXT PRIMARY KEY,
    language_code TEXT NOT NULL UNIQUE,      -- ar / en / fr
    language_name_ar TEXT NOT NULL,          -- العربية / الإنجليزية
    language_name_native TEXT,               -- العربية / English / Français
    script_name TEXT,                        -- Arabic / Latin
    direction TEXT NOT NULL DEFAULT 'LTR' CHECK (direction IN ('RTL','LTR')),
    has_diacritics INTEGER NOT NULL DEFAULT 0,
    has_letter_forms INTEGER NOT NULL DEFAULT 0, -- مهم للعربي
    review_status TEXT NOT NULL DEFAULT 'approved' CHECK (review_status IN ('pending','reviewed','approved','rejected')),
    source TEXT NOT NULL DEFAULT 'system_seed',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2) Language_Letters Table with sequence indices
CREATE TABLE IF NOT EXISTS Language_Letters (
    letter_ID TEXT PRIMARY KEY,
    language_ID TEXT NOT NULL,
    letter_order INTEGER NOT NULL,           -- ترتيب الحرف داخل اللغة
    letter TEXT NOT NULL,                    -- ا / ب / ت / A / B
    letter_name TEXT,                        -- ألف / باء / Alef
    normalized_letter TEXT NOT NULL,         -- الشكل المطبع
    unicode_codepoint TEXT,                  -- U+0627
    sound_hint TEXT,                         -- a / b / t تقريب صوتي
    is_base_letter INTEGER NOT NULL DEFAULT 1,
    is_diacritic INTEGER NOT NULL DEFAULT 0,
    review_status TEXT NOT NULL DEFAULT 'approved' CHECK (review_status IN ('pending','reviewed','approved','rejected')),
    source TEXT NOT NULL DEFAULT 'system_seed',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    seq_2 TEXT,                              -- Second-tier Arabic script sequence context index
    seq_3 TEXT,                              -- Third-tier Arabic script sequence context index
    seq_4 TEXT,                              -- Fourth-tier Arabic script sequence context index
    FOREIGN KEY (language_ID) REFERENCES Languages(language_ID) ON DELETE CASCADE,
    UNIQUE (language_ID, letter),
    UNIQUE (language_ID, letter_order)
);

-- 3) Arabic_Letter_Forms Table supporting both custom fields and original schema mapping
CREATE TABLE IF NOT EXISTS Arabic_Letter_Forms (
    form_ID TEXT PRIMARY KEY,
    letter_ID TEXT NOT NULL,
    isolated TEXT NOT NULL,
    initial TEXT NOT NULL,
    medial TEXT NOT NULL,
    final TEXT NOT NULL,
    isolated_form TEXT,      -- ب
    initial_form TEXT,       -- بـ
    medial_form TEXT,        -- ـبـ
    final_form TEXT,         -- ـب
    connects_before INTEGER NOT NULL DEFAULT 1,
    connects_after INTEGER NOT NULL DEFAULT 1,
    source TEXT NOT NULL DEFAULT 'system_seed',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (letter_ID) REFERENCES Language_Letters(letter_ID) ON DELETE CASCADE
);

-- 4) Import_Review Table
CREATE TABLE IF NOT EXISTS Import_Review (
  reviewer_name TEXT PRIMARY KEY,
  review_status TEXT CHECK(review_status IN ('APPROVED', 'PENDING', 'reviewed', 'rejected')) DEFAULT 'PENDING',
  notes TEXT,
  review_date TEXT
);

-- Indexes for lightning fast lookups & NLP matching
CREATE INDEX IF NOT EXISTS idx_languages_code ON Languages(language_code);
CREATE INDEX IF NOT EXISTS idx_letters_language ON Language_Letters(language_ID);
CREATE INDEX IF NOT EXISTS idx_letters_letter ON Language_Letters(letter);
CREATE INDEX IF NOT EXISTS idx_letters_order ON Language_Letters(language_ID, letter_order);
CREATE INDEX IF NOT EXISTS idx_ar_letter_forms_letter ON Arabic_Letter_Forms(letter_ID);

-- ============================================================
-- QPEC V1 SCHOLARLY SCHEMA TABLES (QURAN PDF ERROR CAPTURE)
-- ============================================================

CREATE TABLE IF NOT EXISTS qpec_reference_words (
    reference_word_id TEXT PRIMARY KEY,
    source_mode TEXT NOT NULL CHECK (source_mode IN ('text_pdf_vs_txt', 'ocr_pdf_vs_sqlite_excel')),
    pdf_page_number INTEGER,
    quran_page_number INTEGER,
    page_offset INTEGER DEFAULT 0,
    surah_number INTEGER NOT NULL,
    surah_name TEXT,
    ayah_number INTEGER NOT NULL,
    word_position INTEGER NOT NULL,
    reference_word TEXT NOT NULL,
    normalized_reference_word TEXT,
    reference_source TEXT NOT NULL CHECK (reference_source IN ('txt', 'sqlite_excel_consensus', 'manual_review')),
    reference_trust_status TEXT NOT NULL DEFAULT 'candidate' CHECK (reference_trust_status IN ('candidate', 'trusted', 'conflict', 'not_trusted', 'needs_review')),
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (source_mode, surah_number, ayah_number, word_position)
);

CREATE TABLE IF NOT EXISTS qpec_extraction_attempts (
    attempt_id TEXT PRIMARY KEY,
    reference_word_id TEXT NOT NULL,
    attempt_number INTEGER NOT NULL,
    extraction_source TEXT NOT NULL CHECK (extraction_source IN ('pdf_text', 'ocr')),
    engine_name TEXT,
    engine_profile TEXT,
    extracted_word TEXT,
    normalized_extracted_word TEXT,
    pdf_page_number INTEGER NOT NULL,
    quran_page_number INTEGER,
    line_number INTEGER,
    word_position INTEGER NOT NULL,
    char_start INTEGER,
    char_end INTEGER,
    bbox_json TEXT,
    similarity REAL DEFAULT 0.0,
    compare_status TEXT NOT NULL CHECK (compare_status IN ('same', 'different', 'missing', 'extra', 'uncertain', 'no_problem')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reference_word_id) REFERENCES qpec_reference_words(reference_word_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS qpec_extraction_errors (
    error_id TEXT PRIMARY KEY,
    reference_word_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    error_round INTEGER NOT NULL,
    pdf_page_number INTEGER NOT NULL,
    quran_page_number INTEGER,
    surah_number INTEGER,
    surah_name TEXT,
    ayah_number INTEGER,
    word_position INTEGER NOT NULL,
    correct_word TEXT NOT NULL,
    wrong_word TEXT,
    issue_type TEXT NOT NULL CHECK (issue_type IN ('wrong_character', 'missing_character', 'extra_character', 'wrong_word', 'missing_word', 'extra_word', 'diacritic_error', 'spacing_error', 'line_break_error', 'word_order_error', 'ocr_noise', 'pdf_extraction_noise', 'reference_conflict', 'uncertain')),
    issue_summary TEXT,
    location_note TEXT,
    similarity REAL DEFAULT 0.0,
    error_signature TEXT,
    repeat_count INTEGER DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'repeated', 'resolved', 'disappeared', 'no_problem', 'needs_review', 'rejected')),
    review_status TEXT NOT NULL DEFAULT 'pending_review' CHECK (review_status IN ('pending_review', 'reviewed', 'approved', 'rejected')),
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reference_word_id) REFERENCES qpec_reference_words(reference_word_id) ON DELETE CASCADE,
    FOREIGN KEY (attempt_id) REFERENCES qpec_extraction_attempts(attempt_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS qpec_no_error_marks (
    mark_id TEXT PRIMARY KEY,
    reference_word_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    attempt_number INTEGER NOT NULL,
    pdf_page_number INTEGER NOT NULL,
    quran_page_number INTEGER,
    word_position INTEGER NOT NULL,
    correct_word TEXT NOT NULL,
    extracted_word TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('no_problem', 'resolved_after_previous_error', 'disappeared_after_rerun')),
    note TEXT,
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reference_word_id) REFERENCES qpec_reference_words(reference_word_id) ON DELETE CASCADE,
    FOREIGN KEY (attempt_id) REFERENCES qpec_extraction_attempts(attempt_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS qpec_repeated_error_patterns (
    pattern_id TEXT PRIMARY KEY,
    error_signature TEXT NOT NULL UNIQUE,
    issue_type TEXT NOT NULL,
    correct_word TEXT,
    wrong_word TEXT,
    extraction_source TEXT,
    engine_name TEXT,
    engine_profile TEXT,
    occurrence_count INTEGER NOT NULL DEFAULT 1,
    first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    training_value TEXT NOT NULL DEFAULT 'candidate' CHECK (training_value IN ('candidate', 'important', 'noise', 'rejected', 'approved_for_profile')),
    suggested_rule TEXT,
    review_status TEXT NOT NULL DEFAULT 'pending_review' CHECK (review_status IN ('pending_review', 'reviewed', 'approved', 'rejected')),
    gold_write INTEGER NOT NULL DEFAULT 0
);

-- Pivot View for Accumulative Matrix pivoting up to 6 rounds representing EasyOCR iterations
CREATE VIEW IF NOT EXISTS qpec_error_matrix_view AS
WITH ranked_attempts AS (
    SELECT
        a.reference_word_id,
        a.attempt_number,
        a.extracted_word,
        a.compare_status,
        (SELECT e.issue_type FROM qpec_extraction_errors e WHERE e.attempt_id = a.attempt_id LIMIT 1) AS issue_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.reference_word_id
            ORDER BY a.attempt_number ASC
        ) AS rn
    FROM qpec_extraction_attempts a
),
last_status AS (
    SELECT
        r.reference_word_id,
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM qpec_no_error_marks n
                WHERE n.reference_word_id = r.reference_word_id
                  AND n.status IN ('resolved_after_previous_error', 'disappeared_after_rerun')
            ) THEN 'resolved'
            WHEN EXISTS (
                SELECT 1
                FROM qpec_extraction_errors e
                WHERE e.reference_word_id = r.reference_word_id
                  AND e.status IN ('open','repeated','needs_review')
            ) THEN 'has_errors'
            ELSE 'no_problem'
        END AS final_status
    FROM qpec_reference_words r
)
SELECT
    r.reference_word_id,
    r.reference_word AS "الكلمة_الصحيحة",
    r.surah_name AS "السورة",
    r.ayah_number AS "الآية",
    r.word_position AS "موقع_الكلمة",
    r.pdf_page_number AS "صفحة_PDF",
    r.quran_page_number AS "صفحة_المصحف",

    MAX(CASE WHEN ra.rn = 1 THEN COALESCE(ra.issue_type, ra.compare_status) END) AS "الخطأ_الأول",
    MAX(CASE WHEN ra.rn = 1 THEN ra.extracted_word END) AS "استخراج_1",

    MAX(CASE WHEN ra.rn = 2 THEN COALESCE(ra.issue_type, ra.compare_status) END) AS "الخطأ_الثاني",
    MAX(CASE WHEN ra.rn = 2 THEN ra.extracted_word END) AS "استخراج_2",

    MAX(CASE WHEN ra.rn = 3 THEN COALESCE(ra.issue_type, ra.compare_status) END) AS "الخطأ_الثالث",
    MAX(CASE WHEN ra.rn = 3 THEN ra.extracted_word END) AS "استخراج_3",

    MAX(CASE WHEN ra.rn = 4 THEN COALESCE(ra.issue_type, ra.compare_status) END) AS "الخطأ_الرابع",
    MAX(CASE WHEN ra.rn = 4 THEN ra.extracted_word END) AS "استخراج_4",

    MAX(CASE WHEN ra.rn = 5 THEN COALESCE(ra.issue_type, ra.compare_status) END) AS "الخطأ_الخامس",
    MAX(CASE WHEN ra.rn = 5 THEN ra.extracted_word END) AS "استخراج_5",

    MAX(CASE WHEN ra.rn = 6 THEN COALESCE(ra.issue_type, ra.compare_status) END) AS "الخطأ_السادس",
    MAX(CASE WHEN ra.rn = 6 THEN ra.extracted_word END) AS "استخراج_6",

    ls.final_status AS "آخر_حالة"

FROM qpec_reference_words r
LEFT JOIN ranked_attempts ra ON r.reference_word_id = ra.reference_word_id
LEFT JOIN last_status ls ON r.reference_word_id = ls.reference_word_id
GROUP BY
    r.reference_word_id,
    r.reference_word,
    r.surah_name,
    r.ayah_number,
    r.word_position,
    r.pdf_page_number,
    r.quran_page_number,
    ls.final_status;

-- ============================================================
-- UNIVERSAL KNOWLEDGE WAREHOUSE PHASE 1 SCHEMAS
-- ============================================================

CREATE TABLE IF NOT EXISTS sources (
    source_id TEXT PRIMARY KEY,
    source_type TEXT NOT NULL CHECK (source_type IN (
        'file', 'folder', 'url', 'api', 'database', 'chat',
        'screen', 'audio', 'video', 'image', 'pdf', 'docx',
        'xlsx', 'txt', 'code', 'system', 'unknown'
    )),
    source_name TEXT,
    source_path TEXT,
    source_url TEXT,
    original_hash TEXT,
    size_bytes INTEGER,
    extension TEXT,
    trust_level TEXT NOT NULL DEFAULT 'unknown' CHECK (trust_level IN ('trusted','medium','low','unknown')),
    status TEXT NOT NULL DEFAULT 'received' CHECK (status IN (
        'received', 'scanned', 'processing', 'completed', 'failed', 'blocked', 'archived'
    )),
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS universal_objects (
    object_id TEXT PRIMARY KEY,
    source_id TEXT,
    object_type TEXT NOT NULL CHECK (object_type IN (
        'text', 'word', 'sentence', 'paragraph', 'page', 'book',
        'pdf', 'image', 'video', 'audio', 'screen_text', 'code_file',
        'function', 'class', 'table', 'database', 'person', 'place',
        'concept', 'rule', 'question', 'answer', 'unknown'
    )),
    domain TEXT,
    language TEXT,
    title TEXT,
    summary TEXT,
    raw_path TEXT,
    normalized_path TEXT,
    hash TEXT,
    parent_object_id TEXT,
    status TEXT NOT NULL DEFAULT 'indexed' CHECK (status IN (
        'indexed', 'parsed', 'chunked', 'linked', 'failed', 'blocked', 'review_required'
    )),
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS words (
    word_id TEXT PRIMARY KEY,
    object_id TEXT,
    source_id TEXT,
    language TEXT,
    script TEXT,
    word TEXT NOT NULL,
    normalized_word TEXT,
    root TEXT,
    word_type TEXT CHECK (word_type IN (
        'اسم', 'فعل', 'حرف', 'صفة', 'ضمير', 'أداة', 'اسم_علم', 'unknown'
    )),
    meaning_short TEXT,
    seq_2 TEXT,
    seq_3 TEXT,
    seq_4 TEXT,
    frequency INTEGER NOT NULL DEFAULT 1,
    confidence REAL DEFAULT 0.0,
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS relations (
    relation_id TEXT PRIMARY KEY,
    subject_id TEXT NOT NULL,
    predicate TEXT NOT NULL,
    object_id TEXT NOT NULL,
    relation_type TEXT NOT NULL CHECK (relation_type IN (
        'contains', 'means', 'belongs_to', 'similar_to', 'opposite_of',
        'causes', 'uses', 'depends_on', 'explains', 'mentions',
        'is_part_of', 'generated_from', 'corrects', 'contradicts',
        'feeds', 'produces', 'unknown'
    )),
    confidence REAL DEFAULT 0.0,
    source_id TEXT,
    evidence_object_id TEXT,
    evidence_text TEXT,
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inverted_index (
    index_id TEXT PRIMARY KEY,
    term TEXT NOT NULL,
    normalized_term TEXT NOT NULL,
    object_id TEXT NOT NULL,
    source_id TEXT,
    field_name TEXT DEFAULT 'content',
    position INTEGER,
    language TEXT,
    seq_2 TEXT,
    seq_3 TEXT,
    seq_4 TEXT,
    weight REAL DEFAULT 1.0,
    frequency INTEGER DEFAULT 1,
    review_status TEXT NOT NULL DEFAULT 'pending_review',
    gold_write INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sources_type ON sources(source_type);
CREATE INDEX IF NOT EXISTS idx_sources_hash ON sources(original_hash);
CREATE INDEX IF NOT EXISTS idx_sources_status ON sources(status);

CREATE INDEX IF NOT EXISTS idx_objects_source ON universal_objects(source_id);
CREATE INDEX IF NOT EXISTS idx_objects_type ON universal_objects(object_type);
CREATE INDEX IF NOT EXISTS idx_objects_language ON universal_objects(language);
CREATE INDEX IF NOT EXISTS idx_objects_hash ON universal_objects(hash);
CREATE INDEX IF NOT EXISTS idx_objects_parent ON universal_objects(parent_object_id);

CREATE INDEX IF NOT EXISTS idx_words_word ON words(word);
CREATE INDEX IF NOT EXISTS idx_words_normalized ON words(normalized_word);
CREATE INDEX IF NOT EXISTS idx_words_language ON words(language);
CREATE INDEX IF NOT EXISTS idx_words_seq_2 ON words(seq_2);
CREATE INDEX IF NOT EXISTS idx_words_seq_3 ON words(seq_3);
CREATE INDEX IF NOT EXISTS idx_words_seq_4 ON words(seq_4);
CREATE UNIQUE INDEX IF NOT EXISTS uq_words_language_normalized ON words(language, normalized_word);

CREATE INDEX IF NOT EXISTS idx_rel_subject ON relations(subject_id);
CREATE INDEX IF NOT EXISTS idx_rel_object ON relations(object_id);
CREATE INDEX IF NOT EXISTS idx_rel_predicate ON relations(predicate);
CREATE INDEX IF NOT EXISTS idx_rel_type ON relations(relation_type);
CREATE INDEX IF NOT EXISTS idx_rel_source ON relations(source_id);

CREATE INDEX IF NOT EXISTS idx_search_term ON inverted_index(normalized_term);
CREATE INDEX IF NOT EXISTS idx_search_object ON inverted_index(object_id);
CREATE INDEX IF NOT EXISTS idx_search_source ON inverted_index(source_id);
CREATE INDEX IF NOT EXISTS idx_search_seq_2 ON inverted_index(seq_2);
CREATE INDEX IF NOT EXISTS idx_search_seq_3 ON inverted_index(seq_3);
CREATE INDEX IF NOT EXISTS idx_search_seq_4 ON inverted_index(seq_4);
CREATE INDEX IF NOT EXISTS idx_search_language ON inverted_index(language);
`;

export default function DBManagerPanel() {
  const [sqliteDb, setSqliteDb] = useState<Database | null>(null);
  const [initLoading, setInitLoading] = useState<boolean>(true);
  const [initError, setInitError] = useState<string | null>(null);

  // Excel seed upload state
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<{
    Languages?: any[];
    Language_Letters?: any[];
    Arabic_Letter_Forms?: any[];
    Import_Review?: any[];
  } | null>(null);

  const [validationReport, setValidationReport] = useState<{
    status: 'pass' | 'warning' | 'fail';
    logs: string[];
    languagesCount: number;
    lettersCount: number;
    formsCount: number;
    reviewStatus: string;
  } | null>(null);

  const [importSuccess, setImportSuccess] = useState<boolean>(false);

  // SQLite Console states
  const [sqlQuery, setSqlQuery] = useState<string>(
    `SELECT l.letter, l.letter_name, l.unicode_codepoint, f.isolated, f.initial, f.medial, f.final \nFROM Language_Letters l \nJOIN Arabic_Letter_Forms f ON l.letter_ID = f.letter_ID \nORDER BY l.letter_order LIMIT 5;`
  );
  const [queryResult, setQueryResult] = useState<{
    columns: string[];
    values: any[][];
  } | null>(null);
  const [queryError, setQueryError] = useState<string | null>(null);
  const [queryStats, setQueryStats] = useState<{ rows: number; timeMs: number } | null>(null);

  // QPEC & Warehouse Sub Tab State & Data
  const [activeSubTab, setActiveSubTab] = useState<'letters' | 'qpec' | 'warehouse' | 'interactive_query'>('letters');
  const [qpecRows, setQpecRows] = useState<any[]>([]);
  const [qpecPatterns, setQpecPatterns] = useState<any[]>([]);
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [selectedWordAttempts, setSelectedWordAttempts] = useState<any[]>([]);
  const [qpecMsg, setQpecMsg] = useState<string | null>(null);

  // Interactive Local DB Query States (01_sources.db and 02_universal_index.db)
  const [sourcesDb, setSourcesDb] = useState<Database | null>(null);
  const [universalIndexDb, setUniversalIndexDb] = useState<Database | null>(null);
  const [selectedInteractiveDb, setSelectedInteractiveDb] = useState<'sources' | 'universal_index'>('sources');
  const [sourcesDbFile, setSourcesDbFile] = useState<File | null>(null);
  const [universalIndexDbFile, setUniversalIndexDbFile] = useState<File | null>(null);
  const [interactiveSqlQuery, setInteractiveSqlQuery] = useState<string>('SELECT * FROM sources LIMIT 5;');
  const [interactiveQueryResult, setInteractiveQueryResult] = useState<{
    columns: string[];
    values: any[][];
  } | null>(null);
  const [interactiveQueryError, setInteractiveQueryError] = useState<string | null>(null);
  const [interactiveQueryStats, setInteractiveQueryStats] = useState<{ rows: number; timeMs: number } | null>(null);

  // Universal Knowledge Warehouse States
  const [warehouseInputText, setWarehouseInputText] = useState<string>('فيصل كتب تقرير عن اللغة العربية');
  const [warehouseSourceType, setWarehouseSourceType] = useState<string>('chat');
  const [warehouseSourceName, setWarehouseSourceName] = useState<string>('محادثة المستخدم الفورية');
  const [warehouseTrustLevel, setWarehouseTrustLevel] = useState<'trusted' | 'medium' | 'low'>('trusted');
  const [warehouseMsg, setWarehouseMsg] = useState<string | null>(null);
  const [warehouseSearchQuery, setWarehouseSearchQuery] = useState<string>('');
  const [warehouseSearchResults, setWarehouseSearchResults] = useState<any[]>([]);
  const [warehouseActiveViewTable, setWarehouseActiveViewTable] = useState<'sources' | 'universal_objects' | 'words' | 'relations' | 'inverted_index'>('sources');
  const [warehouseStats, setWarehouseStats] = useState({ sources: 0, objects: 0, words: 0, relations: 0, index: 0 });
  const [warehouseTableRows, setWarehouseTableRows] = useState<any[]>([]);

  // QPEC Error Capture Form Inputs
  const [qpecSurah, setQpecSurah] = useState<string>('الفاتحة');
  const [qpecAyah, setQpecAyah] = useState<number>(2);
  const [qpecWordPos, setQpecWordPos] = useState<number>(5);
  const [qpecCorrect, setQpecCorrect] = useState<string>('الرَّحْمَٰنِ');
  const [qpecWrong, setQpecWrong] = useState<string>('الرحمان');
  const [qpecIssue, setQpecIssue] = useState<string>('missing_character');
  const [qpecPdfPage, setQpecPdfPage] = useState<number>(2);
  const [qpecQuranPage, setQpecQuranPage] = useState<number>(1);

  // Search interface states
  const [searchLetter, setSearchLetter] = useState<string>('');
  const [selectedLangFilter, setSelectedLangFilter] = useState<string>('all');
  const [quickSearchResults, setQuickSearchResults] = useState<any[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Pre-compiled query templates
  const SQL_TEMPLATES = [
    {
      title: 'عرض اللغات المدعومة',
      query: 'SELECT * FROM Languages;'
    },
    {
      title: 'مستودع المعرفة: مصادر المدخلات',
      query: 'SELECT * FROM sources ORDER BY created_at DESC;'
    },
    {
      title: 'مستودع المعرفة: الكائنات المدرجة (universal_objects)',
      query: 'SELECT * FROM universal_objects;'
    },
    {
      title: 'مستودع المعرفة: الكلمات مع الجذور (words)',
      query: 'SELECT word, root, word_type, seq_2, seq_3, seq_4, frequency FROM words;'
    },
    {
      title: 'مستودع المعرفة: علاقات الرسم البياني المعرفي (relations)',
      query: 'SELECT relation_id, subject_id, predicate, object_id, relation_type, confidence FROM relations;'
    },
    {
      title: 'مستودع المعرفة: الفهرس المقلوب للبحث السريع (inverted_index)',
      query: 'SELECT term, object_id, field_name, position, weight FROM inverted_index;'
    },
    {
      title: 'مصفوفة أخطاء استخراج القرآن (Matrix View)',
      query: 'SELECT * FROM qpec_error_matrix_view;'
    },
    {
      title: 'أنماط الأخطاء المتكررة للتدريب (QPEC Patterns)',
      query: 'SELECT * FROM qpec_repeated_error_patterns WHERE occurrence_count > 0 ORDER BY occurrence_count DESC;'
    }
  ];

  // Initialize SQLite Memory DB using WebAssembly port
  useEffect(() => {
    async function initDatabase() {
      try {
        setInitLoading(true);
        // Load WebAssembly runtime from reliable unpkg CDN
        const SQL = await initSqlJs({
          locateFile: file => `https://sql.js.org/dist/${file}`
        });

        const db = new SQL.Database();
        
        // Execute Schema Tables and constraints creation
        db.run(SCHEMA_CODE);

        // Pre-populate with our default Arabic, English, French statistics seed
        // Languages
        db.run(`
          INSERT OR REPLACE INTO Languages (language_ID, language_code, language_name_ar, language_name_native, script_name, direction, has_diacritics, has_letter_forms) VALUES
          ('LANG_AR', 'ar', 'العربية', 'العربية', 'Arabic', 'RTL', 1, 1),
          ('LANG_EN', 'en', 'الإنجليزية', 'English', 'Latin', 'LTR', 0, 0),
          ('LANG_FR', 'fr', 'الفرنسية', 'Français', 'Latin', 'LTR', 1, 0);
        `);

        // Language_Letters (with standard Arabic subset + some sequences e.g. seq_2 / seq_3)
        db.run(`
          INSERT OR REPLACE INTO Language_Letters (letter_ID, language_ID, letter_order, letter, letter_name, normalized_letter, unicode_codepoint, sound_hint, seq_2, seq_3, seq_4) VALUES
          ('AR_LETTER_001', 'LANG_AR', 1, 'ا', 'ألف', 'ا', 'U+0627', 'a', 'AR_SEQ_A1', 'AR_SEQ_A2', 'AR_SEQ_A3'),
          ('AR_LETTER_002', 'LANG_AR', 2, 'ب', 'باء', 'ب', 'U+0628', 'b', 'AR_SEQ_B1', 'AR_SEQ_B2', 'AR_SEQ_B3'),
          ('AR_LETTER_003', 'LANG_AR', 3, 'ت', 'تاء', 'ت', 'U+062A', 't', 'AR_SEQ_T1', 'AR_SEQ_T2', 'AR_SEQ_T3'),
          ('AR_LETTER_004', 'LANG_AR', 4, 'ث', 'ثاء', 'ث', 'U+062B', 'th', 'AR_SEQ_TH1', 'AR_SEQ_TH2', 'AR_SEQ_TH3'),
          ('AR_LETTER_005', 'LANG_AR', 5, 'ج', 'جيم', 'ج', 'U+062C', 'j', 'AR_SEQ_J1', 'AR_SEQ_J2', 'AR_SEQ_J3'),
          ('EN_LETTER_001', 'LANG_EN', 1, 'A', 'A', 'a', 'U+0041', 'ei', NULL, NULL, NULL),
          ('EN_LETTER_002', 'LANG_EN', 2, 'B', 'B', 'b', 'U+0042', 'bi', NULL, NULL, NULL),
          ('FR_LETTER_001', 'LANG_FR', 1, 'A', 'A', 'a', 'U+0041', 'ah', NULL, NULL, NULL);
        `);

        // Arabic_Letter_Forms
        db.run(`
          INSERT OR REPLACE INTO Arabic_Letter_Forms (form_ID, letter_ID, isolated, initial, medial, final) VALUES
          ('AR_FORM_001', 'AR_LETTER_001', 'ا', 'ا', 'ـا', 'ـا'),
          ('AR_FORM_002', 'AR_LETTER_002', 'ب', 'بـ', 'ـبـ', 'ـب'),
          ('AR_FORM_003', 'AR_LETTER_003', 'ت', 'تـ', 'ـتـ', 'ـت');
        `);

        // Import_Review
        db.run(`
          INSERT OR REPLACE INTO Import_Review (reviewer_name, review_status, notes, review_date) VALUES
          ('د. فيصل العفيف', 'APPROVED', 'تم التأسيس التلقائي ومزامنة الجداول القياسية بنجاح.', '2026-06-09');
        `);

        // ==========================================
        // QPEC V1 DEFAULT SCHEMA SEED DATA (POPULATION)
        // ==========================================
        db.run(`
          INSERT OR REPLACE INTO qpec_reference_words (reference_word_id, source_mode, pdf_page_number, quran_page_number, page_offset, surah_number, surah_name, ayah_number, word_position, reference_word, normalized_reference_word, reference_source, reference_trust_status) VALUES
          ('REF_F001', 'ocr_pdf_vs_sqlite_excel', 2, 1, 1, 1, 'الفاتحة', 2, 1, 'الحمد', 'الحمد', 'sqlite_excel_consensus', 'trusted'),
          ('REF_F002', 'ocr_pdf_vs_sqlite_excel', 2, 1, 1, 1, 'الفاتحة', 2, 2, 'لله', 'لله', 'sqlite_excel_consensus', 'trusted'),
          ('REF_F003', 'ocr_pdf_vs_sqlite_excel', 2, 1, 1, 1, 'الفاتحة', 2, 3, 'رب', 'رب', 'sqlite_excel_consensus', 'trusted'),
          ('REF_F004', 'ocr_pdf_vs_sqlite_excel', 2, 1, 1, 1, 'الفاتحة', 2, 4, 'العالمين', 'العالمين', 'sqlite_excel_consensus', 'trusted');
        `);

        db.run(`
          -- Attempts for REF_F001 (الحمد)
          INSERT OR REPLACE INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status) VALUES
          ('ATT_F001_1', 'REF_F001', 1, 'ocr', 'EasyOCR', 'standard_v1', 'الحمذ', 'الحمذ', 2, 1, 1, 'different'),
          ('ATT_F001_2', 'REF_F001', 2, 'ocr', 'EasyOCR', 'standard_v1', 'الحـمد', 'الحمد', 2, 1, 1, 'different'),
          ('ATT_F001_3', 'REF_F001', 3, 'ocr', 'EasyOCR', 'standard_v1', 'الحمد', 'الحمد', 2, 1, 1, 'same');

          -- Error Log reports for REF_F001
          INSERT OR REPLACE INTO qpec_extraction_errors (error_id, reference_word_id, attempt_id, error_round, pdf_page_number, quran_page_number, surah_name, ayah_number, word_position, correct_word, wrong_word, issue_type, status, review_status) VALUES
          ('ERR_F001_1', 'REF_F001', 'ATT_F001_1', 1, 2, 1, 'الفاتحة', 2, 1, 'الحمد', 'الحمذ', 'wrong_character', 'resolved', 'reviewed'),
          ('ERR_F001_2', 'REF_F001', 'ATT_F001_2', 2, 2, 1, 'الفاتحة', 2, 1, 'الحمد', 'الحـمد', 'ocr_noise', 'resolved', 'reviewed');

          -- Complete No error mark
          INSERT OR REPLACE INTO qpec_no_error_marks (mark_id, reference_word_id, attempt_id, attempt_number, pdf_page_number, quran_page_number, word_position, correct_word, extracted_word, status) VALUES
          ('MRK_F001_3', 'REF_F001', 'ATT_F001_3', 3, 2, 1, 1, 'الحمد', 'الحمد', 'resolved_after_previous_error');
        `);

        db.run(`
          -- Attempts for REF_F002 (لله - perfect matched)
          INSERT OR REPLACE INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status) VALUES
          ('ATT_F002_1', 'REF_F002', 1, 'ocr', 'EasyOCR', 'standard_v1', 'لله', 'لله', 2, 1, 2, 'same');

          INSERT OR REPLACE INTO qpec_no_error_marks (mark_id, reference_word_id, attempt_id, attempt_number, pdf_page_number, quran_page_number, word_position, correct_word, extracted_word, status) VALUES
          ('MRK_F002_1', 'REF_F002', 'ATT_F002_1', 1, 2, 1, 2, 'لله', 'لله', 'no_problem');
        `);

        db.run(`
          -- Attempts for REF_F003 (رب)
          INSERT OR REPLACE INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status) VALUES
          ('ATT_F003_1', 'REF_F003', 1, 'ocr', 'EasyOCR', 'standard_v1', 'رپ', 'رپ', 2, 1, 3, 'different'),
          ('ATT_F003_2', 'REF_F003', 2, 'ocr', 'EasyOCR', 'standard_v1', 'ربّ', 'رب', 2, 1, 3, 'different');

          INSERT OR REPLACE INTO qpec_extraction_errors (error_id, reference_word_id, attempt_id, error_round, pdf_page_number, quran_page_number, surah_name, ayah_number, word_position, correct_word, wrong_word, issue_type, status, review_status) VALUES
          ('ERR_F003_1', 'REF_F003', 'ATT_F003_1', 1, 2, 1, 'الفاتحة', 2, 3, 'رب', 'رپ', 'wrong_character', 'open', 'pending_review'),
          ('ERR_F003_2', 'REF_F003', 'ATT_F003_2', 2, 2, 1, 'الفاتحة', 2, 3, 'رب', 'ربّ', 'diacritic_error', 'open', 'pending_review');
        `);

        db.run(`
          -- Attempts for REF_F004 (العالمين)
          INSERT OR REPLACE INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status) VALUES
          ('ATT_F004_1', 'REF_F004', 1, 'ocr', 'EasyOCR', 'standard_v1', 'العلمين', 'العلمين', 2, 1, 4, 'different');

          INSERT OR REPLACE INTO qpec_extraction_errors (error_id, reference_word_id, attempt_id, error_round, pdf_page_number, quran_page_number, surah_name, ayah_number, word_position, correct_word, wrong_word, issue_type, status, review_status) VALUES
          ('ERR_F004_1', 'REF_F004', 'ATT_F004_1', 1, 2, 1, 'الفاتحة', 2, 4, 'العالمين', 'العلمين', 'missing_character', 'open', 'pending_review');
        `);

        db.run(`
          -- Repeated Patterns training catalog data
          INSERT OR REPLACE INTO qpec_repeated_error_patterns (pattern_id, error_signature, issue_type, correct_word, wrong_word, extraction_source, engine_name, engine_profile, occurrence_count, training_value, suggested_rule) VALUES
          ('PAT_01', 'wrong_character|الحمد|الحمذ|EasyOCR', 'wrong_character', 'الحمد', 'الحمذ', 'ocr', 'EasyOCR', 'standard_v1', 14, 'important', 'تحسين تمييز الذال والدال في خطوط المصاحف المكتبية الرقيقة'),
          ('PAT_02', 'missing_character|العالمين|العلمين|EasyOCR', 'missing_character', 'العالمين', 'العلمين', 'ocr', 'EasyOCR', 'standard_v1', 8, 'important', 'تفسير ومعالجة الألف الخنجرية في الطباعة العثمانية لتفادي سقط الالف'),
          ('PAT_03', 'wrong_character|رب|رپ|EasyOCR', 'wrong_character', 'رب', 'رپ', 'ocr', 'EasyOCR', 'standard_v1', 4, 'noise', 'تصحيح الـ Bounding Box لتفادي التقاط ضوضاء الطباعة الفارسية');
        `);

        db.run(`
          -- ==========================================
          -- WAREHOUSE PHASE 1 SEED RECORDS
          -- ==========================================

          -- Seed Sources
          INSERT OR REPLACE INTO sources (source_id, source_type, source_name, source_path, original_hash, size_bytes, extension, trust_level, status, review_status, gold_write)
          VALUES ('SRC_000001', 'chat', 'user_input', 'C:\\unified_ai_system\\02_data_warehouse\\chat_prompt_001.txt', 'e5e9fa1ba31ecd1ae84f75caaa474f3a', 64, 'txt', 'trusted', 'completed', 'reviewed', 0);

          -- Seed Universal Objects
          INSERT OR REPLACE INTO universal_objects (object_id, source_id, object_type, domain, language, title, summary, raw_path, normalized_path, hash, status, review_status, gold_write)
          VALUES ('OBJ_000001', 'SRC_000001', 'sentence', 'NLP Context', 'ar', 'فيصل كتب تقرير عن اللغة العربية', 'إفادة عن كتابة فيصل لتقرير لغوي عربي', 'raw_node_01', 'normalized_node_01', '7cb2cb219eefb2aa13e9a4f75cc75f91', 'linked', 'reviewed', 0);

          -- Seed Words (from Language Core)
          INSERT OR REPLACE INTO words (word_id, object_id, source_id, language, script, word, normalized_word, root, word_type, meaning_short, seq_2, seq_3, seq_4, frequency, confidence, review_status, gold_write)
          VALUES 
          ('W_000001', 'OBJ_000001', 'SRC_000001', 'ar', 'Arabic', 'فيصل', 'فيصل', 'فصل', 'اسم_علم', 'اسم علم مذكر عربي وهو الشخص الفاعل في الجملة', 'فـ', 'فـي', 'فـيـص', 1, 0.98, 'approved', 0),
          ('W_000002', 'OBJ_000001', 'SRC_000001', 'ar', 'Arabic', 'كتب', 'كتب', 'كتب', 'فعل', 'القيام بالكتابة والتدوين الفعلي', 'كـ', 'كـت', 'كـتـب', 1, 0.99, 'approved', 0),
          ('W_000003', 'OBJ_000001', 'SRC_000001', 'ar', 'Arabic', 'تقرير', 'تقرير', 'قرر', 'اسم', 'مستند أو وثيقة تحتوي على تفصيلات', 'تـ', 'تـق', 'تـقـر', 1, 0.95, 'approved', 0),
          ('W_000004', 'OBJ_000001', 'SRC_000001', 'ar', 'Arabic', 'عن', 'عن', NULL, 'حرف', 'حرف جر يفيد المجاوزة أو التعليل الدلالي', 'عـ', 'عـن', 'عـن', 1, 0.99, 'approved', 0),
          ('W_000005', 'OBJ_000001', 'SRC_000001', 'ar', 'Arabic', 'اللغة', 'اللغة', 'لغو', 'اسم', 'اللسان البشري للتواصل', 'اـ', 'الـ', 'الـل', 1, 0.97, 'approved', 0),
          ('W_000006', 'OBJ_000001', 'SRC_000001', 'ar', 'Arabic', 'العربية', 'العربية', 'عرب', 'صفة', 'نسبة إلى لغة وأمة العرب وهي المعرفة المستهدفة', 'اـ', 'الـ', 'الـع', 1, 0.98, 'approved', 0);

          -- Seed Relations (Knowledge Graph)
          INSERT OR REPLACE INTO relations (relation_id, subject_id, predicate, object_id, relation_type, confidence, source_id, evidence_text, review_status, gold_write)
          VALUES 
          ('REL_000001', 'OBJ_000001', 'contains', 'W_000001', 'contains', 1.0, 'SRC_000001', 'فيصل كتب تقرير عن اللغة العربية', 'approved', 0),
          ('REL_000002', 'OBJ_000001', 'contains', 'W_000002', 'contains', 1.0, 'SRC_000001', 'فيصل كتب تقرير عن اللغة العربية', 'approved', 0),
          ('REL_000003', 'W_000002', 'action_by', 'W_000001', 'unknown', 0.92, 'SRC_000001', 'فيصل كتب', 'approved', 0),
          ('REL_000004', 'W_000003', 'topic', 'W_000005', 'mentions', 0.89, 'SRC_000001', 'تقرير عن اللغة العربية', 'approved', 0);

          -- Seed Inverted Index (Search Engine)
          INSERT OR REPLACE INTO inverted_index (index_id, term, normalized_term, object_id, source_id, field_name, position, language, seq_2, seq_3, seq_4, weight, frequency, review_status, gold_write)
          VALUES
          ('IDX_000001', 'فيصل', 'فيصل', 'OBJ_000001', 'SRC_000001', 'title', 1, 'ar', 'فـ', 'فـي', 'فـيـص', 1.2, 1, 'approved', 0),
          ('IDX_000002', 'كتب', 'كتب', 'OBJ_000001', 'SRC_000001', 'title', 2, 'ar', 'كـ', 'كـت', 'كـتـب', 1.0, 1, 'approved', 0),
          ('IDX_000003', 'تقرير', 'تقرير', 'OBJ_000001', 'SRC_000001', 'title', 3, 'ar', 'تـ', 'تـق', 'تـقـر', 1.0, 1, 'approved', 0),
          ('IDX_000004', 'اللغة', 'اللغة', 'OBJ_000001', 'SRC_000001', 'title', 5, 'ar', 'اـ', 'الـ', 'الـل', 1.0, 1, 'approved', 0),
          ('IDX_000005', 'العربية', 'العربية', 'OBJ_000001', 'SRC_000001', 'title', 6, 'ar', 'اـ', 'الـ', 'الـع', 1.5, 1, 'approved', 0);
        `);

        fetchQpecData(db);
        fetchWarehouseStats(db);
        fetchWarehouseTableRows('sources', db);

        // Pre-initialize our double local DB systems: 01_sources.db and 02_universal_index.db
        const sDb = new SQL.Database();
        sDb.run(`
          CREATE TABLE IF NOT EXISTS sources (
              source_id TEXT PRIMARY KEY,
              source_type TEXT NOT NULL,
              source_name TEXT NOT NULL,
              source_path TEXT,
              original_hash TEXT,
              size_bytes INTEGER,
              extension TEXT,
              trust_level TEXT,
              status TEXT,
              review_status TEXT,
              gold_write INTEGER DEFAULT 0,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
          );

          INSERT OR REPLACE INTO sources (source_id, source_type, source_name, source_path, original_hash, size_bytes, extension, trust_level, status, review_status, gold_write)
          VALUES 
          ('SRC_01_Q_TXT', 'file', 'quran_text_source.txt', 'D:\\OneDrive\\Desktop\\5656\\quran_text_source.txt', 'e5e9fa1ba31ecd1ae84f75caaa474f3a', 836102, 'txt', 'trusted', 'completed', 'reviewed', 0),
          ('SRC_02_Q_XLS', 'file', 'quran_master78.xlsx', 'D:\\OneDrive\\Desktop\\5656\\quran_master78.xlsx', '9bbaf71ba11ecd2ae34f23caa1234f9a', 1048576, 'xlsx', 'trusted', 'completed', 'reviewed', 0),
          ('SRC_03_Q_PDF', 'file', 'quran_text_source.pdf', 'D:\\OneDrive\\Desktop\\5656\\quran_text_source.pdf', 'fe12fa92031ecd3ae81f12caaa114f2c', 3456712, 'pdf', 'trusted', 'completed', 'reviewed', 0),
          ('SRC_04_Q_DOCX', 'file', 'quran_text_source.docx', 'D:\\OneDrive\\Desktop\\5656\\quran_text_source.docx', 'c3ba811ba31ecd4ae84f72ccbb472ea9', 156102, 'docx', 'trusted', 'completed', 'reviewed', 0),
          ('SRC_05_AR_TXT', 'file', 'ar.txt', 'D:\\OneDrive\\Desktop\\5656\\ar.txt', 'ab11fa2ea31ecd5ae84f71bbbb888fa5', 5120, 'txt', 'medium', 'completed', 'reviewed', 0),
          ('SRC_06_AR_CHR', 'file', 'ar_char.txt', 'D:\\OneDrive\\Desktop\\5656\\ar_char.txt', '1209fa88e31ecd6ae84f79cca123aa12', 1024, 'txt', 'medium', 'completed', 'reviewed', 0);
        `);

        const uDb = new SQL.Database();
        uDb.run(`
          CREATE TABLE IF NOT EXISTS universal_objects (
              object_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              object_type TEXT NOT NULL,
              domain TEXT,
              language TEXT DEFAULT 'ar',
              title TEXT,
              summary TEXT,
              hash TEXT,
              status TEXT,
              review_status TEXT,
              gold_write INTEGER DEFAULT 0
          );

          CREATE TABLE IF NOT EXISTS words (
              word_id TEXT PRIMARY KEY,
              object_id TEXT,
              source_id TEXT,
              language TEXT DEFAULT 'ar',
              script TEXT DEFAULT 'Arabic',
              word TEXT NOT NULL,
              normalized_word TEXT,
              root TEXT,
              word_type TEXT,
              meaning_short TEXT,
              seq_2 TEXT,
              seq_3 TEXT,
              seq_4 TEXT,
              frequency INTEGER DEFAULT 1,
              confidence REAL DEFAULT 1.0,
              review_status TEXT DEFAULT 'pending'
          );

          CREATE TABLE IF NOT EXISTS relations (
              relation_id TEXT PRIMARY KEY,
              subject_id TEXT,
              predicate TEXT,
              object_id TEXT,
              relation_type TEXT,
              confidence REAL DEFAULT 1.0,
              source_id TEXT,
              evidence_text TEXT,
              review_status TEXT DEFAULT 'pending_review'
          );

          CREATE TABLE IF NOT EXISTS inverted_index (
              index_id TEXT PRIMARY KEY,
              term TEXT,
              normalized_term TEXT,
              object_id TEXT,
              source_id TEXT,
              field_name TEXT,
              position INTEGER,
              language TEXT DEFAULT 'ar',
              seq_2 TEXT,
              seq_3 TEXT,
              seq_4 TEXT,
              weight REAL DEFAULT 1.0,
              frequency INTEGER DEFAULT 1,
              review_status TEXT DEFAULT 'pending'
          );

          INSERT OR REPLACE INTO universal_objects (object_id, source_id, object_type, domain, language, title, summary, hash, status, review_status, gold_write)
          VALUES 
          ('OBJ_Q001', 'SRC_01_Q_TXT', 'ayah', 'Quranic Verse', 'ar', 'بسم الله الرحمن الرحيم', 'سورة الفاتحة - آية 1', 'h_01', 'linked', 'reviewed', 0),
          ('OBJ_Q002', 'SRC_01_Q_TXT', 'ayah', 'Quranic Verse', 'ar', 'الحمد لله رب العالمين', 'سورة الفاتحة - آية 2', 'h_02', 'linked', 'reviewed', 0);

          INSERT OR REPLACE INTO words (word_id, object_id, source_id, word, normalized_word, root, word_type, meaning_short, seq_2, seq_3, seq_4, frequency)
          VALUES 
          ('W_Q001_1', 'OBJ_Q001', 'SRC_01_Q_TXT', 'بسم', 'بسم', 'سمو', 'اسم', 'حرف الجر الباء مدمج مع اسم', 'بـ', 'بـس', 'بـسـم', 1),
          ('W_Q001_2', 'OBJ_Q001', 'SRC_01_Q_TXT', 'الله', 'الله', 'أله', 'اسم_علم', 'لفظ الجلالة المعظم جل جلاله', 'اـ', 'الـ', 'الـل', 1),
          ('W_Q001_3', 'OBJ_Q001', 'SRC_01_Q_TXT', 'الرحمن', 'الرحمن', 'رحم', 'صفة', 'صيغة صفة مبالغة تدل على سعة الرحمة', 'اـ', 'الـ', 'الـر', 1),
          ('W_Q001_4', 'OBJ_Q001', 'SRC_01_Q_TXT', 'الرحيم', 'الرحيم', 'رحم', 'صفة', 'صفة تدل على إيصال الرحمة للمرحومين', 'اـ', 'الـ', 'الـر', 1),
          ('W_Q002_1', 'OBJ_Q002', 'SRC_01_Q_TXT', 'الحمد', 'الحمد', 'حمد', 'اسم', 'الثناء الجميل على جهة التعظيم باللسان', 'اـ', 'الـ', 'الـح', 1),
          ('W_Q002_2', 'OBJ_Q002', 'SRC_01_Q_TXT', 'لله', 'لله', 'أله', 'مجرور', 'الجار والمجرور لرب العالمين', 'لـ', 'لـل', 'لـلـه', 1),
          ('W_Q002_3', 'OBJ_Q002', 'SRC_01_Q_TXT', 'رب', 'رب', 'ربب', 'اسم', 'المالك والمصلح والمعبود والمنعم سبحانه', 'رـ', 'ربـ', 'ربـ', 1),
          ('W_Q002_4', 'OBJ_Q002', 'SRC_01_Q_TXT', 'العالمين', 'العالمين', 'علم', 'اسم', 'جمع عالم وهو كل ما سوى الله تعالى', 'اـ', 'الـ', 'الـع', 1);

          INSERT OR REPLACE INTO relations (relation_id, subject_id, predicate, object_id, relation_type, confidence, source_id, evidence_text, review_status)
          VALUES 
          ('REL_Q001', 'W_Q002_3', 'modifier_of', 'W_Q002_4', 'genitive_annexation', 0.99, 'SRC_01_Q_TXT', 'رب العالمين', 'approved'),
          ('REL_Q002', 'W_Q002_1', 'allocated_to', 'W_Q002_2', 'praise_dedication', 0.98, 'SRC_01_Q_TXT', 'الحمد لله', 'approved');

          INSERT OR REPLACE INTO inverted_index (index_id, term, normalized_term, object_id, source_id, field_name, position, seq_2, seq_3, seq_4, weight)
          VALUES
          ('IDX_Q001', 'بسم', 'بسم', 'OBJ_Q001', 'SRC_01_Q_TXT', 'text', 1, 'بـ', 'بـس', 'بـسـم', 1.0),
          ('IDX_Q002', 'الله', 'الله', 'OBJ_Q001', 'SRC_01_Q_TXT', 'text', 2, 'اـ', 'الـ', 'الـل', 1.5),
          ('IDX_Q003', 'الرحمن', 'الرحمن', 'OBJ_Q001', 'SRC_01_Q_TXT', 'text', 3, 'اـ', 'الـ', 'الـر', 1.2),
          ('IDX_Q004', 'الرحيم', 'الرحيم', 'OBJ_Q001', 'SRC_01_Q_TXT', 'text', 4, 'اـ', 'الـ', 'الـر', 1.2),
          ('IDX_Q005', 'الحمد', 'الحمد', 'OBJ_Q002', 'SRC_01_Q_TXT', 'text', 1, 'اـ', 'الـ', 'الـح', 1.0);
        `);

        setSourcesDb(sDb);
        setUniversalIndexDb(uDb);

        setSqliteDb(db);
        setInitLoading(false);
      } catch (err: any) {
        console.error('SQLite initialization failed:', err);
        setInitError(err?.message || 'فشل تحميل مكتبة SQL.js سحابياً.');
        setInitLoading(false);
      }
    }

    initDatabase();
  }, []);

  // Fetch QPEC dynamic matrix data helper
  const fetchQpecData = (dbInstance = sqliteDb) => {
    if (!dbInstance) return;
    try {
      const matrixRes = dbInstance.exec(`SELECT * FROM qpec_error_matrix_view;`);
      if (matrixRes && matrixRes.length > 0) {
        const cols = matrixRes[0].columns;
        const mapped = matrixRes[0].values.map((v: any[]) => {
          const robj: any = {};
          cols.forEach((col: string, idx: number) => {
            robj[col] = v[idx];
          });
          return robj;
        });
        setQpecRows(mapped);
      } else {
        setQpecRows([]);
      }

      const patternsRes = dbInstance.exec(`SELECT * FROM qpec_repeated_error_patterns ORDER BY occurrence_count DESC;`);
      if (patternsRes && patternsRes.length > 0) {
        const cols = patternsRes[0].columns;
        const mapped = patternsRes[0].values.map((v: any[]) => {
          const robj: any = {};
          cols.forEach((col: string, idx: number) => {
            robj[col] = v[idx];
          });
          return robj;
        });
        setQpecPatterns(mapped);
      } else {
        setQpecPatterns([]);
      }

      // If a word is selected, update details on the fly
      if (selectedWordId) {
        handleInspectWordAttempts(selectedWordId, dbInstance);
      }
    } catch (e) {
      console.error("Error fetching QPEC data:", e);
    }
  };

  // Fetch warehouse stats
  const fetchWarehouseStats = (dbInstance = sqliteDb) => {
    if (!dbInstance) return;
    try {
      const statsObj = { sources: 0, objects: 0, words: 0, relations: 0, index: 0 };
      const sRes = dbInstance.exec("SELECT COUNT(*) FROM sources;");
      if (sRes.length > 0) statsObj.sources = sRes[0].values[0][0] as number;
      
      const oRes = dbInstance.exec("SELECT COUNT(*) FROM universal_objects;");
      if (oRes.length > 0) statsObj.objects = oRes[0].values[0][0] as number;
      
      const wRes = dbInstance.exec("SELECT COUNT(*) FROM words;");
      if (wRes.length > 0) statsObj.words = wRes[0].values[0][0] as number;
      
      const rRes = dbInstance.exec("SELECT COUNT(*) FROM relations;");
      if (rRes.length > 0) statsObj.relations = rRes[0].values[0][0] as number;
      
      const iRes = dbInstance.exec("SELECT COUNT(*) FROM inverted_index;");
      if (iRes.length > 0) statsObj.index = iRes[0].values[0][0] as number;
      
      setWarehouseStats(statsObj);
    } catch (err) {
      console.error("Error fetching warehouse stats:", err);
    }
  };

  // Fetch individual table rows for visual rendering
  const fetchWarehouseTableRows = (tableName: string, dbInstance = sqliteDb) => {
    if (!dbInstance) return;
    try {
      const res = dbInstance.exec(`SELECT * FROM ${tableName} ORDER BY 1 DESC LIMIT 30;`);
      if (res && res.length > 0) {
        const cols = res[0].columns;
        const mapped = res[0].values.map((v: any[]) => {
          const robj: any = {};
          cols.forEach((col: string, idx: number) => {
            robj[col] = v[idx];
          });
          return robj;
        });
        setWarehouseTableRows(mapped);
      } else {
        setWarehouseTableRows([]);
      }
    } catch (e) {
      console.error("Error fetching table rows:", e);
    }
  };

  // Run search across inverted index
  const handleWarehouseSearch = (forceQuery?: string, dbInstance = sqliteDb) => {
    if (!dbInstance) return;
    const target = forceQuery !== undefined ? forceQuery : warehouseSearchQuery;
    if (!target.trim()) {
      setWarehouseSearchResults([]);
      return;
    }
    try {
      // Find matches in inverted index and join with object and words
      const result = dbInstance.exec(`
        SELECT DISTINCT 
          i.term as "الكلمة",
          o.title as "العنوان_الكامل",
          o.domain as "المجال",
          i.field_name as "الحقل",
          i.position as "الموضع",
          i.weight as "الوزن"
        FROM inverted_index i
        JOIN universal_objects o ON i.object_id = o.object_id
        WHERE i.term LIKE '%${target}%' OR i.normalized_term LIKE '%${target}%' 
        LIMIT 15;
      `);
      if (result && result.length > 0) {
        const cols = result[0].columns;
        const mapped = result[0].values.map((val: any[]) => {
          const item: any = {};
          cols.forEach((c, idx) => {
            item[c] = val[idx];
          });
          return item;
        });
        setWarehouseSearchResults(mapped);
      } else {
        setWarehouseSearchResults([]);
      }
    } catch (err: any) {
      console.error("Search error:", err);
    }
  };

  // Ingest NLP text parser pipeline
  const handleIngestToWarehouse = () => {
    if (!sqliteDb) return;
    if (!warehouseInputText.trim()) {
      setWarehouseMsg("خطأ: يرجى كتابة نص المدخل أولاً.");
      return;
    }

    try {
      const srcId = 'SRC_' + Math.floor(100000 + Math.random() * 900000);
      const objId = 'OBJ_' + Math.floor(100000 + Math.random() * 900000);
      const wordsInText = warehouseInputText.trim().split(/\s+/).filter(Boolean);

      // Simple Arabic normalization
      const stripDiacritics = (txt: string) => txt.replace(/[\u064B-\u0652]/g, "");

      // 1) Insert Source
      sqliteDb.run(`
        INSERT INTO sources (source_id, source_type, source_name, original_hash, trust_level, status)
        VALUES (?, ?, ?, ?, ?, 'completed');
      `, [
        srcId,
        warehouseSourceType,
        warehouseSourceName,
        'hash_' + Math.floor(Math.random() * 1000000),
        warehouseTrustLevel
      ]);

      // 2) Insert Universal Object
      sqliteDb.run(`
        INSERT INTO universal_objects (object_id, source_id, object_type, domain, language, title, summary, status)
        VALUES (?, ?, 'sentence', 'NLP Context', 'ar', ?, ?, 'linked');
      `, [
        objId,
        srcId,
        warehouseInputText,
        `تحليل لغوي تلقائي للمدخل بسعة ${wordsInText.length} كلمات`
      ]);

      // 3) Ingest Words, Relations, and Inverted Index
      let wordCount = 0;
      wordsInText.forEach((rawWord, idx) => {
        const cleanWord = stripDiacritics(rawWord);
        if (!cleanWord) return;

        const wordId = 'W_' + Math.floor(100000 + Math.random() * 900000);
        wordCount++;

        // Basic sequence calculation
        const seq2 = cleanWord.length >= 2 ? cleanWord.substring(0, 2) : cleanWord;
        const seq3 = cleanWord.length >= 3 ? cleanWord.substring(0, 3) : cleanWord;
        const seq4 = cleanWord.length >= 4 ? cleanWord.substring(0, 4) : cleanWord;

        // Guess word type / root
        let type = 'unknown';
        let rootCandidate = cleanWord.substring(0, 3);
        if (cleanWord.length <= 3) {
          type = 'حرف';
          rootCandidate = null;
        } else if (cleanWord.startsWith('ال')) {
          type = 'اسم';
          rootCandidate = cleanWord.substring(2, 5);
        } else if (cleanWord.length > 4) {
          type = 'فعل';
        }

        // Insert into Words
        sqliteDb.run(`
          INSERT OR REPLACE INTO words (word_id, object_id, source_id, language, script, word, normalized_word, root, word_type, seq_2, seq_3, seq_4, frequency, confidence, review_status)
          VALUES (?, ?, ?, 'ar', 'Arabic', ?, ?, ?, ?, ?, ?, ?, 1, 0.90, 'pending_review');
        `, [
          wordId,
          objId,
          srcId,
          rawWord,
          cleanWord,
          rootCandidate,
          type,
          seq2,
          seq3,
          seq4
        ]);

        // Insert into Inverted Index
        sqliteDb.run(`
          INSERT INTO inverted_index (index_id, term, normalized_term, object_id, source_id, position, language, seq_2, seq_3, seq_4, weight)
          VALUES (?, ?, ?, ?, ?, ?, 'ar', ?, ?, ?, 1.2);
        `, [
          'IDX_' + Math.floor(100000 + Math.random() * 900000),
          rawWord,
          cleanWord,
          objId,
          srcId,
          idx + 1,
          seq2,
          seq3,
          seq4
        ]);

        // Ingest containment relation
        sqliteDb.run(`
          INSERT INTO relations (relation_id, subject_id, predicate, object_id, relation_type, confidence, source_id, evidence_text)
          VALUES (?, ?, 'contains', ?, 'contains', 1.0, ?, ?);
        `, [
          'REL_' + Math.floor(100000 + Math.random() * 900000),
          objId,
          wordId,
          srcId,
          rawWord
        ]);
      });

      // Fetch updated stats
      fetchWarehouseStats();
      fetchWarehouseTableRows(warehouseActiveViewTable);
      setWarehouseMsg(`نجاح: تم معالجة وإدخال النص إلى المستودع. سجلنا 1 مصدر، 1 كائن معرفي، ${wordCount} كائن لغوي (كلمة) مفهرسة مع بناء الرسم البياني بالكامل!`);
    } catch (err: any) {
      setWarehouseMsg("فشل خط المعالجة: " + err.message);
    }
  };

  // Inspect attempts on a single reference word
  const handleInspectWordAttempts = (wordId: string, dbInstance = sqliteDb) => {
    if (!dbInstance) return;
    try {
      const res = dbInstance.exec(`
        SELECT attempt_number, extraction_source, engine_name, engine_profile, extracted_word, compare_status, created_at
        FROM qpec_extraction_attempts
        WHERE reference_word_id = '${wordId}'
        ORDER BY attempt_number ASC;
      `);
      if (res && res.length > 0) {
        const cols = res[0].columns;
        const mapped = res[0].values.map((v: any[]) => {
          const robj: any = {};
          cols.forEach((col: string, idx: number) => {
            robj[col] = v[idx];
          });
          return robj;
        });
        setSelectedWordAttempts(mapped);
      } else {
        setSelectedWordAttempts([]);
      }
    } catch (e) {
      console.error("Error looking up attempts:", e);
    }
  };

  const handleAddNewQpecError = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!sqliteDb) {
      alert("محرك SQLite غير متصل حالياً.");
      return;
    }

    try {
      const refWordId = `REF_CUSTOM_${Date.now()}`;
      const attemptId = `ATT_CUSTOM_${Date.now()}`;
      const errorId = `ERR_CUSTOM_${Date.now()}`;

      // Check if word entry already registered
      const checkWord = sqliteDb.exec(`
        SELECT reference_word_id FROM qpec_reference_words
        WHERE surah_name = '${qpecSurah}' AND ayah_number = ${qpecAyah} AND word_position = ${qpecWordPos};
      `);

      let targetRefId = refWordId;
      if (checkWord && checkWord.length > 0 && checkWord[0].values.length > 0) {
        targetRefId = String(checkWord[0].values[0][0]);
      } else {
        sqliteDb.run(`
          INSERT INTO qpec_reference_words (reference_word_id, source_mode, pdf_page_number, quran_page_number, page_offset, surah_number, surah_name, ayah_number, word_position, reference_word, normalized_reference_word, reference_source, reference_trust_status)
          VALUES ('${targetRefId}', 'ocr_pdf_vs_sqlite_excel', ${qpecPdfPage}, ${qpecQuranPage}, ${qpecPdfPage - qpecQuranPage}, 1, '${qpecSurah}', ${qpecAyah}, ${qpecWordPos}, '${qpecCorrect}', '${qpecCorrect}', 'sqlite_excel_consensus', 'trusted');
        `);
      }

      // Fetch dynamic attempt count
      const attCount = sqliteDb.exec(`SELECT COUNT(*) FROM qpec_extraction_attempts WHERE reference_word_id = '${targetRefId}';`);
      const nextAttemptNumber = attCount && attCount[0] ? Number(attCount[0].values[0][0]) + 1 : 1;

      const isSameWord = qpecCorrect.trim() === qpecWrong.trim();
      const compareStatus = isSameWord ? 'same' : 'different';

      // Insert fresh entry into attempts
      sqliteDb.run(`
        INSERT INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status)
        VALUES ('${attemptId}', '${targetRefId}', ${nextAttemptNumber}, 'ocr', 'EasyOCR', 'standard_v1', '${qpecWrong}', '${qpecWrong}', ${qpecPdfPage}, ${qpecQuranPage}, ${qpecWordPos}, '${compareStatus}');
      `);

      if (!isSameWord) {
        // Log Error Record
        sqliteDb.run(`
          INSERT INTO qpec_extraction_errors (error_id, reference_word_id, attempt_id, error_round, pdf_page_number, quran_page_number, surah_number, surah_name, ayah_number, word_position, correct_word, wrong_word, issue_type, status)
          VALUES ('${errorId}', '${targetRefId}', '${attemptId}', ${nextAttemptNumber}, ${qpecPdfPage}, ${qpecQuranPage}, 1, '${qpecSurah}', ${qpecAyah}, ${qpecWordPos}, '${qpecCorrect}', '${qpecWrong}', '${qpecIssue}', 'open');
        `);

        // Register pattern matching
        const signatureStr = `${qpecIssue}|${qpecCorrect}|${qpecWrong}|EasyOCR`;
        const checkPat = sqliteDb.exec(`SELECT pattern_id, occurrence_count FROM qpec_repeated_error_patterns WHERE error_signature = '${signatureStr}';`);
        if (checkPat && checkPat.length > 0 && checkPat[0].values.length > 0) {
          const patId = checkPat[0].values[0][0];
          const nextCount = Number(checkPat[0].values[0][1]) + 1;
          sqliteDb.run(`UPDATE qpec_repeated_error_patterns SET occurrence_count = ${nextCount}, last_seen_at = CURRENT_TIMESTAMP WHERE pattern_id = '${patId}';`);
        } else {
          sqliteDb.run(`
            INSERT INTO qpec_repeated_error_patterns (pattern_id, error_signature, issue_type, correct_word, wrong_word, extraction_source, engine_name, engine_profile, occurrence_count, training_value)
            VALUES ('PAT_C_${Date.now()}', '${signatureStr}', '${qpecIssue}', '${qpecCorrect}', '${qpecWrong}', 'ocr', 'EasyOCR', 'standard_v1', 1, 'candidate');
          `);
        }
      } else {
        // Register Correct Match
        sqliteDb.run(`
          INSERT INTO qpec_no_error_marks (mark_id, reference_word_id, attempt_id, attempt_number, pdf_page_number, quran_page_number, word_position, correct_word, extracted_word, status)
          VALUES ('MRK_C_${Date.now()}', '${targetRefId}', '${attemptId}', ${nextAttemptNumber}, ${qpecPdfPage}, ${qpecQuranPage}, ${qpecWordPos}, '${qpecCorrect}', '${qpecWrong}', 'resolved_after_previous_error');
        `);
      }

      setQpecMsg("✓ تم تسجيل خطأ الاستخلاص وتحديث مصفوفة الأخطاء والمحاولات بنجاح!");
      fetchQpecData();
      setQpecWrong('');
      setTimeout(() => setQpecMsg(null), 4000);
    } catch (e: any) {
      alert("خطأ أثناء كتابة السجل في SQLite: " + e.message);
    }
  };

  const handleSimulateOCRRun = () => {
    if (!sqliteDb) return;
    try {
      setQpecMsg("جاري تشغيل محاكاة المعالجة المتقدمة لـ EasyOCR ورسم النتائج...");
      
      const openRefWords = sqliteDb.exec(`
        SELECT reference_word_id, reference_word, surah_name, ayah_number, word_position, pdf_page_number, quran_page_number 
        FROM qpec_reference_words
        WHERE reference_word_id NOT IN (SELECT reference_word_id FROM qpec_no_error_marks);
      `);

      if (openRefWords && openRefWords.length > 0 && openRefWords[0].values.length > 0) {
        openRefWords[0].values.forEach((row: any[]) => {
          const refWordId = String(row[0]);
          const refWord = String(row[1]);
          const surah = String(row[2]);
          const ayah = Number(row[3]);
          const pos = Number(row[4]);
          const pdfPg = Number(row[5]);
          const quranPg = Number(row[6]);

          const attsCountRes = sqliteDb.exec(`SELECT COUNT(*) FROM qpec_extraction_attempts WHERE reference_word_id = '${refWordId}';`);
          const attemptNumber = attsCountRes && attsCountRes[0] ? Number(attsCountRes[0].values[0][0]) + 1 : 1;
          const attemptId = `ATT_SIM_${attemptNumber}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

          // Correct match attempt
          sqliteDb.run(`
            INSERT INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status)
            VALUES ('${attemptId}', '${refWordId}', ${attemptNumber}, 'ocr', 'EasyOCR', 'reoptimized_v2', '${refWord}', '${refWord}', ${pdfPg}, ${quranPg}, ${pos}, 'same');
          `);

          // Mark resolved
          const markId = `MRK_SIM_${attemptNumber}_${Date.now()}`;
          sqliteDb.run(`
            INSERT INTO qpec_no_error_marks (mark_id, reference_word_id, attempt_id, attempt_number, pdf_page_number, quran_page_number, word_position, correct_word, extracted_word, status)
            VALUES ('${markId}', '${refWordId}', '${attemptId}', ${attemptNumber}, ${pdfPg}, ${quranPg}, ${pos}, '${refWord}', '${refWord}', 'resolved_after_previous_error');
          `);
        });
        setQpecMsg("✓ محاكاة ناجحة! لقد تم إعادة تشغيل EasyOCR وتصحيح الكلمات المعلقة وتحويل حالتها تلقائياً إلى 'محلولة (resolved)' بنجاح!");
      } else {
        // If all resolved, inject a new word with errors to demonstrate transition
        const randId = `REF_SIM_NEW_${Date.now()}`;
        const attId = `ATT_SIM_NEW_${Date.now()}`;
        const errId = `ERR_SIM_NEW_${Date.now()}`;

        sqliteDb.run(`
          INSERT INTO qpec_reference_words (reference_word_id, source_mode, pdf_page_number, quran_page_number, page_offset, surah_number, surah_name, ayah_number, word_position, reference_word, normalized_reference_word, reference_source, reference_trust_status)
          VALUES ('${randId}', 'ocr_pdf_vs_sqlite_excel', 3, 2, 1, 1, 'الفاتحة', 5, 1, 'إياك', 'إياك', 'sqlite_excel_consensus', 'trusted');
        `);

        sqliteDb.run(`
          INSERT INTO qpec_extraction_attempts (attempt_id, reference_word_id, attempt_number, extraction_source, engine_name, engine_profile, extracted_word, normalized_extracted_word, pdf_page_number, quran_page_number, word_position, compare_status)
          VALUES ('${attId}', '${randId}', 1, 'ocr', 'EasyOCR', 'standard_v1', 'اياك', 'اياك', 3, 2, 1, 'different');
        `);

        sqliteDb.run(`
          INSERT INTO qpec_extraction_errors (error_id, reference_word_id, attempt_id, error_round, pdf_page_number, quran_page_number, surah_number, surah_name, ayah_number, word_position, correct_word, wrong_word, issue_type, status)
          VALUES ('${errId}', '${randId}', '${attId}', 1, 3, 2, 1, 'الفاتحة', 5, 1, 'إياك', 'اياك', 'diacritic_error', 'open');
        `);

        setQpecMsg("✓ تم حقن كلمة اختبار جديدة ('إياك' استخرجت 'اياك' بصفحة المراجعة). اضغط زر المحاكاة مرة أخرى لتصحيحها!");
      }

      fetchQpecData();
    } catch (e: any) {
      alert("فشل المحاكاة: " + e.message);
    }
  };

  const handleDownloadQpecMatrix = () => {
    try {
      if (qpecRows.length === 0) {
        alert("لا توجد مذكرات أو أخطاء استخلاص لتصديرها.");
        return;
      }
      const exportRows = qpecRows.map(row => ({
        'الكلمة المرجعية': row.الكلمة_الصحيحة,
        'السورة': row.السورة,
        'الآية': row.الآية,
         'موقع الكلمة': row.موقع_الكلمة,
         'صفحة PDF': row.صفحة_PDF,
         'صفحة المصحف': row.صفحة_المصحف,
         'الخطأ الأول': row.الخطأ_الأول,
         'استخراج 1': row.استخراج_1,
         'الخطأ الثاني': row.الخطأ_الثاني,
         'استخراج 2': row.استخراج_2,
         'آخر حالة': row.آخر_حالة === 'resolved' ? 'محلولة بالتصنيفات' : row.آخر_حالة === 'has_errors' ? 'خطأ معلق' : 'سليمة كليا'
      }));

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(exportRows);
      XLSX.utils.book_append_sheet(wb, ws, 'QPEC Matrix');
      XLSX.writeFile(wb, 'qpec_extraction_matrix_report.xlsx');
    } catch (e: any) {
      alert("فشل تصدير التقرير: " + e.message);
    }
  };

  // Update dynamic search results whenever letters search terms are updated
  useEffect(() => {
    if (!sqliteDb) return;
    try {
      let query = `
        SELECT l.letter_ID, l.letter, l.letter_name, l.unicode_codepoint, l.sound_hint, g.language_name_ar, l.seq_2
        FROM Language_Letters l
        JOIN Languages g ON l.language_ID = g.language_ID
        WHERE 1=1
      `;
      const params: any[] = [];
      if (searchLetter.trim()) {
        query += ` AND (l.letter LIKE ? OR l.letter_name LIKE ? OR l.unicode_codepoint LIKE ?)`;
        params.push(`%${searchLetter.trim()}%`, `%${searchLetter.trim()}%`, `%${searchLetter.trim()}%`);
      }
      if (selectedLangFilter !== 'all') {
        query += ` AND l.language_ID = ?`;
        params.push(selectedLangFilter);
      }
      query += ` ORDER BY l.letter_order ASC LIMIT 20;`;

      const stmt = sqliteDb.prepare(query);
      stmt.bind(params);
      const results = [];
      while (stmt.step()) {
        const row = stmt.getAsObject();
        results.push(row);
      }
      stmt.free();
      setQuickSearchResults(results);
    } catch (e) {
      console.error('Quick search query failure:', e);
    }
  }, [searchLetter, selectedLangFilter, sqliteDb, importSuccess]);

  // Download template on the fly
  const handleDownloadTemplate = () => {
    try {
      const languagesData = [
        { language_ID: 'LANG_AR', language_code: 'ar', language_name_ar: 'العربية', language_name_native: 'العربية', script_name: 'Arabic', direction: 'RTL', has_diacritics: 1, has_letter_forms: 1 },
        { language_ID: 'LANG_EN', language_code: 'en', language_name_ar: 'الإنجليزية', language_name_native: 'English', script_name: 'Latin', direction: 'LTR', has_diacritics: 0, has_letter_forms: 0 },
        { language_ID: 'LANG_FR', language_code: 'fr', language_name_ar: 'الفرنسية', language_name_native: 'Français', script_name: 'Latin', direction: 'LTR', has_diacritics: 1, has_letter_forms: 0 }
      ];

      const lettersData = [
        { letter_ID: 'AR_LETTER_001', language_ID: 'LANG_AR', letter_order: 1, letter: 'ا', letter_name: 'ألف', normalized_letter: 'ا', unicode_codepoint: 'U+0627', sound_hint: 'a', seq_2: 'AR_SEQ_A1', seq_3: 'AR_SEQ_A2', seq_4: 'AR_SEQ_A3' },
        { letter_ID: 'AR_LETTER_002', language_ID: 'LANG_AR', letter_order: 2, letter: 'ب', letter_name: 'باء', normalized_letter: 'ب', unicode_codepoint: 'U+0628', sound_hint: 'b', seq_2: 'AR_SEQ_B1', seq_3: 'AR_SEQ_B2', seq_4: 'AR_SEQ_B3' },
        { letter_ID: 'AR_LETTER_003', language_ID: 'LANG_AR', letter_order: 3, letter: 'ت', letter_name: 'تاء', normalized_letter: 'ت', unicode_codepoint: 'U+062A', sound_hint: 't', seq_2: 'AR_SEQ_T1', seq_3: 'AR_SEQ_T2', seq_4: 'AR_SEQ_T3' },
        { letter_ID: 'AR_LETTER_004', language_ID: 'LANG_AR', letter_order: 4, letter: 'ث', letter_name: 'ثاء', normalized_letter: 'ث', unicode_codepoint: 'U+062B', sound_hint: 'th', seq_2: 'AR_SEQ_TH1', seq_3: 'AR_SEQ_TH2', seq_4: 'AR_SEQ_TH3' },
        { letter_ID: 'AR_LETTER_005', language_ID: 'LANG_AR', letter_order: 5, letter: 'ج', letter_name: 'جيم', normalized_letter: 'ج', unicode_codepoint: 'U+062C', sound_hint: 'j', seq_2: 'AR_SEQ_J1', seq_3: 'AR_SEQ_J2', seq_4: 'AR_SEQ_J3' },
        { letter_ID: 'EN_LETTER_001', language_ID: 'LANG_EN', letter_order: 1, letter: 'A', letter_name: 'A', normalized_letter: 'a', unicode_codepoint: 'U+0041', sound_hint: 'ei', seq_2: '', seq_3: '', seq_4: '' },
        { letter_ID: 'EN_LETTER_002', language_ID: 'LANG_EN', letter_order: 2, letter: 'B', letter_name: 'B', normalized_letter: 'b', unicode_codepoint: 'U+0042', sound_hint: 'bi', seq_2: '', seq_3: '', seq_4: '' },
        { letter_ID: 'FR_LETTER_001', language_ID: 'LANG_FR', letter_order: 1, letter: 'A', letter_name: 'A', normalized_letter: 'a', unicode_codepoint: 'U+0041', sound_hint: 'ah', seq_2: '', seq_3: '', seq_4: '' }
      ];

      const formsData = [
        { form_ID: 'AR_FORM_001', letter_ID: 'AR_LETTER_001', isolated: 'ا', initial: 'ا', medial: 'ـا', final: 'ـا' },
        { form_ID: 'AR_FORM_002', letter_ID: 'AR_LETTER_002', isolated: 'ب', initial: 'بـ', medial: 'ـبـ', final: 'ـب' },
        { form_ID: 'AR_FORM_003', letter_ID: 'AR_LETTER_003', isolated: 'ت', initial: 'تـ', medial: 'ـتـ', final: 'ـت' }
      ];

      const reviewData = [
        { reviewer_name: 'مُراجع لغوي متخصص', review_status: 'APPROVED', notes: 'الحروف مطابقة لمعاجم اللغويات ومعايير المعالجة الطبيعية.', review_date: new Date().toISOString().split('T')[0] }
      ];

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(languagesData), 'Languages');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(lettersData), 'Language_Letters');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(formsData), 'Arabic_Letter_Forms');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(reviewData), 'Import_Review');

      XLSX.writeFile(wb, 'language_letters_seed.xlsx');
    } catch (e: any) {
      alert('حدث خطأ أثناء تحميل الملف المنسق: ' + e.message);
    }
  };

  // Upload and parse Excel template
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExcelFile(file);
    setImportSuccess(false);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const bstr = event.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        
        const Languages = XLSX.utils.sheet_to_json(wb.Sheets['Languages'] || {});
        const Language_Letters = XLSX.utils.sheet_to_json(wb.Sheets['Language_Letters'] || {});
        const Arabic_Letter_Forms = XLSX.utils.sheet_to_json(wb.Sheets['Arabic_Letter_Forms'] || {});
        const Import_Review = XLSX.utils.sheet_to_json(wb.Sheets['Import_Review'] || {});

        setParsedData({ Languages, Language_Letters, Arabic_Letter_Forms, Import_Review });

        // Run deep structural checks
        runDataCheckValidations(Languages, Language_Letters, Arabic_Letter_Forms, Import_Review);

      } catch (err: any) {
        setValidationReport({
          status: 'fail',
          logs: [`خطأ فادح في قراءة هيكل ملف الإكسل: ${err.message}`],
          languagesCount: 0,
          lettersCount: 0,
          formsCount: 0,
          reviewStatus: 'UNKNOWN'
        });
      }
    };
    reader.readAsBinaryString(file);
  };

  // Human Review Checking + Column/Reference validation
  const runDataCheckValidations = (
    languages: any[],
    letters: any[],
    forms: any[],
    review: any[]
  ) => {
    const logs: string[] = [];
    let status: 'pass' | 'warning' | 'fail' = 'pass';

    logs.push(`• بدء مراجعة جودة البيانات وجودة المعجم...`);

    // Section 1: Sheet existence checks
    if (!languages.length) {
      logs.push(`⚠ تحذير: ورقة اللغات (Languages) فارغة أو غير متوفرة بشكل صحيح.`);
      status = 'warning';
    } else {
      logs.push(`✓ تم الكشف عن ورقة اللغات (عدد الحقول: ${languages.length})`);
    }

    if (!letters.length) {
      logs.push(`❌ خطأ: ورقة الحروف (Language_Letters) لا تحتوي على حروف ومخرجات.`);
      status = 'fail';
    } else {
      logs.push(`✓ تم الكشف عن ورقة الحروف (عدد الحروف: ${letters.length})`);
    }

    // Section 2: Relational checks (Foreign key)
    if (languages.length && letters.length) {
      const validLangIds = new Set(languages.map(l => l.language_ID));
      let orphanCount = 0;
      letters.forEach((letRow, idx) => {
        if (!validLangIds.has(letRow.language_ID)) {
          orphanCount++;
          if (orphanCount <= 3) {
            logs.push(`⚠ تحذير: الحرف المكتوب "${letRow.letter}" برقم ترتيب ${letRow.letter_order} يشير إلى لغة غير معرّفة "${letRow.language_ID}".`);
          }
        }
      });
      if (orphanCount > 0) {
        logs.push(`❌ خطأ: تم رصد ${orphanCount} حرفاً تشير لروابط لغات مفقودة، سيتم منع استيرادها.`);
        status = 'fail';
      } else {
        logs.push(`✓ جميع العلاقات المرجعية بين الحروف وجدول اللغات صحيحة ومثبتة.`);
      }
    }

    // Section 3: Unicode Codepoint checks
    const unicodeRegex = /^U\+[0-9A-F]{4,6}$/i;
    let invalidUnicodeCount = 0;
    letters.forEach(letRow => {
      if (letRow.unicode_codepoint && !unicodeRegex.test(letRow.unicode_codepoint.trim())) {
        invalidUnicodeCount++;
        if (invalidUnicodeCount <= 2) {
          logs.push(`⚠ تنبيه ترميز غير قياسي: الحرف "${letRow.letter}" يحمل قيمة يونيكود "${letRow.unicode_codepoint}" لا تطابق الترميز القياسي U+XXXX.`);
        }
      }
    });
    if (invalidUnicodeCount > 0) {
      logs.push(`⚠ إجمالي الحروف ذات قيمة ترميز يونيكود غير النمطية: ${invalidUnicodeCount}`);
      if (status !== 'fail') status = 'warning';
    }

    // Section 4: Human Review verification check
    const reviewerRow = review?.[0];
    const rawStatus = reviewerRow?.review_status ? reviewerRow.review_status.toUpperCase().trim() : 'PENDING';
    
    if (rawStatus === 'APPROVED') {
      logs.push(`✓ تم إقرار الاعتماد والمراجعة البشرية بنجاح من المراجع: "${reviewerRow?.reviewer_name || 'باحث معتمد'}"`);
    } else {
      logs.push(`⚠ تنبيه مرحلي: حالة المراجعة البشرية في ورقة (Import_Review) ما زالت مُعلّقة أو معطّلة. ننصح بالاعتماد اللغوي قبل تفعيل النظام.`);
      if (status !== 'fail') status = 'warning';
    }

    setValidationReport({
      status,
      logs,
      languagesCount: languages.length,
      lettersCount: letters.length,
      formsCount: forms.length,
      reviewStatus: rawStatus
    });
  };

  // Execute actual database insertion and script import to SQLite
  const handleExecuteImportToSQLite = () => {
    if (!sqliteDb || !parsedData) return;

    try {
      // 1) Clear current tables
      sqliteDb.run("DELETE FROM Arabic_Letter_Forms;");
      sqliteDb.run("DELETE FROM Language_Letters;");
      sqliteDb.run("DELETE FROM Languages;");
      sqliteDb.run("DELETE FROM Import_Review;");

      // 2) Parse and insert Languages
      const insertLanguage = sqliteDb.prepare(`
        INSERT INTO Languages (language_ID, language_code, language_name_ar, language_name_native, script_name, direction, has_diacritics, has_letter_forms)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
      `);
      (parsedData.Languages || []).forEach(l => {
        insertLanguage.run([
          l.language_ID || '',
          l.language_code || '',
          l.language_name_ar || '',
          l.language_name_native || '',
          l.script_name || '',
          l.direction || 'RTL',
          l.has_diacritics ? 1 : 0,
          l.has_letter_forms ? 1 : 0
        ]);
      });
      insertLanguage.free();

      // 3) Parse and insert Language_Letters
      const insertLetter = sqliteDb.prepare(`
        INSERT INTO Language_Letters (letter_ID, language_ID, letter_order, letter, letter_name, normalized_letter, unicode_codepoint, sound_hint, seq_2, seq_3, seq_4)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
      `);
      (parsedData.Language_Letters || []).forEach(letRow => {
        insertLetter.run([
          letRow.letter_ID || '',
          letRow.language_ID || '',
          Number(letRow.letter_order) || 0,
          letRow.letter || '',
          letRow.letter_name || '',
          letRow.normalized_letter || '',
          letRow.unicode_codepoint || '',
          letRow.sound_hint || '',
          letRow.seq_2 || null,
          letRow.seq_3 || null,
          letRow.seq_4 || null
        ]);
      });
      insertLetter.free();

      // 4) Parse and insert Arabic_Letter_Forms
      const insertForm = sqliteDb.prepare(`
        INSERT INTO Arabic_Letter_Forms (form_ID, letter_ID, isolated, initial, medial, final)
        VALUES (?, ?, ?, ?, ?, ?);
      `);
      (parsedData.Arabic_Letter_Forms || []).forEach(f => {
        insertForm.run([
          f.form_ID || '',
          f.letter_ID || '',
          f.isolated || '',
          f.initial || '',
          f.medial || '',
          f.final || ''
        ]);
      });
      insertForm.free();

      // 5) Parse and insert Import_Review
      const insertRev = sqliteDb.prepare(`
        INSERT INTO Import_Review (reviewer_name, review_status, notes, review_date)
        VALUES (?, ?, ?, ?);
      `);
      const reviewRow = parsedData.Import_Review?.[0];
      insertRev.run([
        reviewRow?.reviewer_name || 'مراجع افتراضي',
        reviewRow?.review_status || 'APPROVED',
        reviewRow?.notes || 'تم استيرادها سحابياً بنظام SQLite',
        reviewRow?.review_date || new Date().toISOString().split('T')[0]
      ]);
      insertRev.free();

      setImportSuccess(true);
      
      // Auto-run display query to show the newly imported records in the console
      handleExecuteConsoleSQL(`SELECT * FROM Languages;`);
    } catch (err: any) {
      alert('فشل كتابة واستيراد الحقول لقاعدة بيانات SQLite: ' + err.message);
    }
  };

  // Execute console SQL command
  const handleExecuteConsoleSQL = (forceQuery?: string) => {
    if (!sqliteDb) return;
    const targetQuery = forceQuery || sqlQuery;
    
    setQueryError(null);
    setQueryResult(null);
    
    const startTime = performance.now();
    try {
      const res = sqliteDb.exec(targetQuery);
      const endTime = performance.now();
      
      setQueryStats({
        rows: res[0]?.values?.length || 0,
        timeMs: Number((endTime - startTime).toFixed(2))
      });

      if (res.length > 0) {
        setQueryResult({
          columns: res[0].columns,
          values: res[0].values
        });
      } else {
        setQueryResult({
          columns: ['النتيجة (Result)'],
          values: [['نفذ الاستعلام بنجاح ولم يرجع حقولاً صفية.']]
        });
      }
    } catch (err: any) {
      setQueryError(err?.message || 'خطأ إملائي أو كود SQL غير متطابق.');
    }
  };

  // Execute interactive SQL on our chosen target database
  const handleExecuteInteractiveSQL = (forceQuery?: string, targetDbOverride?: 'sources' | 'universal_index') => {
    const activeDbKey = targetDbOverride || selectedInteractiveDb;
    const dbToQuery = activeDbKey === 'sources' ? sourcesDb : universalIndexDb;
    
    if (!dbToQuery) {
      setInteractiveQueryError(`لم يتم تحميل أو تفعيل محرك قاعدة بيانات SQLite لـ ${activeDbKey === 'sources' ? '01_sources.db' : '02_universal_index.db'}`);
      return;
    }

    const queryToExecute = forceQuery !== undefined ? forceQuery : interactiveSqlQuery;
    setInteractiveQueryError(null);
    setInteractiveQueryResult(null);

    const startTime = performance.now();
    try {
      const res = dbToQuery.exec(queryToExecute);
      const endTime = performance.now();

      setInteractiveQueryStats({
        rows: res[0]?.values?.length || 0,
        timeMs: Number((endTime - startTime).toFixed(2))
      });

      if (res.length > 0) {
        setInteractiveQueryResult({
          columns: res[0].columns,
          values: res[0].values
        });
      } else {
        setInteractiveQueryResult({
          columns: ['النتيجة (Result)'],
          values: [['نفذ الاستعلام بنجاح ولم يرجع أي حقول صفية (Query executed with no results).']]
        });
      }
    } catch (err: any) {
      setInteractiveQueryError(err?.message || 'خطأ إملائي أو كود SQL غير متوافق.');
    }
  };

  // Helper template definitions for user references
  const INTERACTIVE_TEMPLATES_SOURCES = [
    {
      title: 'جميع المصادر فورا',
      query: 'SELECT * FROM sources ORDER BY created_at DESC;'
    },
    {
      title: 'المصادر عالية الموثوقية',
      query: "SELECT source_id, source_name, source_type, trust_level FROM sources WHERE trust_level = 'trusted';"
    },
    {
      title: 'إجمالي حجم الملفات بالبايت',
      query: 'SELECT SUM(size_bytes) AS total_file_size, COUNT(*) AS count_of_files FROM sources;'
    }
  ];

  const INTERACTIVE_TEMPLATES_INDEX = [
    {
      title: 'جميع الكائنات المعرفية',
      query: 'SELECT * FROM universal_objects;'
    },
    {
      title: 'القاموس اللغوي: المعاينة',
      query: 'SELECT word_id, word, root, word_type, frequency FROM words LIMIT 5;'
    },
    {
      title: 'البحث عن كلمات جذرها (رحم)',
      query: "SELECT word_id, word, root, word_type FROM words WHERE root = 'رحم';"
    },
    {
      title: 'الرسم البياني للمعرفة وصيغ الثقة',
      query: 'SELECT relation_id, subject_id, predicate, object_id, confidence FROM relations ORDER BY confidence DESC;'
    },
    {
      title: 'الفهرس المقلوب الفوري',
      query: 'SELECT term, field_name, position, weight FROM inverted_index;'
    }
  ];

  // Upload handlers for actual local .db / .sqlite files
  const handleSourcesDbUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async function() {
      try {
        const u8 = new Uint8Array(reader.result as ArrayBuffer);
        const SQL = await initSqlJs({
          locateFile: file => `https://sql.js.org/dist/${file}`
        });
        const customDb = new SQL.Database(u8);
        setSourcesDb(customDb);
        setSourcesDbFile(file);
        setInteractiveQueryError(null);
        setInteractiveQueryResult(null);
        
        // Auto run a quick query to test custom loaded DB
        const testQuery = 'SELECT * FROM sqlite_master WHERE type="table";';
        setInteractiveSqlQuery(testQuery);
        const res = customDb.exec(testQuery);
        if (res.length > 0) {
          setInteractiveQueryResult({ columns: res[0].columns, values: res[0].values });
        }
      } catch (err: any) {
        setInteractiveQueryError('فشل معالجة وقراءة ملف 01_sources.db: ' + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleUniversalIndexDbUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async function() {
      try {
        const u8 = new Uint8Array(reader.result as ArrayBuffer);
        const SQL = await initSqlJs({
          locateFile: file => `https://sql.js.org/dist/${file}`
        });
        const customDb = new SQL.Database(u8);
        setUniversalIndexDb(customDb);
        setUniversalIndexDbFile(file);
        setInteractiveQueryError(null);
        setInteractiveQueryResult(null);

        // Auto run a quick query to test custom loaded DB
        const testQuery = 'SELECT * FROM sqlite_master WHERE type="table";';
        setInteractiveSqlQuery(testQuery);
        const res = customDb.exec(testQuery);
        if (res.length > 0) {
          setInteractiveQueryResult({ columns: res[0].columns, values: res[0].values });
        }
      } catch (err: any) {
        setInteractiveQueryError('فشل معالجة وقراءة ملف 02_universal_index.db: ' + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="space-y-6 text-right">

      {/* Modern High-End SubNavigation Bar inside DB Panel */}
      <div className="bg-slate-100 border border-slate-200 p-1.5 rounded-2xl flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 w-full sm:w-auto">
          <button
            onClick={() => setActiveSubTab('letters')}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 py-2.5 px-6 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'letters'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200/50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
            }`}
          >
            <FileSpreadsheet size={14} className={activeSubTab === 'letters' ? 'text-indigo-600' : ''} />
            إدارة اللغات والحروف (Excel & SQLite Seed)
          </button>

          <button
            onClick={() => {
              setActiveSubTab('qpec');
              fetchQpecData();
            }}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 py-2.5 px-6 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'qpec'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
            }`}
          >
            <ShieldAlert size={14} className={activeSubTab === 'qpec' ? 'text-amber-300' : 'text-amber-500'} />
            شاحن أخطاء استخلاص القرآن (QPEC V1)
          </button>

          <button
            onClick={() => {
              setActiveSubTab('warehouse');
              fetchWarehouseStats();
              fetchWarehouseTableRows(warehouseActiveViewTable);
            }}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 py-2.5 px-6 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'warehouse'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
            }`}
          >
            <DbIcon size={14} className={activeSubTab === 'warehouse' ? 'text-emerald-100' : 'text-emerald-500'} />
            مستودع المعرفة الشامل (Warehouse v1)
          </button>

          <button
            onClick={() => {
              setActiveSubTab('interactive_query');
              setTimeout(() => {
                handleExecuteInteractiveSQL();
              }, 50);
            }}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 py-2.5 px-6 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'interactive_query'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
            }`}
          >
            <Terminal size={14} className={activeSubTab === 'interactive_query' ? 'text-indigo-100' : 'text-indigo-500'} />
            المسائل والاستعلام التفاعلي (Local DBs)
          </button>
        </div>

        <div className="hidden md:flex items-center gap-1 text-[10px] text-slate-500 font-extrabold px-3 font-mono">
          <span>SQLite 3.42.0 (sql.js WASM)</span>
        </div>
      </div>

      {activeSubTab === 'letters' ? (
        <>
          {/* Database Stage visual workflow map */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2 mb-4">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-lg text-xs font-bold flex items-center gap-1">
                  <RefreshCw size={13} className="animate-spin text-emerald-500" />
                  دورة تجهيز واعتماد الحروف اللغوية
                </span>
                <h3 className="text-sm font-bold text-slate-900">أقسام ومراحل قاعدة البيانات المعتمدة في النظام</h3>
              </div>
              <span className="text-[10px] text-indigo-600 font-bold bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full font-mono">
                محرك SQLite جاهز
              </span>
            </div>

            {/* Dynamic Visual Chain Indicators */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative justify-center items-center py-4">
              
              {/* Phase 1: Excel staging */}
              <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl text-center space-y-1 relative z-10">
                <div className="w-10 h-10 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-2 border border-emerald-200 shadow-sm">
                  <FileSpreadsheet size={18} />
                </div>
                <h4 className="text-xs font-black text-slate-800">1) قالب تجهيز Excel</h4>
                <p className="text-[10px] text-slate-400 leading-relaxed font-semibold">إدخال الحروف وتعديل اليونيكود والمراجعة اليدوية المتكاملة</p>
              </div>

              {/* Connectors */}
              <div className="hidden md:flex justify-center text-slate-300">
                <ChevronRight size={24} className="mx-auto text-slate-400" />
              </div>

              {/* Phase 2: Human review audit */}
              <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl text-center space-y-1 relative z-10">
                <div className="w-10 h-10 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto mb-2 border border-amber-200 shadow-sm">
                  <Clock size={18} />
                </div>
                <h4 className="text-xs font-black text-slate-800">2) مراجعة بشرية معتمدة</h4>
                <p className="text-[10px] text-slate-400 leading-relaxed font-semibold">توثيق مراجع الجودة في ورقة المراجعة لتأكيد القياس الصوتي</p>
              </div>

              {/* Connectors */}
              <div className="hidden md:flex justify-center text-slate-300">
                <ChevronRight size={24} className="mx-auto text-slate-400" />
              </div>

              {/* Phase 3: SQLite Storage System */}
              <div className="bg-white border-2 border-indigo-500/80 p-4 rounded-xl text-center space-y-1 relative z-10 shadow-sm shadow-indigo-100/50">
                <div className="w-10 h-10 bg-indigo-100 text-indigo-700 rounded-full flex items-center justify-center mx-auto mb-2 border border-indigo-200 shadow-sm animate-pulse">
                  <DbIcon size={18} />
                </div>
                <h4 className="text-xs font-black text-indigo-900">3) محرك SQLite الذكي</h4>
                <p className="text-[10px] text-indigo-700 leading-relaxed font-bold">بناء العلاقات، المفاتيح الأساسية والمقاييس seq_2 / seq_3 الموثقة</p>
              </div>

            </div>
          </div>

          {/* Main interactive cards: Excel import / review and SQLite console */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Side: Staging / Upload and Download Area */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Template download and manual upload frame */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-5">
                <div className="border-b border-slate-100 pb-3">
                  <h3 className="text-sm font-bold text-slate-900">تنزيل وتجهيز قالب الإكسل (Excel Seed Staging)</h3>
                  <p className="text-[11px] text-slate-400 mt-1">ابدأ بتحميل ملف النموذج المفرغ، حدّث البيانات اللغوية، واعتمدها ثم حملها للنظام.</p>
                </div>

                <div className="flex flex-col gap-3">
                  <button
                    onClick={handleDownloadTemplate}
                    className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-580 text-white font-bold text-xs py-3 px-4 rounded-xl transition-all shadow-sm cursor-pointer border border-transparent"
                  >
                    <Download size={14} />
                    تنزيل قالب Excel Seed مسبق التعبئة بنجاح
                  </button>

                  <div className="border-t border-slate-100/70 pt-4">
                    <label className="text-[11px] font-bold text-slate-600 block mb-2">رفع واستيراد ملف الإكسل السحابي لتجهيز الحروف:</label>
                    
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-500 p-6 rounded-2xl text-center cursor-pointer transition-all bg-slate-50 hover:bg-white"
                >
                  <Upload size={28} className="mx-auto text-slate-400 mb-2 animate-bounce" />
                  <span className="text-xs font-bold text-slate-700 block mb-1">اسحب ملف الإكسل هنا أو اضغط للتصفح</span>
                  <span className="text-[10px] text-slate-400 font-semibold block">يقبل صيغ .xlsx أو نموذج البيانات</span>
                  
                  {excelFile && (
                    <span className="inline-block mt-3 bg-indigo-50 text-indigo-700 font-mono text-[10px] font-bold py-1 px-2.5 rounded border border-indigo-100">
                      قيد الفحص: {excelFile.name}
                    </span>
                  )}
                </div>
                
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".xlsx"
                  className="hidden" 
                />
              </div>
            </div>

            {/* Validation Reports and review blocks */}
            {validationReport && (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">تقرير الاعتماد والمراجعة الآلية:</span>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 border ${
                    validationReport.status === 'pass' 
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                      : validationReport.status === 'warning'
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-rose-50 text-rose-700 border-rose-200'
                  }`}>
                    {validationReport.status === 'pass' && <CheckCircle size={10} />}
                    {validationReport.status === 'warning' && <AlertTriangle size={10} />}
                    {validationReport.status === 'fail' && <ShieldAlert size={10} />}
                    {validationReport.status === 'pass' ? 'معتمد' : validationReport.status === 'warning' ? 'محتمل مع تنبيهات' : 'مرفوض'}
                  </span>
                </div>

                <div className="space-y-1.5 text-[10px] max-h-40 overflow-y-auto font-semibold pr-1">
                  {validationReport.logs.map((log, i) => (
                    <p key={i} className="text-slate-600 leading-relaxed font-mono rtl:text-right">{log}</p>
                  ))}
                </div>

                <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-slate-200/50">
                  <div className="bg-white p-2 border border-slate-100 rounded-lg">
                    <span className="text-[9px] text-slate-400 block font-semibold">اللغات</span>
                    <strong className="text-xs text-slate-800">{validationReport.languagesCount}</strong>
                  </div>
                  <div className="bg-white p-2 border border-slate-100 rounded-lg">
                    <span className="text-[9px] text-slate-400 block font-semibold">حروف لغوية</span>
                    <strong className="text-xs text-slate-800">{validationReport.lettersCount}</strong>
                  </div>
                  <div className="bg-white p-2 border border-slate-100 rounded-lg">
                    <span className="text-[9px] text-slate-400 block font-semibold">أشكال خطية</span>
                    <strong className="text-xs text-slate-800">{validationReport.formsCount}</strong>
                  </div>
                </div>

                {/* Import button to SQLite */}
                {validationReport.status !== 'fail' && (
                  <button
                    onClick={handleExecuteImportToSQLite}
                    className="w-full flex items-center justify-center gap-1.5 bg-indigo-650 hover:bg-indigo-700 text-white font-bold text-xs py-2 px-4 rounded-xl transition-all shadow-sm cursor-pointer mt-2"
                  >
                    <Play size={12} />
                    شحن واستيراد البيانات إلى قاعدة SQLite المعتمدة
                  </button>
                )}
              </div>
            )}

            {/* Import Status Success indicators */}
            {importSuccess && (
              <div className="p-3.5 bg-emerald-50 border border-emerald-150 rounded-xl flex items-start gap-2 text-emerald-900 animate-pulse">
                <CheckCircle size={16} className="text-emerald-600 flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="block font-bold">تم استيراد ومعايرة قاعدة SQLite اللغوية!</strong>
                  <p className="text-[10px] leading-relaxed text-emerald-850 mt-0.5">تم تطهير وتطهير الجداول، ربط أوراق العمل بالكامل، وتأكيد العلاقات مع تفعيل تسلسلات الحروف seq_2, seq_3 بدقة متطورة.</p>
                </div>
              </div>
            )}
          </div>

          {/* Quick SQLite Indexed Letters Finder */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-xs font-bold text-slate-900">مستكشف الفهارس والحروف السريعة (Fast Indexed Search)</h3>
              <span className="text-[9px] text-slate-400 font-semibold">مدعوم مسبقاً بفهارس بـ SQLite</span>
            </div>

            <div className="flex gap-2">
              <div className="flex-1 relative">
                <input 
                  type="text"
                  value={searchLetter}
                  onChange={(e) => setSearchLetter(e.target.value)}
                  placeholder="ابحث بالحرف أو الاسم أو قيمة اليونيكود..."
                  className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-xl text-xs bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-emerald-300 focus:bg-white text-right font-medium"
                />
                <span className="absolute left-2.5 top-2.5 text-slate-400"><Search size={14} /></span>
              </div>

              <select 
                value={selectedLangFilter}
                onChange={(e) => setSelectedLangFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-xl text-slate-600 font-bold focus:outline-none"
              >
                <option value="all">كل اللغات</option>
                <option value="LANG_AR">العربية</option>
                <option value="LANG_EN">الإنجليزية</option>
                <option value="LANG_FR">الفرنسية</option>
              </select>
            </div>

            {/* Quick search listing result display */}
            <div className="max-h-56 overflow-y-auto space-y-1.5 pr-1 text-xs">
              {quickSearchResults.length > 0 ? (
                quickSearchResults.map((letRow, i) => (
                  <div 
                    key={i}
                    className="flex justify-between items-center p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-100 transition-all font-mono"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md font-sans border border-indigo-100">
                        {letRow.letter}
                      </span>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-700 font-black block font-sans">{letRow.letter_name}</span>
                        <span className="text-[9px] text-slate-400 block">{letRow.language_name_ar}</span>
                      </div>
                    </div>

                    <div className="text-left">
                      <span className="text-[10px] text-slate-500 font-bold block">{letRow.unicode_codepoint}</span>
                      {letRow.seq_2 && (
                        <span className="text-[8px] bg-slate-200 text-slate-600 rounded px-1 font-bold">
                          {letRow.seq_2}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-slate-400 font-bold text-[10px]">
                  لا يوجد حروف قياسية مطابقة لبحثك في قاعدة SQLite حالياً.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right Side: SQLite Visual Studio & Command Console */}
        <div className="lg:col-span-7 bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm flex flex-col justify-between space-y-5">
          
          <div className="space-y-4">
            
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between flex-wrap gap-2">
              <div className="space-y-0.5">
                <h3 className="text-sm font-bold text-slate-900">استوديو التحكم في SQLite (Visual SQLite Studio)</h3>
                <p className="text-[11px] text-slate-400">منصة تفاعلية مدمجة لتنفيذ الاستعلامات، فحص العلاقات وحالة الفهارس وتجريب لغة SQL.</p>
              </div>

              <div className="flex items-center gap-1.5 font-bold text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-lg p-1.5 px-3">
                <Terminal size={11} />
                <span>محرك SQLite: Active </span>
              </div>
            </div>

            {/* Quick Templates List */}
            <div className="space-y-1.5">
              <span className="text-[10px] text-slate-400 font-bold block mb-1">استعلم بنقرة واحدة (قوالب جاهزة):</span>
              <div className="flex flex-wrap gap-1.5">
                {SQL_TEMPLATES.map((tmpl, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSqlQuery(tmpl.query);
                      handleExecuteConsoleSQL(tmpl.query);
                    }}
                    className="text-[9px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 py-1.5 px-2.5 rounded-lg transition-all cursor-pointer"
                  >
                    {tmpl.title}
                  </button>
                ))}
              </div>
            </div>

            {/* SQL Terminal text prompt and query run trigger */}
            <div className="space-y-1.5 pt-2">
              <label className="text-[10px] text-slate-400 font-bold block">محرر أوامر SQL (Raw SQLite Command Editor):</label>
              <div className="relative border border-slate-200 rounded-xl overflow-hidden bg-slate-900 font-mono text-xs">
                
                <textarea
                  value={sqlQuery}
                  onChange={(e) => setSqlQuery(e.target.value)}
                  className="w-full h-36 p-4 bg-slate-950 text-emerald-400 font-mono text-xs focus:outline-none border-none text-left leading-normal selection:bg-indigo-900"
                  dir="ltr"
                  placeholder="Write your raw SELECT, JOIN, or aggregate SQL commands here..."
                />

                <div className="bg-slate-900 p-2.5 border-t border-slate-800 flex justify-between items-center flex-wrap gap-1.5">
                  <span className="text-[9px] text-slate-400 font-semibold font-sans">
                    يمكنك كتابة أي جملة استعلامية لغة SQL Standard
                  </span>
                  
                  <button
                    onClick={() => handleExecuteConsoleSQL()}
                    className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] py-1.5 px-4 rounded-lg transition-all shadow-sm cursor-pointer"
                  >
                    <Play size={10} />
                    نشِّط الاستعلام واعرض المخرجات
                  </button>
                </div>
              </div>
            </div>

            {/* Result Stats bar */}
            {queryStats && (
              <div className="bg-slate-50 text-[10px] text-slate-500 p-2 rounded-lg flex gap-3 font-semibold justify-end">
                <span>تاريخ التنفيذ: {new Date().toLocaleTimeString('ar-EG')}</span>
                <span>•</span>
                <span>الصفوف المسترجعة: {queryStats.rows} صفاً</span>
                <span>•</span>
                <span>زمن الاستدعاء: {queryStats.timeMs} ملي ثانية</span>
              </div>
            )}

            {/* Query result table wrapper */}
            <div className="border border-slate-150 rounded-xl overflow-hidden shadow-xs">
              <div className="bg-slate-50 border-b border-slate-150 p-2.5 text-[10px] font-bold text-slate-700 flex justify-between">
                <span>معاينة جدول المخرجات والنتائج الفرعية:</span>
                <span className="text-slate-400 font-semibold">SQLite Storage Engine</span>
              </div>

              <div className="max-h-56 overflow-auto">
                {queryError ? (
                  <div className="p-6 text-center text-[11px] text-rose-600 bg-rose-50/50 flex flex-col items-center justify-center gap-1.5 font-bold">
                    <ShieldAlert size={20} className="text-rose-500" />
                    <span>خطأ في تنفيذ وتفسير أمر الـ SQL في المحرك سيت:</span>
                    <pre className="text-[10px] text-rose-700 bg-white border border-rose-100 p-2.5 rounded font-mono select-all w-full leading-normal">{queryError}</pre>
                  </div>
                ) : queryResult ? (
                  <table className="w-full text-[10px] text-slate-700 font-mono border-collapse" dir="rtl">
                    <thead>
                      <tr className="bg-slate-100 text-slate-600 font-black border-b border-slate-200">
                        {queryResult.columns.map((col, idx) => (
                          <th key={idx} className="p-2.5 text-right font-sans whitespace-nowrap">{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {queryResult.values.length > 0 ? (
                        queryResult.values.map((row, rowIdx) => (
                          <tr key={rowIdx} className="hover:bg-slate-50 font-sans">
                            {row.map((val, cellIdx) => (
                              <td key={cellIdx} className="p-2.5 whitespace-nowrap text-slate-800 font-medium">
                                {val === null ? <em className="text-slate-350">NULL</em> : String(val)}
                              </td>
                            ))}
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={queryResult.columns.length} className="p-6 text-center text-[10px] text-slate-400 font-semibold">
                            لا يوجد صفوف مسترجعة مطابقة للاستعلام المحدد.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                ) : (
                  <div className="p-8 text-center text-[11px] text-slate-400 font-bold">
                    اكتب أوامرك البرمجية أو اضغط على أحد قوالب الاستعلامات بالرأس لتفعيل محتوى المستودع ومعاينة الجداول فورا.
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* SQLite schema and structural specifications guidelines */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
            <h4 className="text-[11px] font-bold text-slate-800 mb-1.5">مواصفات الفهارس والمفاتيح المركّبة (Indices & Schema Specs)</h4>
            <p className="text-[10px] text-slate-500 leading-normal leading-relaxed font-semibold">
              يقوم السكربت بتوليد فهارس آلية لـ <code className="bg-slate-100 text-indigo-600 px-1 rounded font-mono">language_ID</code> وتفعيل معايير التتالي <code className="bg-slate-100 text-indigo-600 px-1 rounded font-mono">ON DELETE CASCADE</code> لضمان عدم وجود حروف يتيمة في النظام عند إفراغ اللغات أو الفحص.
            </p>
          </div>

        </div>

      </div>
        </>
      ) : activeSubTab === 'qpec' ? (
        /* QPEC V1 TAB CONTENT */
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-lg text-xs font-bold flex items-center gap-1">
                  <ShieldAlert size={14} className="text-amber-500" />
                  برنامج شحن أخطاء استخلاص القرآن (QPEC V1)
                </span>
                <h2 className="text-md font-extrabold text-slate-900 font-sans">منظومة رصد وتقييم أخطاء الـ OCR ومطابقة مصاحف الـ PDF</h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSimulateOCRRun}
                  className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-605 text-slate-900 font-bold text-[11px] py-1.5 px-3.5 rounded-lg transition-all cursor-pointer"
                >
                  <RefreshCw size={12} />
                  محاكاة دورة استخلاص EasyOCR
                </button>
                <button
                  onClick={handleDownloadQpecMatrix}
                  className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] py-1.5 px-3.5 rounded-lg transition-all cursor-pointer"
                >
                  <Download size={12} />
                  تصدير التقرير (Excel)
                </button>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed font-semibold">
              تقوم المنظومة بالتخلي عن آليات مطابقة الصفحات الصلبة، وتعتمد بدلاً من ذلك على <strong className="text-slate-800">مجموع إجماع المحاذاة (Consensus Alignment Table)</strong>. الكلمات تفهرس تبعا لموقعها المعجمي المطلق (<strong className="text-indigo-600 font-mono">surah_number + ayah_number + word_position</strong>) لتسجيل جولات الخطأ المتعاقبة. عندما تختفي المشكلة في الإعادة، تُعلم الكلمة كـ <span className="text-emerald-600 font-extrabold">محلولة (resolved)</span>. لا وجود لسياسة الكتابات الدائمة الذهبية (NO Permanent Gold Write) دون مراجعة إجماعية لضمان النزاهة العلمية.
            </p>

            {qpecMsg && (
              <div className="p-3 bg-indigo-50 text-indigo-900 border border-indigo-100 rounded-xl text-xs font-bold flex items-center gap-2 animate-pulse">
                <CheckCircle size={15} className="text-indigo-600" />
                <span>{qpecMsg}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Capture Form - Right Column */}
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="border-b border-slate-100 pb-2">
                <h3 className="text-xs font-bold text-slate-900 font-sans col-auto">تسجيل محاولة استخلاص (جديد/سلسلة متعاقبة)</h3>
                <p className="text-[10px] text-slate-400">سجل خطأ ocr في كلمة محددة. التكرار يترجم كجولة اتهام إضافية!</p>
              </div>

              <form onSubmit={handleAddNewQpecError} className="space-y-3 text-right">
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 block font-bold">السورة</label>
                    <input 
                      type="text" 
                      value={qpecSurah} 
                      onChange={e => setQpecSurah(e.target.value)} 
                      className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-right font-medium" 
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 block font-bold">الآية وموقع الكلمة</label>
                    <div className="grid grid-cols-2 gap-1">
                      <input 
                        type="number" 
                        value={qpecAyah} 
                        onChange={e => setQpecAyah(Number(e.target.value))} 
                        className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-center font-mono" 
                        min="1" 
                        required
                      />
                      <input 
                        type="number" 
                        value={qpecWordPos} 
                        onChange={e => setQpecWordPos(Number(e.target.value))} 
                        className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-center font-mono" 
                        min="1" 
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 block font-bold">الصفحة PDF</label>
                    <input 
                      type="number" 
                      value={qpecPdfPage} 
                      onChange={e => setQpecPdfPage(Number(e.target.value))} 
                      className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-center font-mono" 
                      min="1" 
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 block font-bold">الصفحة مصحف</label>
                    <input 
                      type="number" 
                      value={qpecQuranPage} 
                      onChange={e => setQpecQuranPage(Number(e.target.value))} 
                      className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-center font-mono" 
                      min="1" 
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block font-bold">الكلمة الصحيحة (المرجع الوفاقي)</label>
                  <input 
                    type="text" 
                    value={qpecCorrect} 
                    onChange={e => setQpecCorrect(e.target.value)} 
                    className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-right font-medium" 
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block font-bold">الكلمة المستخلصة (الخطأ الفعلي)</label>
                  <input 
                    type="text" 
                    value={qpecWrong} 
                    onChange={e => setQpecWrong(e.target.value)} 
                    placeholder="اكتب نفس الكلمة لمحاكاة تصحيح تام ومطابقة"
                    className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-right font-medium" 
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block font-bold">نوع الخطأ الاستخلاصي</label>
                  <select 
                    value={qpecIssue} 
                    onChange={e => setQpecIssue(e.target.value)}
                    className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-705 font-bold focus:outline-none"
                  >
                    <option value="wrong_character">تصحيف حرف (Wrong Character)</option>
                    <option value="missing_character">سقط حرف (Missing Character)</option>
                    <option value="extra_character">زيادة حرف (Extra Character)</option>
                    <option value="diacritic_error">خطأ تشكيل وضبط (Diacritic Error)</option>
                    <option value="spacing_error">أخطاء المسافات وفصل الكلمات</option>
                    <option value="ocr_noise">ضوضاء استبعاد/ترميز مطبعي (Noise)</option>
                    <option value="uncertain">غير حاسم (Uncertain)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs py-2 px-4 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  حفظ وتحديث مصفوفة الأخطاء التراكمية
                </button>
              </form>
            </div>

            {/* Matrix Board Display - Left Column */}
            <div className="lg:col-span-8 space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                <div className="border-b border-slate-100 pb-2 flex justify-between items-center">
                  <h3 className="text-xs font-extrabold text-slate-900 font-sans">سجل مصفوفة الأخطاء التراكمية (Multiple Attempts Matrix)</h3>
                  <span className="text-[9px] bg-slate-100 p-1 px-2.5 rounded text-slate-500 font-bold font-mono">
                    {qpecRows.length} سجلات فاعلة
                  </span>
                </div>

                <div className="overflow-x-auto border border-slate-100 rounded-xl">
                  <table className="w-full text-[11px] text-slate-700 text-right border-collapse" dir="rtl">
                    <thead>
                      <tr className="bg-slate-50 font-black border-b border-slate-200 text-slate-600">
                        <th className="p-2.5">الكلمة الصحيحة</th>
                        <th className="p-2.5">السورة (الآية)</th>
                        <th className="p-2.5 text-center font-sans">موقعها</th>
                        <th className="p-2.5 text-center font-sans">صفحة PDF</th>
                        <th className="p-2.5 text-center font-sans">صفحة المصحف</th>
                        <th className="p-2.5 text-center font-sans">الخطأ الأول</th>
                        <th className="p-2.5 text-center font-sans">الخطأ الثاني</th>
                        <th className="p-2.5 text-center font-sans">الخطأ الثالث</th>
                        <th className="p-2.5 text-center">آخر حالة</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {qpecRows.map((row, i) => (
                        <tr 
                          key={i} 
                          onClick={() => {
                            setSelectedWordId(row.reference_word_id);
                            handleInspectWordAttempts(row.reference_word_id);
                          }}
                          className={`hover:bg-indigo-50/50 cursor-pointer transition-colors ${
                            selectedWordId === row.reference_word_id ? 'bg-indigo-50/70 font-semibold text-indigo-950' : ''
                          }`}
                        >
                          <td className="p-2.5 font-sans font-extrabold text-slate-900 text-right">{row.الكلمة_الصحيحة}</td>
                          <td className="p-2.5 text-right font-sans">{row.السورة} ({row.الآية})</td>
                          <td className="p-2.5 text-center font-mono font-medium text-slate-500">{row.موقع_الكلمة}</td>
                          <td className="p-2.5 text-center font-mono font-medium text-slate-500">{row.صفحة_PDF}</td>
                          <td className="p-2.5 text-center font-mono font-medium text-slate-500">{row.صفحة_المصحف}</td>
                          <td className="p-2.5 text-center">
                            <span className="text-[10px] text-rose-700 bg-rose-50 border border-rose-100 rounded-md px-1.5 py-0.5 font-bold">
                              {row.الخطأ_الأول || '-'}
                            </span>
                          </td>
                          <td className="p-2.5 text-center">
                            {row.الخطأ_الثاني ? (
                              <span className="text-[10px] text-amber-700 bg-amber-50 border border-amber-100 rounded-md px-1.5 py-0.5 font-bold">
                                {row.الخطأ_الثاني}
                              </span>
                            ) : <span className="text-slate-350 font-semibold font-mono">-</span>}
                          </td>
                          <td className="p-2.5 text-center">
                            {row.الخطأ_الثالث ? (
                              <span className={`text-[10px] rounded-md px-1.5 py-0.5 font-bold border ${
                                row.الخطأ_الثالث === 'same' 
                                  ? 'text-emerald-700 bg-emerald-50 border-emerald-100'
                                  : 'text-rose-700 bg-rose-50 border-rose-100'
                              }`}>
                                {row.الخطأ_الثالث === 'same' ? 'مطابق' : row.الخطأ_الثالث}
                              </span>
                            ) : <span className="text-slate-350 font-semibold font-mono">-</span>}
                          </td>
                          <td className="p-2.5 text-center">
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${
                              row.آخر_حالة === 'resolved' 
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : row.آخر_حالة === 'has_errors'
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : 'bg-slate-50 text-slate-600 border-slate-200'
                            }`}>
                              {row.آخر_حالة === 'resolved' ? 'سليمة (resolved)' : row.آخر_حالة === 'has_errors' ? 'معلق (has_errors)' : 'سليمة (no_problem)'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Inspecting single word extraction history */}
                {selectedWordId && (
                  <div className="bg-slate-50 border border-slate-200/60 p-4 rounded-xl space-y-2">
                    <span className="text-[10px] text-slate-400 font-extrabold block">سلسلة محاولات الاستخلاص لجولة الكلمة المحددة:</span>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      {selectedWordAttempts.map((att, i) => (
                        <div key={i} className="bg-white p-2.5 border border-slate-100 rounded-lg flex justify-between items-center text-xs">
                          <div>
                            <span className="block font-black text-slate-800">جولة {att.attempt_number} ({att.engine_profile})</span>
                            <span className="text-[9px] text-slate-400 font-mono block">التاريخ: {String(att.created_at).split(' ')[0]}</span>
                          </div>
                          <div className="text-left">
                            <span className="block font-bold text-indigo-700 text-left font-sans">{att.extracted_word}</span>
                            <span className={`text-[9px] font-bold border rounded px-1 ${
                              att.compare_status === 'same'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-100'
                                : 'bg-rose-50 text-rose-700 border-rose-100'
                            }`}>{att.compare_status === 'same' ? 'مطابق' : 'مختلف'}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* Training pattern view */}
          <div className="bg-white border border-slate-250/70 p-6 rounded-2xl shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-2 flex justify-between items-center">
              <h3 className="text-xs font-black text-slate-900 font-sans">سجل الأنماط المتكررة لتدريب الأنموذج (Frequent Pattern Training Logs)</h3>
              <span className="text-[9px] text-slate-400">تحليل الأنماط الفردية لترميم مصنف OCR</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {qpecPatterns.map((pat, i) => (
                <div key={i} className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-2 text-right relative hover:bg-slate-100/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="p-1 px-2.5 bg-violet-50 text-violet-700 rounded-md text-[9px] font-bold">
                      {pat.issue_type}
                    </span>
                    <span className="text-xs font-mono font-black text-slate-700 bg-white border border-slate-150 rounded px-1.5 py-0.5">
                      تكرر {pat.occurrence_count} مرات
                    </span>
                  </div>

                  <div className="flex justify-between items-center pt-1 font-mono">
                    <span className="text-xs text-slate-400 font-semibold">الصحيحة: <strong className="text-indigo-600 font-sans">{pat.correct_word}</strong></span>
                    <span className="text-xs text-rose-600 font-semibold">الاستخلاص: <strong className="font-sans">{pat.wrong_word}</strong></span>
                  </div>

                  <p className="text-[10.5px] text-slate-500 leading-relaxed pt-1.5 border-t border-slate-200/50 font-bold">
                    قيمة التدريب: <span className="text-violet-600 underline text-[10.5px] font-black">{pat.suggested_rule || 'جاري صياغة القاعدة تلقائياً...'}</span>
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : activeSubTab === 'warehouse' ? (
        /* UNIVERSAL KNOWLEDGE WAREHOUSE PHASE 1 TAB CONTENT */
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-lg text-xs font-bold flex items-center gap-1">
                  <DbIcon size={14} className="text-emerald-500 animate-pulse" />
                  مستودع المعرفة الشامل (Universal Knowledge Warehouse)
                </span>
                <h2 className="text-md font-extrabold text-slate-900 font-sans">إدارة نواة تشغيل مستودع المعرفة - المرحلة الأولى Core</h2>
              </div>
              <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-full font-mono">
                محرك SQLite فاعل
              </span>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed font-semibold">
              يقوم النظام ببناء عالمه الداخلي تفاعلياً من المدخلات تلقائياً (مصدر ➔ كائن عام ➔ كلمة ➔ علاقة ➔ فهارس بحث). والاعتماد النهائي الفعلي للبيانات الموثقة يكون ضمن <strong className="text-slate-800 font-sans">قاعدة بيانات SQLite</strong> المستقرة بدلاً من ملفات الإكسل المؤقتة لتفعيل محركات البحث والعلاقات اللفظية. لا يتم التصدير لجداول الذهب (Gold Commits) إلا بعد المرور بدورات المراجعة البشرية المعتمدة.
            </p>

            {warehouseMsg && (
              <div className={`p-3 border rounded-xl text-xs font-bold flex items-center gap-2 ${
                warehouseMsg.startsWith('خطأ') 
                  ? 'bg-rose-50 text-rose-900 border-rose-100'
                  : 'bg-emerald-50 text-emerald-950 border-emerald-150'
              }`}>
                <CheckCircle size={15} className="text-emerald-600" />
                <span>{warehouseMsg}</span>
              </div>
            )}
          </div>

          {/* Core Analytics Widgets counters */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm text-right">
              <span className="text-[10px] text-slate-400 font-extrabold block">01_المصادر (Sources)</span>
              <span className="text-2xl font-black text-slate-900 font-mono block mt-1">{warehouseStats.sources}</span>
            </div>
            
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm text-right">
              <span className="text-[10px] text-slate-400 font-extrabold block">02_الكائنات (Objects)</span>
              <span className="text-2xl font-black text-slate-900 font-mono block mt-1">{warehouseStats.objects}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm text-right">
              <span className="text-[10px] text-slate-400 font-extrabold block">03_كلمات المعجم (Words)</span>
              <span className="text-2xl font-black text-indigo-600 font-mono block mt-1">{warehouseStats.words}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm text-right">
              <span className="text-[10px] text-slate-400 font-extrabold block">04_العلاقات (Relations)</span>
              <span className="text-2xl font-black text-purple-600 font-mono block mt-1">{warehouseStats.relations}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm text-right col-span-2 md:col-span-1">
              <span className="text-[10px] text-slate-400 font-extrabold block">05_فهرس البحث (Index)</span>
              <span className="text-2xl font-black text-emerald-600 font-mono block mt-1">{warehouseStats.index}</span>
            </div>
          </div>

          {/* Interactive Ingestion Form & Flow representation */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Form column (Right Side) */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="border-b border-slate-100 pb-2">
                <h3 className="text-xs font-bold text-slate-900 font-sans">أداة تغذية المستودع ومعالجة الحقول لغوياً (Warehouse Ingestion)</h3>
                <p className="text-[10px] text-slate-400">مثال فوري لخط معالجة النصوص (NLP Pipeline): إدخال فقرة يقوم بتقطيعها لغوياً وبناء فهارسها المعجمية.</p>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 font-extrabold block">نص المدخل الفعلي (Raw Sentence Word):</label>
                  <textarea
                    value={warehouseInputText}
                    onChange={(e) => setWarehouseInputText(e.target.value)}
                    rows={2}
                    className="w-full text-xs p-3 border border-slate-200 rounded-lg focus:ring-1 focus:ring-emerald-500 font-semibold"
                    placeholder="مثال: فيصل كتب تقرير عن اللغة العربية"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-extrabold block">نوع المصدر (Source Type):</label>
                    <select
                      value={warehouseSourceType}
                      onChange={(e) => setWarehouseSourceType(e.target.value)}
                      className="w-full text-xs p-2.5 border border-slate-200 rounded-lg text-slate-700 font-bold"
                    >
                      <option value="chat">chat (محادثة فورية)</option>
                      <option value="file">file (ملف محلي)</option>
                      <option value="database">database (قاعدة خارجية)</option>
                      <option value="screen">screen (لقطة شاشة)</option>
                      <option value="unknown">unknown (غير معروف)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 font-extrabold block">مستوى الموثوقية (Trust Level):</label>
                    <select
                      value={warehouseTrustLevel}
                      onChange={(e: any) => setWarehouseTrustLevel(e.target.value)}
                      className="w-full text-xs p-2.5 border border-slate-200 rounded-lg text-slate-700 font-bold"
                    >
                      <option value="trusted">trusted (عالي الثقة)</option>
                      <option value="medium">medium (متوسط)</option>
                      <option value="low">low (منخفض)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 font-extrabold block">اسم أو عنوان المصدر ومساره:</label>
                  <input
                    value={warehouseSourceName}
                    onChange={(e) => setWarehouseSourceName(e.target.value)}
                    type="text"
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-lg font-semibold"
                    placeholder="مثال: محادثة المستخدم الفورية"
                  />
                </div>

                <button
                  onClick={handleIngestToWarehouse}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 hover:scale-[1.01] text-white font-black text-xs py-3 px-4 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                >
                  <DbIcon size={14} />
                  تشغيل خط المعالجة والحرث اللغوي (Execute Node)
                </button>
              </div>
            </div>

            {/* Ingestion Visual Flow Graphic (Left Side) */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4 flex flex-col justify-between">
              <div>
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-xs font-bold text-slate-900 font-sans">محاكاة المخطط الشمولي لتدفق المعرفة وحركتها بالـ SQLite Pipeline</h3>
                  <p className="text-[10px] text-slate-400">يوضح هذا المخطط العمليات المعقدة والروابط السبعة لكتابة وتحديث فهارس البيانات الذهبية.</p>
                </div>

                {/* Styled Pipeline Diagram of Universal Knowledge Warehouse */}
                <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl space-y-4 font-mono text-xs text-right mt-3 text-slate-600">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="font-extrabold text-[11px] text-slate-800">مرحلة معالجة وتدفق المدخلات النحوية اللفظية:</span>
                    <span className="bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded text-[9px] font-black">Active Phase ✅</span>
                  </div>

                  <div className="grid grid-cols-5 gap-1.5 text-center mt-2">
                    <div className="bg-white border-2 border-slate-250 p-2 rounded-lg space-y-1 text-center font-bold shadow-sm">
                      <div className="text-[9px] text-indigo-600 font-black">01_المصادر</div>
                      <div className="text-[10.5px] text-slate-900">Sources</div>
                    </div>
                    
                    <div className="flex items-center justify-center font-black text-indigo-500">➔</div>

                    <div className="bg-white border-2 border-indigo-200 p-2 rounded-lg space-y-1 font-bold shadow-sm">
                      <div className="text-[9px] text-slate-500 font-black">02_الكائنات</div>
                      <div className="text-[10.5px] text-slate-900">Index Obj</div>
                    </div>

                    <div className="flex items-center justify-center font-black text-indigo-500">➔</div>

                    <div className="bg-white border-2 border-emerald-200 p-2 rounded-lg space-y-1 font-bold shadow-sm">
                      <div className="text-[9px] text-emerald-600 font-black">03_المعجم اللغوي</div>
                      <div className="text-[10.5px] text-slate-900">Words (R3)</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center my-1 w-full text-indigo-500 font-black leading-none text-center">
                    ⬇
                  </div>

                  <div className="grid grid-cols-5 gap-1.5 text-center">
                    <div className="bg-white border-2 border-purple-200 p-2 rounded-lg space-y-1 font-bold col-span-2 shadow-sm">
                      <div className="text-[9px] text-purple-600 font-black">04_الرسم البياني للمعرفة</div>
                      <div className="text-[10.5px] text-slate-900">Relations Graph</div>
                    </div>

                    <div className="flex items-center justify-center font-black text-indigo-500">➔</div>

                    <div className="bg-white border-2 border-emerald-250 p-2 rounded-lg space-y-1 font-bold col-span-2 shadow-sm">
                      <div className="text-[9px] text-emerald-600 font-black">05_الفهرس الميداني السريع</div>
                      <div className="text-[10.5px] text-slate-900">Inverted Search</div>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400 leading-normal leading-relaxed pt-2.5 border-t border-slate-200/50">
                    * ملاحظة: يتم حفظ الكلمة مع بوابات التدرج الحروفي <code className="bg-white border text-indigo-600 px-1.5 py-0.5 rounded font-mono">seq_2 / seq_3 / seq_4</code> في القاموس والفهرسة اللحظية لتسهيل محاكاة خوارزميات الاقتراح الفوري المتقدمة.
                  </p>
                </div>
              </div>

              {/* Semantic search explorer */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3">
                <span className="text-[11px] text-slate-800 font-black block">محرّك الميكرو-بحث الفوري (Inverted Index Search Engine)</span>
                
                <div className="flex gap-2">
                  <input
                    value={warehouseSearchQuery}
                    onChange={(e) => {
                      setWarehouseSearchQuery(e.target.value);
                      handleWarehouseSearch(e.target.value);
                    }}
                    type="text"
                    className="flex-1 text-xs p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium font-semibold"
                    placeholder="ابحث في الفهرس اللغوي عن أي كلمة (مثال: فيصل، العربية)..."
                  />
                  <button
                    onClick={() => handleWarehouseSearch()}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 rounded-lg cursor-pointer"
                  >
                    بحث فوري
                  </button>
                </div>

                {warehouseSearchResults.length > 0 ? (
                  <div className="bg-white border border-slate-100 rounded-lg p-2 max-h-36 overflow-y-auto text-xs space-y-1.5 font-sans">
                    {warehouseSearchResults.map((resItem, i) => (
                      <div key={i} className="flex justify-between items-center p-2 hover:bg-slate-50 border-b border-slate-50 last:border-0">
                        <div className="text-right">
                          <span className="font-extrabold text-indigo-700 block">العثور على الكلمة: «{resItem['الكلمة']}»</span>
                          <span className="text-[10px] text-slate-400 block pb-0.5">في الجملة: {resItem['العنوان_الكامل']} ({resItem['المجال']})</span>
                        </div>
                        <span className="text-[10px] text-emerald-600 bg-emerald-50 font-bold px-1.5 py-0.5 rounded border border-emerald-100">
                          حقل {resItem['الحقل']} | وزن {resItem['الوزن']}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : warehouseSearchQuery ? (
                  <span className="text-[10.5px] text-slate-400 font-semibold block text-center">لا توجد نتائج مطابقة في الفهرس المقلوب حالياً.</span>
                ) : null}
              </div>
            </div>

          </div>

          {/* Table Data Explorers for SQLite Warehouse */}
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4">
            
            <div className="border-b border-indigo-50 pb-3 flex justify-between items-center flex-wrap gap-2">
              <div className="space-y-1 text-right">
                <h3 className="text-xs font-black text-slate-900 font-sans">معاينة جداول المستقر اللغوي في SQLite (Phase 1 Database In-Memory Table Explorer)</h3>
                <p className="text-[10.5px] text-slate-400">تصفح الفوري للمدخرات المخزنة بشكل معقد ومنظم لتوفير بيئة الاستهلاك في النظام.</p>
              </div>

              {/* Segmented Table buttons switcher */}
              <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-xl">
                {[
                  { id: 'sources', title: '01_المصادر (sources)' },
                  { id: 'universal_objects', title: '02_الكائنات (objects)' },
                  { id: 'words', title: '03_القاموس اللغوي (words)' },
                  { id: 'relations', title: '04_العلاقات البيانية (relations)' },
                  { id: 'inverted_index', title: '05_الفهرس المقلوب (index)' }
                ].map((tbl) => (
                  <button
                    key={tbl.id}
                    onClick={() => {
                      setWarehouseActiveViewTable(tbl.id as any);
                      fetchWarehouseTableRows(tbl.id);
                    }}
                    className={`text-[10.5px] font-bold py-1.5 px-3 rounded-lg transition-all cursor-pointer ${
                      warehouseActiveViewTable === tbl.id
                        ? 'bg-white text-emerald-700 shadow-sm border border-slate-200/50 font-black'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {tbl.title}
                  </button>
                ))}
              </div>
            </div>

            {/* Render selected table rows list */}
            {warehouseTableRows.length > 0 ? (
              <div className="overflow-x-auto border border-slate-150 rounded-xl bg-slate-50 max-h-96">
                <table className="w-full text-xs text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-200/60 border-b border-slate-200 text-slate-700 font-black">
                      {Object.keys(warehouseTableRows[0]).map((h) => (
                        <th key={h} className="p-3 font-semibold text-slate-800 bg-slate-100">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {warehouseTableRows.map((r, i) => (
                      <tr key={i} className="hover:bg-slate-100/60 border-b border-slate-100 bg-white transition-colors">
                        {Object.values(r).map((val: any, j) => (
                          <td key={j} className="p-3 text-slate-700 font-semibold font-mono whitespace-nowrap overflow-hidden text-ellipsis max-w-xs leading-5">
                            {val === null ? <span className="text-slate-300 font-light italic">-</span> : String(val)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-xl font-bold font-sans">
                لا توجد سجلات فاعلة مدرجة في هذا الجدول حالياً.
              </div>
            )}
          </div>
        </div>
      ) : (
        /* INTERACTIVE_QUERY TAB CONTENT (NEW INTERACTIVE DUAL SQL LOCAL DB QUERY MODULE) */
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-lg text-xs font-bold flex items-center gap-1">
                  <Terminal size={14} className="text-indigo-500 animate-pulse" />
                  برنامج الاستعلام المزدوج التفاعلي في قواعد البيانات SQLite المحلية
                </span>
                <h2 className="text-md font-extrabold text-slate-900 font-sans">الاستعلام البرمجي التفاعلي لملفي 01_sources.db و 02_universal_index.db</h2>
              </div>
              <span className="text-[10px] text-indigo-600 bg-indigo-50 border border-indigo-150 rounded-full font-bold px-3 py-1 font-mono">
                 sql.js WASM Active
              </span>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed font-semibold">
              تتيح لك هذه المنصة التفاعلية المتقدمة كتابة استعلامات لغة SQL وتطبيقها على ملفي قواعد البيانات المحليين <strong className="text-slate-800 font-sans">01_sources.db</strong> و <strong className="text-indigo-600 font-sans">02_universal_index.db</strong>. يمكنك الاختيار بين الاستعلام عن بيانات الهيكل الافتراضي المشحون بنصوص وتراجم القرآن الموثقة، أو رفع ملفات SQLite حقيقية تملكها محلياً من جهازك ومحاذاة الفهارس بها لحظياً.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Database Selection & Schema helper column */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-xs font-black text-slate-800 font-sans">اختر قاعدة البيانات المستهدفة للاستعلام</h3>
                  <p className="text-[10px] text-slate-400">حدد قاعدة البيانات النشطة للتوجه وكتابة الأوامر عليها</p>
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      setSelectedInteractiveDb('sources');
                      setInteractiveSqlQuery('SELECT * FROM sources LIMIT 5;');
                      setInteractiveQueryResult(null);
                      setInteractiveQueryError(null);
                      setInteractiveQueryStats(null);
                    }}
                    className={`flex items-center justify-between p-3 rounded-xl border text-right cursor-pointer transition-all ${
                      selectedInteractiveDb === 'sources'
                        ? 'border-indigo-500 bg-indigo-50/50 shadow-xs'
                        : 'border-slate-250 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-right">
                      <span className="text-[11px] font-black text-slate-800 block">01_sources.db</span>
                      <span className="text-[10px] text-slate-400 block pt-0.5 font-semibold">قاعدة بيانات مصادر ومستندات الإدخال العميقة</span>
                    </div>
                    <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                      selectedInteractiveDb === 'sources' ? 'border-indigo-600 bg-indigo-600' : 'border-slate-300'
                    }`} />
                  </button>

                  <button
                    onClick={() => {
                      setSelectedInteractiveDb('universal_index');
                      setInteractiveSqlQuery('SELECT * FROM words LIMIT 5;');
                      setInteractiveQueryResult(null);
                      setInteractiveQueryError(null);
                      setInteractiveQueryStats(null);
                    }}
                    className={`flex items-center justify-between p-3 rounded-xl border text-right cursor-pointer transition-all ${
                      selectedInteractiveDb === 'universal_index'
                        ? 'border-indigo-500 bg-indigo-50/50 shadow-xs'
                        : 'border-slate-250 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-right">
                      <span className="text-[11px] font-black text-slate-800 block">02_universal_index.db</span>
                      <span className="text-[10px] text-slate-400 block pt-0.5 font-semibold font-sans">قاعدة بيانات الفهرس الشامل، الكلمات، العلاقات والمعجم</span>
                    </div>
                    <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                      selectedInteractiveDb === 'universal_index' ? 'border-indigo-600 bg-indigo-600' : 'border-slate-300'
                    }`} />
                  </button>
                </div>
              </div>

              {/* Local File Ingestion / Upload Zones */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-xs font-black text-slate-800 font-sans">تغذية ورفع ملفات .db حقيقية (Upload Custom DB File)</h3>
                  <p className="text-[10px] text-slate-400">يمكنك رفع ملف SQLite الخاص بك من جهازك (مثال: D:\\OneDrive\\Desktop\\5656\\data_layer\\db\\corrections.sqlite) للاستعلام التفاعلي المباشر</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5 flex flex-col justify-end text-right">
                    <label className="text-[10.5px] font-bold text-slate-600 block">مرجع ملف 01_sources.db:</label>
                    <div className="flex gap-2 items-center">
                      <input
                        type="file"
                        accept=".db,.sqlite,.sqlite3"
                        id="sources-db-upload"
                        className="hidden"
                        onChange={handleSourcesDbUpload}
                      />
                      <button
                        onClick={() => document.getElementById('sources-db-upload')?.click()}
                        className="text-[10px] bg-slate-900 border border-slate-250 hover:bg-slate-800 text-white font-bold p-2 px-3.5 rounded-lg cursor-pointer flex items-center gap-1 flex-1 justify-center"
                      >
                        <Upload size={12} />
                        تصفح ملف sources
                      </button>
                    </div>
                    {sourcesDbFile ? (
                      <span className="text-[10px] text-emerald-600 font-bold block pt-1 bg-emerald-50 border border-emerald-100 p-1.5 rounded-lg font-mono">
                        📂 تم تحميل وتغذية: {sourcesDbFile.name} ({Math.round(sourcesDbFile.size / 1024)} KB)
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 block pt-1 font-semibold italic">
                        * نشط الآن: قالب المرجعية المفرغ المشحون تلقائياً ببيانات القرآن والقرية.
                      </span>
                    )}
                  </div>

                  <div className="space-y-1.5 border-t border-slate-100 pt-3 flex flex-col justify-end text-right">
                    <label className="text-[10.5px] font-bold text-slate-600 block">مرجع ملف 02_universal_index.db:</label>
                    <div className="flex gap-2 items-center">
                      <input
                        type="file"
                        accept=".db,.sqlite,.sqlite3"
                        id="unival-db-upload"
                        className="hidden"
                        onChange={handleUniversalIndexDbUpload}
                      />
                      <button
                        onClick={() => document.getElementById('unival-db-upload')?.click()}
                        className="text-[10px] bg-slate-900 border border-slate-250 hover:bg-slate-800 text-white font-bold p-2 px-3.5 rounded-lg cursor-pointer flex items-center gap-1 flex-1 justify-center"
                      >
                        <Upload size={12} />
                        تصفح ملف index
                      </button>
                    </div>
                    {universalIndexDbFile ? (
                      <span className="text-[10px] text-emerald-600 font-bold block pt-1 bg-emerald-50 border border-emerald-100 p-1.5 rounded-lg font-mono">
                        📂 تم تحميل وتغذية: {universalIndexDbFile.name} ({Math.round(universalIndexDbFile.size / 1024)} KB)
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 block pt-1 font-semibold italic">
                        * نشط الآن: الهيكل الافتراضي للكلمات المعجمية والعلاقات اللغوية.
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Database Schema Map guide card */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
                <span className="text-[10px] text-slate-400 font-extrabold block">مستندات الهيكل البنيوي النشط (Active Catalog Schema Reference):</span>
                {selectedInteractiveDb === 'sources' ? (
                  <div className="text-[10px] text-slate-600 space-y-1 pr-1 font-mono">
                    <span className="font-extrabold text-[10.5px] text-slate-700 block">الجدول متاح: sources</span>
                    <span className="block">• <strong className="text-slate-800 font-sans">source_id</strong>: المعرف الأساسي</span>
                    <span className="block">• <strong className="text-slate-800 font-sans">source_name</strong>: اسم مستند التدريب المرجعي</span>
                    <span className="block">• <strong className="text-slate-800 font-sans">source_path</strong>: المسار الفعلي</span>
                    <span className="block">• <strong className="text-slate-800 font-sans">size_bytes</strong>: الحجم الكلي للملف</span>
                    <span className="block">• <strong className="text-slate-800 font-sans">trust_level</strong>: مستوى الموثوقية العلمي</span>
                  </div>
                ) : (
                  <div className="text-[10px] text-slate-600 space-y-1.5 pr-1 font-mono">
                    <div>
                      <span className="font-extrabold text-[10.5px] text-slate-700 block">01) universal_objects</span>
                      <span className="text-[9.5px] text-slate-450 block ml-1 leading-normal">• المعرف: object_id, العنوان: title, المجال: domain</span>
                    </div>
                    <div>
                      <span className="font-extrabold text-[10.5px] text-slate-700 block gap-x-1">02) words</span>
                      <span className="text-[9.5px] text-slate-450 block ml-1 leading-normal">• الكلمة: word, الجذر: root, التدرجات: seq_2/seq_3</span>
                    </div>
                    <div>
                      <span className="font-extrabold text-[10.5px] text-slate-700 block">03) relations</span>
                      <span className="text-[9.5px] text-slate-450 block ml-1 leading-normal">• المحمول: predicate, الثقة: confidence, البرهان: evidence_text</span>
                    </div>
                    <div>
                      <span className="font-extrabold text-[10.5px] text-slate-700 block">04) inverted_index</span>
                      <span className="text-[9.5px] text-slate-450 block ml-1 leading-normal">• المصطلح: term, الحقل: field_name, الوزن: weight</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* SQL Terminal text prompt and results rendering pane (Right Side) */}
            <div className="lg:col-span-8 space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4 font-sans text-right">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-xs font-black text-slate-800 font-sans">تنفيذ استعلامات SQL تفاعلية فورية (Active Interactive SQL Studio)</h3>
                  <p className="text-[10px] text-slate-400 font-sans">اكتب أوامر SELECT أو عمليات التجميع JOIN ومطابقة القواميس بالأسفل، واعرض المخرجات تفاعلياً.</p>
                </div>

                {/* SQL Presets templates switches row */}
                <div className="space-y-1 text-right">
                  <span className="text-[10px] text-slate-450 font-bold block mb-1">استعلامات منسقة سريعة:</span>
                  <div className="flex flex-wrap gap-1.5 justify-end" dir="rtl">
                    {(selectedInteractiveDb === 'sources'
                      ? INTERACTIVE_TEMPLATES_SOURCES
                      : INTERACTIVE_TEMPLATES_INDEX
                    ).map((tmpl, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setInteractiveSqlQuery(tmpl.query);
                          handleExecuteInteractiveSQL(tmpl.query);
                        }}
                        className="text-[9.5px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200/50 py-1.5 px-3 rounded-lg transition-all cursor-pointer"
                      >
                        {tmpl.title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* TEXT EDITOR SPACE FOR INTERACTIVE QUERY */}
                <div className="space-y-1.5 pt-2 text-right">
                  <label className="text-[10px] text-slate-400 font-bold block font-sans">لوحة أوامر SQL لقاعدة البيانات المختارة:</label>
                  <div className="relative border border-slate-200 rounded-xl overflow-hidden bg-slate-950 font-mono text-xs shadow-inner">
                    <textarea
                      value={interactiveSqlQuery}
                      onChange={(e) => setInteractiveSqlQuery(e.target.value)}
                      className="w-full h-36 p-4 bg-slate-900 text-emerald-400 font-mono text-xs focus:outline-none border-none text-left leading-relaxed select-all"
                      dir="ltr"
                      placeholder="Write your SQLite commands here..."
                    />

                    <div className="bg-slate-950 p-3 border-t border-slate-850 flex justify-between items-center flex-wrap gap-2">
                      <span className="text-[9px] text-slate-400 font-sans font-semibold">
                        قاعدة البيانات النشطة المنفذ عليها: <strong>{selectedInteractiveDb === 'sources' ? '01_sources.db' : '02_universal_index.db'}</strong>
                      </span>

                      <button
                        onClick={() => handleExecuteInteractiveSQL()}
                        className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] py-1.5 px-5 rounded-lg transition-all cursor-pointer shadow-md"
                      >
                        <Play size={10} />
                        تشغيل الاستعلام التفاعلي
                      </button>
                    </div>
                  </div>
                </div>

                {/* Stats info box */}
                {interactiveQueryStats && (
                  <div className="bg-slate-100/50 text-[10px] text-slate-500 p-2 rounded-lg flex gap-3 font-bold justify-end font-mono">
                    <span>الصفوف: {interactiveQueryStats.rows} صفا</span>
                    <span>•</span>
                    <span>زمن التنفيذ: {interactiveQueryStats.timeMs} ملي ثانية</span>
                  </div>
                )}

                {/* Result output display table */}
                <div className="border border-slate-150 rounded-xl overflow-hidden shadow-xs text-right">
                  <div className="bg-slate-50 border-b border-slate-150 p-2 text-[10px] font-bold text-slate-700 flex justify-between">
                    <span>مخرجات جدول نتائج الاستعلام كـ SQLite Raw View:</span>
                    <span className="text-slate-400 font-semibold font-mono">DataTable</span>
                  </div>

                  <div className="max-h-80 overflow-auto">
                    {interactiveQueryError ? (
                      <div className="p-6 text-center text-[10.5px] text-rose-600 bg-rose-50/50 flex flex-col items-center justify-center gap-1.5 font-bold">
                        <ShieldAlert size={20} className="text-rose-500" />
                        <span>خطأ في تنفيذ وتفسير أمر الـ SQL في المحرك سيت:</span>
                        <pre className="text-[9.5px] text-rose-700 bg-white border border-rose-100 p-2.5 rounded font-mono select-all w-full leading-normal text-left" dir="ltr">
                          {interactiveQueryError}
                        </pre>
                      </div>
                    ) : interactiveQueryResult ? (
                      <table className="w-full text-[10px] text-slate-750 font-mono border-collapse" dir="rtl">
                        <thead>
                          <tr className="bg-slate-100 text-slate-600 font-black border-b border-slate-200">
                            {interactiveQueryResult.columns.map((col, idx) => (
                              <th key={idx} className="p-2.5 text-right font-sans whitespace-nowrap">{col}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 bg-white">
                          {interactiveQueryResult.values.length > 0 ? (
                            interactiveQueryResult.values.map((row, rowIdx) => (
                              <tr key={rowIdx} className="hover:bg-slate-50 font-sans transition-colors">
                                {row.map((val, cellIdx) => (
                                  <td key={cellIdx} className="p-2.5 whitespace-nowrap text-slate-800 font-bold block-inline overflow-hidden text-ellipsis max-w-xs leading-5">
                                    {val === null ? <em className="text-slate-450 font-light font-mono text-[9px]">NULL</em> : String(val)}
                                  </td>
                                ))}
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={Math.max(1, interactiveQueryResult.columns.length)} className="p-6 text-center text-[10px] text-slate-450 font-semibold font-sans">
                                نفذ الاستعلام بنجاح ولكنه لم يعثر على صفوف مطابقة لعرضها (Empty Query ResultSet).
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    ) : (
                      <div className="p-8 text-center text-[11px] text-slate-400 font-semibold font-sans">
                        اكتب جملة استعلامية تفاعلية، أو اختر أحد القوالب التفاعلية الجاهزة لبث جداول البيانات مباشرة.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Persistent SQLite Console at the bottom */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm flex flex-col justify-between space-y-5">
        
        <div className="space-y-4">
          
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between flex-wrap gap-2">
            <div className="space-y-0.5 text-right">
              <h3 className="text-sm font-bold text-slate-900 font-sans">استوديو التحكم في SQLite (Visual SQLite Studio)</h3>
              <p className="text-[11px] text-slate-400">منصة تفاعلية مدمجة لتنفيذ الاستعلامات، فحص العلاقات وحالة الفهارس وتجريب لغة SQL لمصنوفات الحروف وQPEC.</p>
            </div>

            <div className="flex items-center gap-1.5 font-bold text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-lg p-1.5 px-3">
              <Terminal size={11} />
              <span>محرك SQLite: Active (WASMLoaded)</span>
            </div>
          </div>

          {/* Quick Templates List */}
          <div className="space-y-1.5">
            <span className="text-[10px] text-slate-400 font-bold block mb-1 text-right">استعلم بنقرة واحدة (قوالب جاهزة):</span>
            <div className="flex flex-wrap gap-1.5 justify-end">
              {SQL_TEMPLATES.map((tmpl, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSqlQuery(tmpl.query);
                    handleExecuteConsoleSQL(tmpl.query);
                  }}
                  className="text-[9px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 py-1.5 px-2.5 rounded-lg transition-all cursor-pointer"
                >
                  {tmpl.title}
                </button>
              ))}
            </div>
          </div>

          {/* SQL Terminal text prompt and query run trigger */}
          <div className="space-y-1.5 pt-2">
            <label className="text-[10px] text-slate-400 font-bold block text-right">محرر أوامر SQL (Raw SQLite Command Editor):</label>
            <div className="relative border border-slate-200 rounded-xl overflow-hidden bg-slate-900 font-mono text-xs">
              
              <textarea
                value={sqlQuery}
                onChange={(e) => setSqlQuery(e.target.value)}
                className="w-full h-36 p-4 bg-slate-950 text-emerald-400 font-mono text-xs focus:outline-none border-none text-left leading-normal selection:bg-indigo-900"
                dir="ltr"
                placeholder="Write your raw SELECT, JOIN, or aggregate SQL commands here..."
              />

              <div className="bg-slate-900 p-2.5 border-t border-slate-800 flex justify-between items-center flex-wrap gap-1.5">
                <span className="text-[9px] text-slate-400 font-semibold font-sans">
                  يمكنك كتابة أي جملة استعلامية لغة SQL Standard
                </span>
                
                <button
                  onClick={() => handleExecuteConsoleSQL()}
                  className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] py-1.5 px-4 rounded-lg transition-all shadow-sm cursor-pointer"
                >
                  <Play size={10} />
                  نشِّط الاستعلام واعرض المخرجات
                </button>
              </div>
            </div>
          </div>

          {/* Result Stats bar */}
          {queryStats && (
            <div className="bg-slate-50 text-[10px] text-slate-500 p-2 rounded-lg flex gap-3 font-semibold justify-end">
              <span>تاريخ التنفيذ: {new Date().toLocaleTimeString('ar-EG')}</span>
              <span>•</span>
              <span>الصفوف المسترجعة: {queryStats.rows} صفاً</span>
              <span>•</span>
              <span>زمن الاستدعاء: {queryStats.timeMs} ملي ثانية</span>
            </div>
          )}

          {/* Query result table wrapper */}
          <div className="border border-slate-150 rounded-xl overflow-hidden shadow-xs">
            <div className="bg-slate-50 border-b border-slate-150 p-2.5 text-[10px] font-bold text-slate-700 flex justify-between">
              <span>معاينة جدول المخرجات والنتائج الفرعية:</span>
              <span className="text-slate-400 font-semibold">SQLite Storage Engine</span>
            </div>

            <div className="max-h-56 overflow-auto">
              {queryError ? (
                <div className="p-6 text-center text-[11px] text-rose-600 bg-rose-50/50 flex flex-col items-center justify-center gap-1.5 font-bold">
                  <ShieldAlert size={20} className="text-rose-500" />
                  <span>خطأ في تنفيذ وتفسير أمر الـ SQL في المحرك سيت:</span>
                  <pre className="text-[10px] text-rose-700 bg-white border border-rose-100 p-2.5 rounded font-mono select-all w-full leading-normal">{queryError}</pre>
                </div>
              ) : queryResult ? (
                <table className="w-full text-[10px] text-slate-700 font-mono border-collapse" dir="rtl">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 font-black border-b border-slate-200">
                      {queryResult.columns.map((col, idx) => (
                        <th key={idx} className="p-2.5 text-right font-sans whitespace-nowrap">{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {queryResult.values.length > 0 ? (
                      queryResult.values.map((row, rowIdx) => (
                        <tr key={rowIdx} className="hover:bg-slate-50 font-sans">
                          {row.map((val, cellIdx) => (
                            <td key={cellIdx} className="p-2.5 whitespace-nowrap text-slate-800 font-medium">
                              {val === null ? <em className="text-slate-350">NULL</em> : String(val)}
                            </td>
                          ))}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={queryResult.columns.length} className="p-6 text-center text-[10px] text-slate-400 font-semibold">
                          لا يوجد صفوف مسترجعة مطابقة للاستعلام المحدد.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              ) : (
                <div className="p-8 text-center text-[11px] text-slate-400 font-bold">
                  اكتب أوامرك البرمجية أو اضغط على أحد قوالب الاستعلامات بالرأس لتفعيل محتوى المستودع ومعاينة الجداول فورا.
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
