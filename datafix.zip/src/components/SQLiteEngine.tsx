import React, { useState, useEffect } from 'react';
import initSqlJs, { Database, QueryExecResult } from 'sql.js';
import { 
  Database as DbIcon, 
  Terminal, 
  Play, 
  Table, 
  RefreshCw, 
  AlertCircle,
  CheckCircle2,
  Trash2,
  Download,
  Info,
  ChevronRight
} from 'lucide-react';

const UNIFIED_SCHEMA = `
-- 1-4) Language Core Tables
CREATE TABLE IF NOT EXISTS Languages (
    language_id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name_ar TEXT NOT NULL,
    direction TEXT DEFAULT 'RTL'
);

CREATE TABLE IF NOT EXISTS Language_Letters (
    letter_id TEXT PRIMARY KEY,
    language_id TEXT NOT NULL,
    letter TEXT NOT NULL,
    letter_name TEXT,
    letter_order INTEGER,
    unicode_codepoint TEXT,
    FOREIGN KEY (language_id) REFERENCES Languages(language_id)
);

CREATE TABLE IF NOT EXISTS Arabic_Letter_Forms (
    form_id TEXT PRIMARY KEY,
    letter_id TEXT NOT NULL,
    isolated TEXT,
    initial TEXT,
    medial TEXT,
    final TEXT,
    FOREIGN KEY (letter_id) REFERENCES Language_Letters(letter_id)
);

CREATE TABLE IF NOT EXISTS Scripts (
    script_id TEXT PRIMARY KEY,
    script_name TEXT NOT NULL,
    description TEXT
);

-- 5-9) QPEC (Quran PDF Error Capture) Tables
CREATE TABLE IF NOT EXISTS qpec_reference_words (
    word_id TEXT PRIMARY KEY,
    surah_num INTEGER,
    ayah_num INTEGER,
    word_pos INTEGER,
    word_text TEXT NOT NULL,
    norm_word TEXT
);

CREATE TABLE IF NOT EXISTS qpec_extraction_attempts (
    attempt_id TEXT PRIMARY KEY,
    word_id TEXT NOT NULL,
    engine_name TEXT,
    extracted_text TEXT,
    status TEXT,
    FOREIGN KEY (word_id) REFERENCES qpec_reference_words(word_id)
);

CREATE TABLE IF NOT EXISTS qpec_extraction_errors (
    error_id TEXT PRIMARY KEY,
    attempt_id TEXT NOT NULL,
    issue_type TEXT,
    wrong_text TEXT,
    correct_text TEXT,
    FOREIGN KEY (attempt_id) REFERENCES qpec_extraction_attempts(attempt_id)
);

CREATE TABLE IF NOT EXISTS qpec_error_rules (
    rule_id TEXT PRIMARY KEY,
    signature TEXT UNIQUE,
    correction_logic TEXT,
    is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS qpec_validation_logs (
    log_id TEXT PRIMARY KEY,
    run_timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
    summary TEXT,
    errors_count INTEGER
);

-- 10-14) Universal Knowledge Warehouse Tables
CREATE TABLE IF NOT EXISTS sources (
    source_id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    name TEXT,
    path TEXT,
    file_hash TEXT,
    size INTEGER,
    trust_level TEXT DEFAULT 'medium'
);

CREATE TABLE IF NOT EXISTS universal_objects (
    object_id TEXT PRIMARY KEY,
    source_id TEXT,
    type TEXT,
    domain TEXT,
    content_summary TEXT,
    FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE IF NOT EXISTS word_lake (
    word_id TEXT PRIMARY KEY,
    object_id TEXT,
    text TEXT NOT NULL,
    root TEXT,
    type TEXT,
    frequency INTEGER DEFAULT 1,
    FOREIGN KEY (object_id) REFERENCES universal_objects(object_id)
);

CREATE TABLE IF NOT EXISTS knowledge_relations (
    rel_id TEXT PRIMARY KEY,
    subject_id TEXT,
    predicate TEXT,
    object_id TEXT,
    confidence REAL,
    FOREIGN KEY (subject_id) REFERENCES universal_objects(object_id),
    FOREIGN KEY (object_id) REFERENCES universal_objects(object_id)
);

CREATE TABLE IF NOT EXISTS inverted_index (
    index_id TEXT PRIMARY KEY,
    term TEXT NOT NULL,
    object_id TEXT,
    field TEXT,
    position INTEGER,
    FOREIGN KEY (object_id) REFERENCES universal_objects(object_id)
);

-- 15-22) Quran Metadata Tables (Scholarly Reference)
CREATE TABLE IF NOT EXISTS quran_surahs (
    surah_id INTEGER PRIMARY KEY,
    name_ar TEXT,
    name_en TEXT,
    type TEXT,
    ayahs_count INTEGER
);

CREATE TABLE IF NOT EXISTS quran_ayahs (
    ayah_id INTEGER PRIMARY KEY,
    surah_id INTEGER,
    ayah_num INTEGER,
    text TEXT,
    page INTEGER,
    juz INTEGER,
    FOREIGN KEY (surah_id) REFERENCES quran_surahs(surah_id)
);

CREATE TABLE IF NOT EXISTS quran_juzs (
    juz_num INTEGER PRIMARY KEY,
    start_surah INTEGER,
    start_ayah INTEGER
);

CREATE TABLE IF NOT EXISTS quran_pages (
    page_num INTEGER PRIMARY KEY,
    juz_num INTEGER,
    surah_num INTEGER
);

CREATE TABLE IF NOT EXISTS quran_manzils (
    manzil_num INTEGER PRIMARY KEY,
    start_surah INTEGER
);

CREATE TABLE IF NOT EXISTS quran_sajdas (
    sajda_id INTEGER PRIMARY KEY,
    surah_num INTEGER,
    ayah_num INTEGER,
    type TEXT
);

CREATE TABLE IF NOT EXISTS quran_rukus (
    ruku_id INTEGER PRIMARY KEY,
    surah_num INTEGER,
    ayah_num INTEGER
);

CREATE TABLE IF NOT EXISTS quran_translations (
    trans_id TEXT PRIMARY KEY,
    ayah_id INTEGER,
    language_code TEXT,
    translated_text TEXT,
    FOREIGN KEY (ayah_id) REFERENCES quran_ayahs(ayah_id)
);

-- 23-30) System Management Tables
CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    username TEXT UNIQUE,
    role TEXT DEFAULT 'viewer',
    last_login TEXT
);

CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    description TEXT
);

CREATE TABLE IF NOT EXISTS system_logs (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    level TEXT,
    module TEXT,
    message TEXT,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_cache (
    cache_key TEXT PRIMARY KEY,
    data TEXT,
    expiry TEXT
);

CREATE TABLE IF NOT EXISTS audit_trails (
    audit_id TEXT PRIMARY KEY,
    user_id TEXT,
    action TEXT,
    table_name TEXT,
    record_id TEXT,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS schema_versions (
    version_id INTEGER PRIMARY KEY,
    applied_at TEXT DEFAULT CURRENT_TIMESTAMP,
    description TEXT
);

CREATE TABLE IF NOT EXISTS task_queue (
    task_id TEXT PRIMARY KEY,
    task_type TEXT,
    payload TEXT,
    status TEXT DEFAULT 'pending',
    retry_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS engine_profiles (
    profile_id TEXT PRIMARY KEY,
    name TEXT,
    config_json TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`;

export default function SQLiteEngine() {
  const [db, setDb] = useState<Database | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('SELECT count(*) FROM sqlite_master WHERE type="table";');
  const [results, setResults] = useState<QueryExecResult[] | null>(null);
  const [stats, setStats] = useState({ tables: 0, rows: 0 });
  const [activeTable, setActiveTable] = useState<string | null>(null);
  const [tables, setTables] = useState<string[]>([]);

  useEffect(() => {
    async function init() {
      try {
        setIsReady(false);
        setError(null);
        
        const SQL = await initSqlJs({
          locateFile: file => `https://sql.js.org/dist/${file}`
        });

        const newDb = new SQL.Database();
        newDb.run(UNIFIED_SCHEMA);
        
        newDb.run("INSERT OR IGNORE INTO Languages (language_id, code, name_ar) VALUES ('L1', 'ar', 'العربية');");
        newDb.run("INSERT OR IGNORE INTO quran_surahs (surah_id, name_ar, ayahs_count) VALUES (1, 'الفاتحة', 7);");
        newDb.run("INSERT OR IGNORE INTO system_settings (key, value) VALUES ('version', '1.0.1');");
        newDb.run("INSERT OR IGNORE INTO users (user_id, username, role) VALUES ('U1', 'faisal', 'researcher');");

        setDb(newDb);
        setIsReady(true);
        refreshStats(newDb);
      } catch (err: any) {
        console.error('SQL.js Init Error:', err);
        setError(`SQLite Initialization failed: ${err.message || err.toString()}`);
      }
    }
    init();
  }, []);

  const refreshStats = (database: Database) => {
    try {
      const tableList = database.exec('SELECT name FROM sqlite_master WHERE type="table" AND name NOT LIKE "sqlite_%"');
      if (tableList.length > 0) {
        const names = tableList[0].values.map(row => String(row[0]));
        setTables(names);
        setStats(prev => ({ ...prev, tables: names.length }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const executeQuery = () => {
    if (!db || !query) return;
    try {
      const res = db.exec(query);
      setResults(res);
      setError(null);
      refreshStats(db);
    } catch (err: any) {
      setError(err.message);
      setResults(null);
    }
  };

  const resetDB = () => {
    if (!db) return;
    if (confirm('هل أنت متأكد من رغبتك في إعادة ضبط قاعدة البيانات؟')) {
      window.location.reload(); 
    }
  };

  return (
    <div id="sqlite-engine-root" className="flex flex-col h-[700px] bg-slate-50 overflow-hidden font-sans border border-slate-200 rounded-xl shadow-lg">
      {/* Header */}
      <div id="engine-header" className="bg-white px-6 py-4 border-b border-slate-200 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 rounded-lg">
            <DbIcon className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800 leading-tight">محرك SQLite الموحد</h2>
            <p className="text-[10px] uppercase tracking-tighter text-slate-400 font-bold">Local WebAssembly Database Engine</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isReady && !error && (
            <div className="flex items-center gap-2 text-amber-600 text-sm bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100 animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>جاري التحميل...</span>
            </div>
          )}
          {isReady && (
            <div className="flex items-center gap-2 text-emerald-600 text-sm bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100 font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>نظام القواعد جاهز</span>
            </div>
          )}
          {error && (
            <div className="flex items-center gap-2 text-rose-600 text-sm bg-rose-50 px-3 py-1.5 rounded-full border border-rose-100">
              <AlertCircle className="w-4 h-4" />
              <span>فشل في تهيئة Wasm</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div id="engine-sidebar" className="w-64 border-l border-slate-200 bg-white flex flex-col overflow-hidden hidden md:flex">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2">
              <Table className="w-4 h-4 text-slate-500" />
              <span className="font-bold text-slate-700 text-xs">الجداول المصممة</span>
            </div>
            <span className="text-[10px] font-black bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded">
              {tables.length}
            </span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 space-y-0.5 scrollbar-thin">
            {tables.map(tableName => (
              <button
                key={tableName}
                onClick={() => {
                  setQuery(`SELECT * FROM ${tableName} LIMIT 100;`);
                  setActiveTable(tableName);
                }}
                className={`w-full text-right px-3 py-2 rounded-lg text-xs transition-all flex items-center justify-between group ${
                  activeTable === tableName 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100' 
                  : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span className="truncate">{tableName}</span>
                <ChevronRight className={`w-3 h-3 transition-transform ${activeTable === tableName ? 'rotate-90 opacity-100 text-white' : 'opacity-0 group-hover:opacity-40'}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Console Area */}
        <div id="engine-main" className="flex-1 flex flex-col overflow-hidden bg-white">
          <div className="p-4 space-y-4 flex-1 flex flex-col overflow-hidden">
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
              <div className="px-4 py-2 bg-slate-800 border-b border-slate-700 flex items-center justify-between text-slate-300">
                <div className="flex items-center gap-2 text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-300">
                  <Terminal className="w-3.5 h-3.5" />
                  <span>SQL Console Input</span>
                </div>
              </div>
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full h-32 p-4 font-mono text-xs leading-relaxed text-indigo-900 focus:outline-none resize-none bg-indigo-50/10"
                placeholder="Write your SQL command..."
                dir="ltr"
              />
              <div className="px-4 py-2 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
                <button
                  disabled={!isReady}
                  onClick={executeQuery}
                  className="flex items-center gap-2 px-5 py-2 bg-indigo-600 text-white rounded-lg text-xs font-black hover:bg-indigo-700 disabled:opacity-50 shadow-sm transition-all"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>تـنـفـيـذ الاستـعـلام</span>
                </button>
                
                <button onClick={resetDB} className="text-slate-300 hover:text-rose-500 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-rose-50 border border-rose-100 rounded-lg flex items-start gap-3 text-rose-700 text-xs">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <div className="font-mono font-bold uppercase tracking-tight">{error}</div>
              </div>
            )}

            <div id="results-area" className="flex-1 overflow-auto bg-slate-50 rounded-xl border border-slate-200/60 p-1">
              {!results && !error && (
                <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-2 p-10 opacity-60 italic text-center">
                  <Info className="w-10 h-10 stroke-1" />
                  <p className="text-xs">Console is waiting for execution. Select a table from the sidebar or type a query.</p>
                </div>
              )}

              {results && results.map((res, i) => (
                <div key={i} className="bg-white rounded-lg overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px] text-right">
                      <thead>
                        <tr className="bg-slate-100/80 text-slate-500 border-b border-slate-200">
                          <th className="px-3 py-2 border-l border-slate-100 text-center w-8 font-mono">#</th>
                          {res.columns.map(col => (
                            <th key={col} className="px-3 py-2 font-bold border-l border-slate-100 text-slate-700 whitespace-nowrap">{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {res.values.length === 0 ? (
                          <tr>
                            <td colSpan={res.columns.length + 1} className="px-4 py-10 text-center text-slate-400 font-medium italic">
                              Result set is empty
                            </td>
                          </tr>
                        ) : (
                          res.values.map((row, rowIndex) => (
                            <tr key={rowIndex} className="border-b border-slate-50 hover:bg-indigo-50/30">
                              <td className="px-3 py-1.5 text-center text-slate-300 font-mono border-l border-slate-100">{rowIndex + 1}</td>
                              {row.map((val, cellIndex) => (
                                <td key={cellIndex} className="px-3 py-1.5 border-l border-slate-100 max-w-sm truncate text-slate-600 font-medium">
                                  {val === null ? <span className="opacity-30 italic">NULL</span> : String(val)}
                                </td>
                              ))}
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-slate-900 text-slate-400 px-6 py-2.5 flex items-center justify-between text-[9px] font-black uppercase tracking-widest">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse shadow-[0_0_8px_rgba(99,102,241,0.8)]"></span>
            <span>SYSTEM TABLES: {stats.tables} / 30 IDENTIFIED</span>
          </div>
          <div className="flex items-center gap-2 border-r border-white/10 pr-6 h-3">
             <span>SCHEMA VER: 1.1.0</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-slate-500">
          <span>SQLITE3 WASM MODULE RUNNING</span>
          <span>© 2026</span>
        </div>
      </div>
    </div>
  );
}
