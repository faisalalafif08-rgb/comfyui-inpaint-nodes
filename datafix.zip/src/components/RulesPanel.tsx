import { useState, FormEvent } from 'react';
import { Sliders, Plus, Trash2, HelpCircle, Cloud } from 'lucide-react';

interface RulesPanelProps {
  rules: Record<string, boolean>;
  onToggleRule: (ruleId: string) => void;
  customRules: { id?: string; original: string; corrected: string }[];
  onAddCustomRule: (original: string, corrected: string) => void;
  onRemoveCustomRule: (index: number) => void;
  isSignedIn?: boolean;
}

export default function RulesPanel({
  rules,
  onToggleRule,
  customRules,
  onAddCustomRule,
  onRemoveCustomRule,
  isSignedIn = false
}: RulesPanelProps) {
  const [newOriginal, setNewOriginal] = useState('');
  const [newCorrected, setNewCorrected] = useState('');

  const handleSubmitCustom = (e: FormEvent) => {
    e.preventDefault();
    if (!newOriginal.trim() || !newCorrected.trim()) return;
    onAddCustomRule(newOriginal.trim(), newCorrected.trim());
    setNewOriginal('');
    setNewCorrected('');
  };

  const ruleLabels = [
    {
      id: 'fixMaksuraPrefix',
      title: 'إصلاح البادئات التالفة والتشوهات الشاذة',
      description: 'إصلاح سقوط الحروف والتشوه الإملائي للبادئات الشاذة والمغلوطة (مثل ىأصحابها -> أصحابها، ؤساء -> رؤساء، ةالأخذ -> بالأخذ).',
      category: 'تنظيف'
    },
    {
      id: 'stripDiacritics',
      title: 'حذف حركات التشكيل والضبط اللغوي',
      description: 'تجريد النص من الفتحة، الضمة، الكسرة، التنوين، الشدة، والسكون لسهولة الفرز والبحث.',
      category: 'تنظيف'
    },
    {
      id: 'stripKashida',
      title: 'إزالة مد الحروف (الكشيدة / التطويل)',
      description: 'إزالة رمز التطويل الأفقي (ـ) الذي يستعمل لمد الكلمات وجماليتها.',
      category: 'تنظيف'
    },
    {
      id: 'compressRepeatedChars',
      title: 'ضغط الأحرف المتكررة لغوياً',
      description: 'ضغط وحذف تكرار الحروف المبالغ فيه (مثل: جمييييلة -> جميلة، روووووعة -> روعة).',
      category: 'تقويم'
    },
    {
      id: 'normalizeTerminalYaa',
      title: 'توحيد الياء والألف المقصورة المتطرفة',
      description: 'تصحيح الياء المنقوطة والغير منقوطة في أواخر الكلمات (مثل فى -> في، علي -> على).',
      category: 'تقويم'
    },
    {
      id: 'normalizeAlifHamza',
      title: 'توحيد وتثبيت همزات الألف القطعية',
      description: 'معالجة همزات القطع (أ، إ، آ) وتثبيتها للكلمات الشهيرة لضبط الإملاء الصرفي.',
      category: 'تقويم'
    },
    {
      id: 'fixTeMarbuta',
      title: 'معالجة التاء المربوطة الوجوبية',
      description: 'معالجة الخلط الشائع بين الهاء والتاء المربوطة في أواخر الكلمات القيادية (مدرسه -> مدرسة).',
      category: 'تقويم'
    },
    {
      id: 'applyCustomRules',
      title: 'تطبيق قواعد العميل المخصصة',
      description: 'تطبيق التبديلات والتعليمات الإملائية اليدوية المضافة في لوحة التحكم أدناه.',
      category: 'مخصص'
    }
  ];

  return (
    <div id="rules-panel" className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm flex flex-col gap-6" dir="rtl">
      <div>
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-1">
          <Sliders className="text-emerald-600" size={18} />
          خيارات التصفية ومعالجة البيانات ديموغرافياً
        </h3>
        <p className="text-xs text-slate-500">اختر خوارزميات التصحيح والفلترة الملائمة لتهيئة نصوصك أو معاجمك وحمايتها من أخطاء الترميز.</p>
      </div>

      {/* Grid checklist of logical rule switches */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {ruleLabels.map((rule) => (
          <div
            key={rule.id}
            onClick={() => onToggleRule(rule.id)}
            className={`cursor-pointer border p-4 rounded-xl transition-all duration-150 flex items-start gap-3 select-none ${
              rules[rule.id]
                ? 'border-emerald-200 bg-emerald-50/25 shadow-sm shadow-emerald-50'
                : 'border-slate-100/90 hover:border-slate-200 bg-slate-50/20'
            }`}
          >
            <div className="pt-0.5">
              <input
                type="checkbox"
                checked={rules[rule.id]}
                onChange={() => {}} // Done via parent container click triggers
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
              />
            </div>
            
            <div className="flex-1 text-right">
              <div className="flex items-center gap-1.5 justify-start">
                <span className="text-sm font-bold text-slate-800">{rule.title}</span>
                <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded ${
                  rule.category === 'تنظيف'
                    ? 'bg-blue-50 text-blue-600 border border-blue-100'
                    : rule.category === 'تقويم'
                    ? 'bg-purple-50 text-purple-600 border border-purple-100'
                    : 'bg-indigo-50 text-indigo-600 border border-indigo-100'
                }`}>
                  {rule.category}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-normal">{rule.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* User customizable replacement patterns section */}
      <div className="border-t border-slate-100 pt-5">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            أضف قاعدة تصحيح مخصصة (Custom Vocabulary Replacement)
          </h4>
          {isSignedIn && (
            <span className="inline-flex items-center gap-1.5 text-[10px] bg-sky-50 text-sky-700 border border-sky-100 py-0.5 px-2 rounded-full font-bold">
              <Cloud size={11} className="animate-pulse" />
              مزامنة سحابية نشطة
            </span>
          )}
        </div>

        <form onSubmit={handleSubmitCustom} className="flex flex-col sm:flex-row gap-2 items-end">
          <div className="flex-1 text-right w-full">
            <label className="block text-[10px] text-slate-400 font-semibold mb-1">الكلمة المشوهة أو الخاطئة</label>
            <input
              type="text"
              required
              value={newOriginal}
              onChange={(e) => setNewOriginal(e.target.value)}
              placeholder="مثال: كتاااب"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-400 rounded-xl text-xs font-semibold"
            />
          </div>
          
          <div className="flex-1 text-right w-full">
            <label className="block text-[10px] text-slate-400 font-semibold mb-1">الكلمة البديلة المصححة</label>
            <input
              type="text"
              required
              value={newCorrected}
              onChange={(e) => setNewCorrected(e.target.value)}
              placeholder="مثال: كتاب"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-400 rounded-xl text-xs font-semibold"
            />
          </div>

          <button
            type="submit"
            className="bg-slate-900 text-white rounded-xl py-2 px-4 hover:bg-slate-800 transition-all font-semibold text-xs flex items-center gap-1 flex-shrink-0 cursor-pointer h-9 w-full sm:w-auto justify-center"
          >
            <Plus size={14} />
            إضافة قاعدة
          </button>
        </form>

        {/* Existing Custom Rules Items list */}
        {rules['applyCustomRules'] && (
          <div className="mt-4">
            {customRules.length > 0 ? (
              <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto pt-1 pr-1">
                {customRules.map((rule, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg py-1 px-2.5 text-xs text-slate-700 font-medium"
                  >
                    <span>{rule.original}</span>
                    <span className="text-slate-400">➔</span>
                    <span className="font-bold text-emerald-600">{rule.corrected}</span>
                    <button
                      type="button"
                      onClick={() => onRemoveCustomRule(idx)}
                      className="text-slate-400 hover:text-rose-500 mr-1 p-0.5 rounded transition-colors"
                      title="حذف القاعدة"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
                <HelpCircle size={13} />
                لا توجد أي قواعد مخصصة مضافة حالياً. اكتب الكلمات أعلاه لإنشائها.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
