import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  getDocFromServer, 
  setDoc, 
  addDoc, 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  deleteDoc,
  serverTimestamp 
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Authentication & Firestore
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Test connection on boot to validate setup
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration or network status.");
    }
  }
}
testConnection();

// Operations enum & error handler interface as dictated by the skill guidelines
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Authentication Helpers
export async function loginWithGoogle() {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    
    // Save/Sync User Profile safely upon first login
    const userRef = doc(db, 'users', result.user.uid);
    await setDoc(userRef, {
      userId: result.user.uid,
      displayName: result.user.displayName || 'مستخدم عربي',
      email: result.user.email || '',
      createdAt: serverTimestamp()
    }, { merge: true });
    
    return result.user;
  } catch (error) {
    console.error('Authentication Login Failed:', error);
    throw error;
  }
}

export async function logoutUser() {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Authentication Logout Failed:', error);
    throw error;
  }
}

// Firestore Database Sync CRUD Services
export interface DBCustomRule {
  id: string;
  original: string;
  corrected: string;
  createdAt: any;
}

export interface DBCorrectionHistory {
  id: string;
  inputText: string;
  cleanedText: string;
  createdAt: any;
  originalWordsCount: number;
  correctedWordsCount: number;
  changesCount: number;
}

export interface DBAnomalyAnnotation {
  id: string;
  userId: string;
  userEmail: string;
  word: string;
  note: string;
  createdAt: any;
}

// Custom Rule Actions
export async function addCustomRuleToDB(userId: string, original: string, corrected: string) {
  const path = `users/${userId}/customRules`;
  try {
    const colRef = collection(db, 'users', userId, 'customRules');
    await addDoc(colRef, {
      userId,
      original,
      corrected,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteCustomRuleFromDB(userId: string, ruleId: string) {
  const path = `users/${userId}/customRules/${ruleId}`;
  try {
    const docRef = doc(db, 'users', userId, 'customRules', ruleId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// History Actions
export async function addCorrectionHistoryToDB(
  userId: string, 
  inputText: string, 
  cleanedText: string,
  summary: { originalWordsCount: number; correctedWordsCount: number; uniqueOriginalCount?: number; uniqueCorrectedCount?: number }, 
  changesCount: number
) {
  const path = `users/${userId}/correctionHistory`;
  try {
    const colRef = collection(db, 'users', userId, 'correctionHistory');
    await addDoc(colRef, {
      userId,
      inputText,
      cleanedText,
      originalWordsCount: summary.originalWordsCount || 0,
      correctedWordsCount: summary.correctedWordsCount || 0,
      changesCount,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteHistoryFromDB(userId: string, historyId: string) {
  const path = `users/${userId}/correctionHistory/${historyId}`;
  try {
    const docRef = doc(db, 'users', userId, 'correctionHistory', historyId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Global Anomaly Annotation Actions
export async function addAnomalyAnnotationToDB(word: string, note: string) {
  const path = `anomalyAnnotations`;
  const currentUser = auth.currentUser;
  if (!currentUser) return;
  
  try {
    const colRef = collection(db, 'anomalyAnnotations');
    await addDoc(colRef, {
      userId: currentUser.uid,
      userEmail: currentUser.email || '익명',
      word,
      note,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteAnomalyAnnotationFromDB(annotationId: string) {
  const path = `anomalyAnnotations/${annotationId}`;
  try {
    const docRef = doc(db, 'anomalyAnnotations', annotationId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
