import { ANOMALY_DICTIONARY } from './data';
import { RuleConfig, CorrectionChange, AnalysisSummary } from './types';

// Regular expression to catch Arabic diacritics (Tashkeel)
const DIACRITICS_REGEX = /[\u064B-\u0652]/g;

// Regular expression for Kashida (Tatweel)
const KASHIDA_REGEX = /\u0640/g;

/**
 * Calculates vocabulary stats of a text
 */
export function getLinguisticStats(text: string) {
  if (!text.trim()) {
    return { rawCount: 0, uniqueCount: 0, words: [] };
  }
  
  // Split by spaces and punctuation (keeping only words consisting of Arabic letters, numbers, or standard letters)
  const words = text
    .split(/[\s،؛؟\.\-\:\(\)\!]+/)
    .filter(word => word.trim().length > 0);
    
  const uniqueWords = new Set(words);
  
  return {
    rawCount: words.length,
    uniqueCount: uniqueWords.size,
    words
  };
}

/**
 * Main Text Correction Engine
 */
export function processArabicCorrection(
  text: string,
  rules: Record<string, boolean>,
  customRules: { original: string; corrected: string }[] = []
): {
  cleanedText: string;
  changes: CorrectionChange[];
  summary: AnalysisSummary;
} {
  if (!text) {
    return {
      cleanedText: '',
      changes: [],
      summary: {
        originalWordsCount: 0,
        uniqueOriginalCount: 0,
        correctedWordsCount: 0,
        uniqueCorrectedCount: 0,
        cleanlinessScore: 100
      }
    };
  }

  // Calculate pre-cleanup stats
  const preStats = getLinguisticStats(text);
  
  const changes: CorrectionChange[] = [];
  let changeIdCounter = 1;
  
  // We will process the text line by line or word by word. 
  // For highly readable diffing, let's tokenize the text, but split by word boundaries while preserving whitespace,
  // or apply regex replacement while tracking matches.
  
  let currentText = text;

  // 1. Strip Diacritics (if enabled)
  if (rules['stripDiacritics']) {
    const originalLength = currentText.length;
    const stripped = currentText.replace(DIACRITICS_REGEX, '');
    const diff = originalLength - stripped.length;
    if (diff > 0) {
      changes.push({
        id: `change-${changeIdCounter++}`,
        index: 0,
        original: 'علامات التشكيل اللغوية',
        replacement: 'حذف التشكيل',
        type: 'حذف التشكيل (Tashkeel)',
        context: `تم حذف ${diff} من حركات التشكيل والحرَكات الفوقية والتحتية.`
      });
      currentText = stripped;
    }
  }

  // 2. Strip Kashida (if enabled)
  if (rules['stripKashida']) {
    const originalLength = currentText.length;
    const stripped = currentText.replace(KASHIDA_REGEX, '');
    const diff = originalLength - stripped.length;
    if (diff > 0) {
      changes.push({
        id: `change-${changeIdCounter++}`,
        index: 0,
        original: 'ـ (الكشيدة والتطويل)',
        replacement: 'حذف الكشيدة',
        type: 'إزالة مد الكلمات (Kashida)',
        context: `تمت إزالة ${diff} من علامات مد الحروف (التطويل/الكشيدة).`
      });
      currentText = stripped;
    }
  }

  // 3. Apply Custom User Mapping rules (High priority)
  if (rules['applyCustomRules'] && customRules.length > 0) {
    for (const rule of customRules) {
      if (!rule.original.trim()) continue;
      
      const escapeRegExp = (str: string) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      // Look for whole words
      const regex = new RegExp(`(?<=^|\\s)${escapeRegExp(rule.original)}(?=\\s|$|،|؛|؟|\\.|\\!)`, 'g');
      
      let matchCount = 0;
      currentText = currentText.replace(regex, (match) => {
        matchCount++;
        return rule.corrected;
      });

      if (matchCount > 0) {
         changes.push({
           id: `change-${changeIdCounter++}`,
           index: 0,
           original: rule.original,
           replacement: rule.corrected,
           type: 'تخصيص مستخدم',
           context: `تم استبدال الكلمة المخصصة "${rule.original}" بـ "${rule.corrected}" في ${matchCount} موضعًا.`
         });
      }
    }
  }

  // Split text into words to make precise word-level dictionary corrections
  // We keep whitespaces and punctuation intact so we can reconstruct the text exactly.
  // Tokenizer regex that captures words containing Arabic characters, leading 'ى', and everything else separately.
  const tokens = currentText.split(/(\s+|[،؛؟\.\-\:\(\)\!]+)/);
  
  const processedTokens = tokens.map((token, index) => {
    // If the token is whitespace or punctuation, return it directly
    if (/^(\s+|[،؛؟\.\-\:\(\)\!]+)$/.test(token) || !token.trim()) {
      return token;
    }
    
    let updatedWord = token;
    
    // A. Remove anomalous leading prefixes or fix corruptions (if enabled)
    const isAnomalousStart = ['ى', 'ؤ', 'ئ', 'ء', 'ة'].some(char => updatedWord.startsWith(char));
    if (rules['fixMaksuraPrefix'] && isAnomalousStart) {
      // Direct dictionary lookup
      if (ANOMALY_DICTIONARY[updatedWord]) {
        const correctionObj = ANOMALY_DICTIONARY[updatedWord];
        updatedWord = correctionObj.corrected;
        
        changes.push({
          id: `change-${changeIdCounter++}`,
          index: index,
          original: token,
          replacement: updatedWord,
          type: 'تصحيح البادئة الفاسدة والمعطوبة',
          context: `تصحيح الكلمة المشوهة "${token}" إلى الصحيحة "${updatedWord}" (${correctionObj.explanation})`
        });
      } else {
        // Fallback: If it's a word starting with "ى" but not in our dictionary, strip the leading "ى"
        if (token.startsWith('ى')) {
          const stripped = token.substring(1);
          if (stripped.length > 0) {
            updatedWord = stripped;
            changes.push({
              id: `change-${changeIdCounter++}`,
              index: index,
              original: token,
              replacement: updatedWord,
              type: 'تجريد البادئة الفاسدة',
              context: `الكلمة تبدأ بوصلة "ى" غير قياسية، تم تجريدها لتُصبح "${updatedWord}".`
            });
          }
        }
      }
    }

    // B. Compression of repeated characters (e.g., "أهلاً بككككك" or "راااائع" -> "رائع")
    if (rules['compressRepeatedChars']) {
      // Find occurrences where an Arabic character repeats 3 or more times
      const repeatRegex = /([\u0600-\u06FF])\1{2,}/g;
      if (repeatRegex.test(updatedWord)) {
        const originalWord = updatedWord;
        updatedWord = updatedWord.replace(/([\u0600-\u06FF])\1{2,}/g, '$1'); 
        if (originalWord !== updatedWord) {
          changes.push({
            id: `change-${changeIdCounter++}`,
            index: index,
            original: originalWord,
            replacement: updatedWord,
            type: 'ضغط الحروف المتكررة',
            context: `تم ضغط التكرار الزائد للحروف في الكلمة "${originalWord}" لتصبح "${updatedWord}".`
          });
        }
      }
    }

    // C. Standardization of terminal Yaa and Alif Maksoura (if enabled)
    if (rules['normalizeTerminalYaa']) {
      // Famous conversions like common misspelling of "علي" instead of "على", "فى" instead of "في"
      if (updatedWord === 'فى') {
        updatedWord = 'في';
        changes.push({
          id: `change-${changeIdCounter++}`,
          index: index,
          original: 'فى',
          replacement: 'في',
          type: 'توحيد الياء المتطرفة',
          context: `تصحيح حرف الجر "فى" بالياء المقصورة إلى الكلمة الصحيحة "في" بالياء المنقوطة.`
        });
      } else if (updatedWord === 'علي' && token !== 'عَلِيّ' && token !== 'علي') {
        // Note: 'علي' can be a proper name (Ali), so we use a safe heuristic: if it looks like a preposition "على" in context where Alif Maksura is preferred
        // Let's only do standard pre-defined prepositions mapping
      } else if (updatedWord.endsWith('ى') && (updatedWord === 'حتى' || updatedWord === 'على' || updatedWord === 'إلى' || updatedWord === 'بلى' || updatedWord === 'أولى')) {
        // Correct prepositions ending on Alif Maksoura. (already correct, but ensure they don't get flipped)
      } else if (updatedWord.endsWith('ى') && ['في', 'الذى', 'التى', 'الذين'].includes(updatedWord.replace('ى', 'ي'))) {
        const replacement = updatedWord.slice(0, -1) + 'ي';
        changes.push({
          id: `change-${changeIdCounter++}`,
          index: index,
          original: updatedWord,
          replacement: replacement,
          type: 'تصحيح الياء المنقوطة',
          context: `تثبيت الياء المنقوطة في نهاية الكلمة "${updatedWord}" لتصبح "${replacement}".`
        });
      }
    }

    // D. Standardization of Alif Hamzas "أ/إ/آ/ا" (if enabled)
    if (rules['normalizeAlifHamza']) {
      // Simple orthographic help: If a word starts with simple "ا" but is famously marked with "أ" or "إ"
      const prepositionsHamza: Record<string, string> = {
        'ان': 'أن',
        'انك': 'أنك',
        'انه': 'أنه',
        'انهم': 'أنهم',
        'اذا': 'إذا',
        'الى': 'إلى',
        'او': 'أو',
        'ام': 'أم',
        'اي': 'أي',
        'اين': 'أين',
        'الا': 'ألا',
        'إلا': 'إلا', // keep original
        'الاء': 'آلاء',
        'اان': 'أأن',
        'اكثر': 'أكثر',
        'اهم': 'أهم',
        'اول': 'أول',
        'اعتقد': 'أعتقد',
        'اريد': 'أريد',
        'اكبر': 'أكبر',
        'اصعب': 'أصعب',
        'افضل': 'أفضل'
      };
      
      if (prepositionsHamza[updatedWord]) {
        const correctedHamza = prepositionsHamza[updatedWord];
        changes.push({
          id: `change-${changeIdCounter++}`,
          index: index,
          original: updatedWord,
          replacement: correctedHamza,
          type: 'تصحيح همزة القطع',
          context: `تثبيت همزة القطع الصحيحة لكلمة "${updatedWord}" لتصبح "${correctedHamza}".`
        });
        updatedWord = correctedHamza;
      }
    }

    // E. Fix terminal Te Marbuta vs Haa (if enabled)
    if (rules['fixTeMarbuta']) {
      // Heuristic auto-fixes for highly common spelling issues in general words
      const targetFixes: Record<string, string> = {
        'مدرسه': 'مدرسة',
        'مكتبه': 'مكتبة',
        'جميله': 'جميلة',
        'كبيره': 'كبيرة',
        'صغيره': 'صغيرة',
        'قويه': 'قوية',
        'امراة': 'امرأة',
        'فتره': 'فترة',
        'مدينه': 'مدينة',
        'قريه': 'قرية',
        'لغه': 'لغة',
        'ثقافه': 'ثقافة',
        'جامعه': 'جامعة',
        'حياه': 'حياة'
      };
      
      if (targetFixes[updatedWord]) {
        const replacement = targetFixes[updatedWord];
        changes.push({
          id: `change-${changeIdCounter++}`,
          index: index,
          original: updatedWord,
          replacement: replacement,
          type: 'إصلاح التاء المربوطة',
          context: `ترجيح التاء المربوطة "ة" في نهاية كلمة "${updatedWord}" لتصبح "${replacement}".`
        });
        updatedWord = replacement;
      }
    }

    return updatedWord;
  });

  const cleanedText = processedTokens.join('');
  const postStats = getLinguisticStats(cleanedText);

  // Cleanliness Score Estimation:
  // Starts at 100%, subtracts a small penalty for each change relative to total words, 
  // and anomalous words are heavily weighted.
  const wordsCount = preStats.rawCount || 1;
  const uniqueChangesCount = changes.filter(c => c.type.includes('الفاسدة') || c.type.includes('تجريد')).length;
  const factor = (uniqueChangesCount / wordsCount) * 100;
  const cleanlinessScore = Math.max(0, Math.min(100, Math.round(100 - factor)));

  return {
    cleanedText,
    changes,
    summary: {
      originalWordsCount: preStats.rawCount,
      uniqueOriginalCount: preStats.uniqueCount,
      correctedWordsCount: postStats.rawCount,
      uniqueCorrectedCount: postStats.uniqueCount,
      cleanlinessScore
    }
  };
}
