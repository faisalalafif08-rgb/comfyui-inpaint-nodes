import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { INITIAL_LETTER_STATS, SPECIMEN_ARABIC_TEXT, ANOMALY_DICTIONARY } from './data';
import { processArabicCorrection } from './utils';
import { RuleConfig, CorrectionChange, AnalysisSummary } from './types';

// Firebase imports
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { 
  auth, 
  db, 
  loginWithGoogle, 
  logoutUser, 
  addCustomRuleToDB, 
  deleteCustomRuleFromDB, 
  addCorrectionHistoryToDB, 
  deleteHistoryFromDB, 
  addAnomalyAnnotationToDB, 
  deleteAnomalyAnnotationFromDB 
} from './lib/firebase';

// Importing subcomponents
import LetterCard from './components/LetterCard';
import AnomalyInspector from './components/AnomalyInspector';
import RulesPanel from './components/RulesPanel';
import StatsDashboard from './components/StatsDashboard';
import DBManagerPanel from './components/DBManagerPanel';
import EvaluationPanel from './components/EvaluationPanel';
import SQLiteEngine from './components/SQLiteEngine';

// Lucide Icons
import { 
  Sparkles, 
  Database, 
  FileText, 
  CheckCircle, 
  Clipboard, 
  Download, 
  RotateCcw, 
  BookOpen, 
  AlertTriangle,
  ChevronLeft,
  Settings,
  Flame,
  Check,
  Cloud,
  LogIn,
  LogOut,
  Trash2,
  History,
  AlertCircle,
  Volume2,
  VolumeX,
  Terminal
} from 'lucide-react';

export default function App() {
  // Navigation active tab State
  const [activeTab, setActiveTab] = useState<'correction' | 'explorer' | 'about' | 'db_manager' | 'evaluation' | 'sql_engine'>('correction');
  
  // Selected letter for the details view in the explorer tab
  const [selectedLetter, setSelectedLetter] = useState<string>('ى');

  // Interactive Text Inputs / Outputs State
  const [inputText, setInputText] = useState<string>('');
  const [copiedSuccess, setCopiedSuccess] = useState<boolean>(false);
  const [historySavedSuccess, setHistorySavedSuccess] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  
  // Firebase Auth and DB States
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [dbHistory, setDbHistory] = useState<any[]>([]);
  const [dbAnnotations, setDbAnnotations] = useState<any[]>([]);

  // Default validation rules configuration state
  const [rules, setRules] = useState<Record<string, boolean>>({
    fixMaksuraPrefix: true,
    stripDiacritics: false,
    stripKashida: false,
    compressRepeatedChars: true,
    normalizeTerminalYaa: true,
    normalizeAlifHamza: true,
    fixTeMarbuta: true,
    applyCustomRules: true,
  });

  // User's custom correction dictionaries
  const [customRules, setCustomRules] = useState<{ id?: string; original: string; corrected: string }[]>([
    { original: 'كتاااب', corrected: 'كتاب' },
    { original: 'مدرسه', corrected: 'مدرسة' }
  ]);

  // Auth Observer useEffect
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Sync custom rules from Firestore dynamically
  useEffect(() => {
    if (!user) {
      // Unsigned state reset to local defaults
      setCustomRules([
        { original: 'كتاااب', corrected: 'كتاب' },
        { original: 'مدرسه', corrected: 'مدرسة' }
      ]);
      return;
    }

    const colRef = collection(db, 'users', user.uid, 'customRules');
    const q = query(colRef, orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const rulesData = snapshot.docs.map(doc => ({
        id: doc.id,
        original: doc.data().original || '',
        corrected: doc.data().corrected || ''
      }));
      setCustomRules(rulesData);
    }, (error) => {
      console.error("Rules Firestore sync failed: ", error);
    });

    return () => unsubscribe();
  }, [user]);

  // Sync correction history from Firestore dynamically
  useEffect(() => {
    if (!user) {
      setDbHistory([]);
      return;
    }

    const colRef = collection(db, 'users', user.uid, 'correctionHistory');
    const q = query(colRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const historyData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setDbHistory(historyData);
    }, (error) => {
      console.error("History Firestore sync failed: ", error);
    });

    return () => unsubscribe();
  }, [user]);

  // Sync collaborative annotations globally from Firestore
  useEffect(() => {
    if (!user) {
      setDbAnnotations([]);
      return;
    }

    const colRef = collection(db, 'anomalyAnnotations');
    const q = query(colRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const annotationsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setDbAnnotations(annotationsData);
    }, (error) => {
      console.error("Annotations Firestore sync failed: ", error);
    });

    return () => unsubscribe();
  }, [user]);

  // Execute Correction Real-time or triggered
  const { cleanedText, changes, summary } = processArabicCorrection(inputText, rules, customRules);

  const handleToggleRule = (ruleId: string) => {
    setRules(prev => ({ ...prev, [ruleId]: !prev[ruleId] }));
  };

  const handleAddCustomRule = async (original: string, corrected: string) => {
    if (user) {
      try {
        await addCustomRuleToDB(user.uid, original, corrected);
      } catch (err) {
        console.error('Failed to add custom rule to DB:', err);
      }
    } else {
      setCustomRules(prev => [...prev, { original, corrected }]);
    }
  };

  const handleRemoveCustomRule = async (index: number) => {
    if (user) {
      const targetRule = customRules[index];
      if (targetRule && targetRule.id) {
        try {
          await deleteCustomRuleFromDB(user.uid, targetRule.id);
        } catch (err) {
          console.error('Failed to delete custom rule:', err);
        }
      }
    } else {
      setCustomRules(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleLogIn = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error('Failed to login:', err);
    }
  };

  const handleLogOut = async () => {
    try {
      await logoutUser();
    } catch (err) {
      console.error('Failed to logout:', err);
    }
  };

  const handleSaveToCloudHistory = async () => {
    if (!user || !inputText.trim() || !cleanedText) return;
    try {
      await addCorrectionHistoryToDB(user.uid, inputText, cleanedText, summary, changes.length);
      setHistorySavedSuccess(true);
      setTimeout(() => setHistorySavedSuccess(false), 2000);
    } catch (err) {
      console.error('Failed to save correction to history:', err);
    }
  };

  const handleLoadHistoryItem = (savedInputText: string) => {
    setInputText(savedInputText);
    setActiveTab('correction');
  };

  const handleDeleteHistoryItem = async (historyId: string) => {
    if (!user) return;
    try {
      await deleteHistoryFromDB(user.uid, historyId);
    } catch (err) {
      console.error('Failed to delete history item:', err);
    }
  };

  const handleAddAnnotation = async (word: string, note: string) => {
    try {
      await addAnomalyAnnotationToDB(word, note);
    } catch (err) {
      console.error('Failed to add annotation note:', err);
    }
  };

  const handleDeleteAnnotation = async (annotationId: string) => {
    try {
      await deleteAnomalyAnnotationFromDB(annotationId);
    } catch (err) {
      console.error('Failed to delete annotation note:', err);
    }
  };

  const handleLoadSpecimenText = () => {
    setInputText(SPECIMEN_ARABIC_TEXT);
  };

  const handleClearText = () => {
    setInputText('');
  };

  const handleCopyText = () => {
    if (!cleanedText) return;
    navigator.clipboard.writeText(cleanedText);
    setCopiedSuccess(true);
    setTimeout(() => setCopiedSuccess(false), 2000);
  };

  const handleDownloadText = () => {
    if (!cleanedText) return;
    const blob = new Blob([cleanedText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cleaned_arabic_data.txt';
    link.click();
    URL.revokeObjectURL(url);
  };

  // Cancel speech synthesis if the cleaned text changes
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window && isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [cleanedText]);

  // Cancel speech synthesis on component unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleToggleSpeech = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    if (!cleanedText.trim()) return;

    const utterance = new SpeechSynthesisUtterance(cleanedText);
    utterance.lang = 'ar-SA';

    // Locate Arabic synthesizer voices if available
    const voices = window.speechSynthesis.getVoices();
    const arabicVoice = voices.find(voice => voice.lang.startsWith('ar'));
    if (arabicVoice) {
      utterance.voice = arabicVoice;
    }

    utterance.onend = () => {
      setIsSpeaking(false);
    };

    utterance.onerror = (e) => {
      console.error('Speech synthesis error:', e);
      setIsSpeaking(false);
    };

    // Reset synthesis queue to speak immediately
    window.speechSynthesis.cancel();
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleInsertWordFromAnomalyTracker = (word: string) => {
    // Appends the chosen anomalous word to the text editor
    setInputText(prev => {
      const spacing = prev.trim() ? ' ' : '';
      return prev + spacing + word;
    });
    // Switch to workspace automatically
    setActiveTab('correction');
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 font-sans p-4 md:p-8 selection:bg-emerald-100 selection:text-emerald-900" dir="rtl">
      
      {/* Outer elegant container */}
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* TOP BRAND BRANDING & NAVIGATION HEADER */}
        <header className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-slate-200/80 pb-6 gap-4">
          
          <div className="text-right">
            <div className="flex items-center gap-2 mb-1 justify-start">
              <span className="p-2 bg-emerald-500 rounded-xl text-white shadow-sm shadow-emerald-200">
                <Database size={22} className="animate-pulse" />
              </span>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight font-sans">
                مُصَحِّحُ البَيَانَاتِ العَرَبِيِّ
              </h1>
              <span className="text-[10px] bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full text-slate-500 font-bold">
                نسخة 2.5
              </span>
            </div>
            
            <p className="text-xs text-slate-500 max-w-xl leading-relaxed">
              أداة علمية متطورة لتنفيذ التدقيق والتحليلات العلوية للمفردات وقوانين القواميس اللغوية العربية، مصممة لمعالجة بادئات الياء المقصورة الفاسدة والخلط الإملائي في الملفات الضخمة مثل <code className="bg-slate-100 text-rose-600 px-1 py-0.5 rounded font-mono text-xs">ar.txt</code>.
            </p>
          </div>

          {/* Dynamic Tab Controllers & Auth Block */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Google Authentication Section */}
            <div className="flex items-center gap-2 flex-shrink-0">
              {authLoading ? (
                <div className="w-5 h-5 border-2 border-slate-300 border-t-emerald-500 rounded-full animate-spin"></div>
              ) : user ? (
                <div className="flex items-center gap-2 bg-slate-100 border border-slate-200 p-1.5 pr-3 rounded-xl shadow-xs">
                  {user.photoURL ? (
                    <img 
                      src={user.photoURL} 
                      alt={user.displayName || 'مُحقّق'} 
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-lg border border-white object-cover" 
                    />
                  ) : (
                    <div className="w-7 h-7 bg-emerald-500 text-white rounded-lg flex items-center justify-center font-bold text-xs border border-white">
                      {user.displayName ? user.displayName.charAt(0) : 'م'}
                    </div>
                  )}
                  <div className="text-right hidden sm:block">
                    <p className="text-[10px] font-black leading-none text-slate-800">{user.displayName || 'باحث لغوي معتمد'}</p>
                    <p className="text-[8px] text-slate-400 mt-0.5">{user.email}</p>
                  </div>
                  <button
                    onClick={handleLogOut}
                    className="p-1 px-2.5 bg-white hover:bg-rose-50 border border-rose-100/50 hover:border-rose-100 text-rose-600 hover:text-rose-700 font-bold text-[10px] rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                    title="تسجيل الخروج"
                  >
                    <LogOut size={11} />
                    خروج
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleLogIn}
                  className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer border border-slate-850"
                  title="سجل دخولك لتفعيل المزامنة السحابية الفورية"
                >
                  <LogIn size={13} />
                  تسجيل الدخول سحابياً
                </button>
              )}
            </div>

            {/* In-app navigation links */}
            <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 flex-shrink-0">
              <button
                onClick={() => setActiveTab('correction')}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'correction'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <Sparkles size={14} className={activeTab === 'correction' ? 'text-emerald-500' : ''} />
                غرفة تصحيح النصوص
              </button>
              
              <button
                onClick={() => setActiveTab('explorer')}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'explorer'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <Database size={14} className={activeTab === 'explorer' ? 'text-emerald-500' : ''} />
                مستكشف الإحصائيات (ar.txt)
              </button>

              <button
                onClick={() => setActiveTab('about')}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'about'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <BookOpen size={14} />
                قواعد التدقيق
              </button>

              <button
                onClick={() => setActiveTab('db_manager')}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'db_manager'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <Database size={14} className={activeTab === 'db_manager' ? 'text-emerald-500' : ''} />
                إدارة الحروف (Excel & SQLite)
              </button>

              <button
                onClick={() => setActiveTab('sql_engine')}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'sql_engine'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <Terminal size={14} className={activeTab === 'sql_engine' ? 'text-indigo-500' : ''} />
                محرك SQL الموحد
              </button>

              <button
                onClick={() => setActiveTab('evaluation')}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'evaluation'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <Flame size={14} className={activeTab === 'evaluation' ? 'text-orange-500' : 'text-slate-400'} />
                قياس الأداء والتطور (19 ملفاً)
              </button>
            </div>
          </div>
        </header>

        {/* TAB 1: INTERACTIVE CLEANING WORKGROUND & PLAYPENS */}
        {activeTab === 'correction' && (
          <div className="space-y-6">
            
            {/* IN-APP REAL-TIME METRICS FOR EDITS */}
            {inputText.trim() && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
              >
                <StatsDashboard summary={summary} totalChanges={changes.length} />
              </motion.div>
            )}

            {/* MAIN EDITORS STAGE */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* LEFT / CENTRAL STAGE (Inputs / Outputs) */}
              <div className="lg:col-span-2 space-y-6">
                
                {/* Visual Editing Frame */}
                <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <h2 className="text-base font-bold text-slate-900">محرر تنظيف وفحص الكلمات المعجمية</h2>
                    </div>
                    
                    <div className="flex gap-1.5">
                      <button
                        onClick={handleLoadSpecimenText}
                        className="text-[11px] font-bold text-amber-600 bg-amber-50 hover:bg-amber-100 border border-amber-200 py-1.5 px-3 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <FileText size={12} />
                        تحميل نص تجريبي (بأخطاء الـ 31 كلمة)
                      </button>
                      
                      {inputText && (
                        <button
                          onClick={handleClearText}
                          className="text-[11px] font-bold text-slate-500 bg-slate-50 hover:bg-slate-100 border border-slate-200 py-1.5 px-3 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw size={12} />
                          إفراغ المحرر
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Dual Grid View for Original input and Cleaned output if text is present */}
                  <div className={`grid grid-cols-1 ${inputText.trim() ? 'md:grid-cols-2' : ''} gap-4`}>
                    
                    {/* INPUT SIDE */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">بيانات النص الخام الأصلي (Original Input)</label>
                      <textarea
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="الصق هنا الكلمات المعطوبة، أو نصوص المعاجم والقواميس، أو الجمل الإملائية بترميز غير قياسي لبدء التنظيف والتحقق..."
                        dir="rtl"
                        className="w-full h-80 p-4 border border-slate-200/90 rounded-2xl bg-slate-50/20 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-sans text-sm leading-relaxed text-slate-800"
                      />
                    </div>

                    {/* OUTPUT SIDE (Displays Real-time results) */}
                    {inputText.trim() && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex flex-col gap-1"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <label className="text-[11px] font-bold text-emerald-600 block">مخرجات البيانات الطاهرة المصححة (Cleaned Output)</label>
                            <div className="flex items-center gap-1">
                              <span className="inline-flex items-center text-[10px] bg-emerald-100/70 text-emerald-800 font-bold px-1.5 py-0.5 rounded-md border border-emerald-200/50">
                                {cleanedText.trim() ? cleanedText.trim().split(/\s+/).length : 0} كلمة
                              </span>
                              <span className="inline-flex items-center text-[10px] bg-slate-150/80 text-slate-705 font-bold px-1.5 py-0.5 rounded-md border border-slate-200">
                                {cleanedText.length} حرف
                              </span>
                              <span className="inline-flex items-center text-[10px] bg-slate-150/80 text-slate-705 font-bold px-1.5 py-0.5 rounded-md border border-slate-200 font-mono">
                                {cleanedText ? cleanedText.split('\n').length : 0} سطر
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-1 flex-wrap">
                            {user ? (
                              <button
                                onClick={handleSaveToCloudHistory}
                                className={`text-[10px] font-bold border py-1 px-2.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                                  historySavedSuccess
                                    ? 'bg-sky-50 border-sky-200 text-sky-700 animate-pulse'
                                    : 'bg-emerald-600 text-white hover:bg-emerald-550 border-transparent shadow-sm'
                                }`}
                                title="احفظ التعديلات في أرشيف السحاب الآمن الخاص بك"
                              >
                                {historySavedSuccess ? <Check size={11} className="text-sky-500" /> : <Cloud size={11} />}
                                {historySavedSuccess ? 'تم الحفظ!' : 'حفظ بسجل السحاب'}
                              </button>
                            ) : (
                              <button
                                onClick={handleLogIn}
                                className="text-[10px] font-bold bg-slate-100 hover:bg-slate-250 border border-slate-200 text-slate-500 py-1 px-2.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                                title="سجل دخولك لأرشفة وتخزين نصوصك سحابياً"
                              >
                                <Cloud size={11} className="text-slate-400" />
                                أرشفة السحاب (دخول)
                              </button>
                            )}
                            
                            <button
                              onClick={handleCopyText}
                              className={`text-[10px] font-bold border py-1 px-2.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                                copiedSuccess
                                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                                  : 'bg-white border-slate-202 text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              {copiedSuccess ? <Check size={11} className="text-emerald-500" /> : <Clipboard size={11} />}
                              {copiedSuccess ? 'تم النسخ!' : 'نسخ النص'}
                            </button>
                            
                            <button
                              onClick={handleToggleSpeech}
                              className={`text-[10px] font-bold border py-1 px-2.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                                isSpeaking
                                  ? 'bg-rose-50 border-rose-200 text-rose-700 animate-pulse'
                                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600'
                              }`}
                              title={isSpeaking ? 'إيقاف نطق النص اللغوي' : 'استمع للنص المصحّح ونطقه باللغة العربية الفصحى'}
                            >
                              {isSpeaking ? <VolumeX size={11} className="text-rose-500" /> : <Volume2 size={11} />}
                              {isSpeaking ? 'إيقاف القراءة' : 'قراءة النص'}
                            </button>

                            <button
                              onClick={handleDownloadText}
                              className="text-[10px] font-bold bg-white border border-slate-205 hover:bg-slate-50 text-slate-600 py-1 px-2.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <Download size={11} />
                              تحميل ملف (.txt)
                            </button>
                          </div>
                        </div>
                        
                        <div
                          dir="rtl"
                          className="w-full h-80 p-4 border border-emerald-200 rounded-2xl bg-emerald-50/10 font-sans text-sm leading-relaxed text-slate-800 overflow-y-auto whitespace-pre-wrap select-text"
                        >
                          {cleanedText}
                        </div>
                      </motion.div>
                    )}

                  </div>
                </div>

                {/* CORRECTION LOG & STEP ACTIONS (Interactive list of corrections made) */}
                {inputText.trim() && changes.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm"
                  >
                    <div className="flex items-center gap-2 border-b border-slate-100 pb-3 mb-4">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                      <h3 className="text-sm font-bold text-slate-900">سجل التغييرات والمعالجات اللغوية المنفذة ({changes.length})</h3>
                    </div>

                    <div className="max-h-60 overflow-y-auto space-y-2.5 pr-1">
                      {changes.map((change) => (
                        <div
                          key={change.id}
                          className="flex items-start justify-between p-3 rounded-xl bg-slate-50 border border-slate-100/90 text-right gap-4 text-xs"
                        >
                          <div className="space-y-1 select-text">
                            <p className="font-semibold text-slate-800 flex items-center gap-2">
                              <span>استبدال المفرط:</span>
                              <span className="text-sm font-bold text-rose-600 font-mono bg-rose-50 border border-rose-100 rounded px-1.5 py-0.5">
                                {change.original}
                              </span>
                              <span>➔</span>
                              <span className="text-sm font-bold text-emerald-600 font-mono bg-emerald-50 border border-emerald-100 rounded px-1.5 py-0.5">
                                {change.replacement}
                              </span>
                            </p>
                            <p className="text-[11px] text-slate-500 leading-normal">{change.context}</p>
                          </div>
                          
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 flex-shrink-0">
                            {change.type}
                          </span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* CLOUD ARCHIVED HISTORICAL RECORDS CARD */}
                {user && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4"
                  >
                    <div className="flex items-center justify-between border-b border-slate-150 pb-3 flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="p-1 px-2.5 bg-sky-50 text-sky-700 border border-sky-100 rounded-lg text-xs font-bold flex items-center gap-1">
                          <Cloud size={12} className="animate-pulse" />
                          أرشيف السحاب الآمن
                        </span>
                        <h3 className="text-sm font-bold text-slate-900">سجل عمليات التدقيق والمراجعات السابقة ({dbHistory.length})</h3>
                      </div>
                      
                      <span className="text-[10px] text-slate-400 font-bold">مربوط بحساب {user.email}</span>
                    </div>

                    {dbHistory.length > 0 ? (
                      <div className="max-h-60 overflow-y-auto space-y-2.5 pr-1">
                        {dbHistory.map((item) => {
                          const originalPreview = item.inputText && item.inputText.length > 80 
                            ? item.inputText.substring(0, 80) + '...'
                            : item.inputText || '';
                          
                          // Format timestamp helper
                          let timeStr = 'سجل غير مؤرخ';
                          if (item.createdAt) {
                            try {
                              const date = item.createdAt.seconds 
                                ? new Date(item.createdAt.seconds * 1000) 
                                : new Date(item.createdAt);
                              timeStr = date.toLocaleString('ar-EG', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
                            } catch (e) {
                              timeStr = 'سجل محفوظ';
                            }
                          }

                          return (
                            <div
                              key={item.id}
                              className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 rounded-xl bg-slate-50 hover:bg-slate-100/55 border border-slate-100/90 text-right gap-3 text-xs transition-all"
                            >
                              <div className="space-y-1 select-text flex-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[10px] font-bold text-slate-400">{timeStr}</span>
                                  <div className="h-2.5 w-[1px] bg-slate-200 sm:block hidden"></div>
                                  <span className="bg-emerald-50 text-emerald-700 border border-emerald-100/70 text-[10px] py-0.5 px-2 rounded-full font-bold">
                                    تعديلات: {item.changesCount || 0}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-600 font-medium whitespace-pre-wrap leading-relaxed">
                                  {originalPreview}
                                </p>
                              </div>
                              
                              <div className="flex items-center gap-1.5 self-end sm:self-center flex-shrink-0">
                                <button
                                  onClick={() => handleLoadHistoryItem(item.inputText)}
                                  className="text-[10px] font-bold text-indigo-650 hover:text-white bg-indigo-50 hover:bg-indigo-600 border border-indigo-150 py-1 px-2.5 rounded-lg transition-all cursor-pointer"
                                  title="تحميل النص بأكمله إلى لوحة التحرير"
                                >
                                  تحميل للمحرر
                                </button>
                                <button
                                  onClick={() => handleDeleteHistoryItem(item.id)}
                                  className="text-slate-400 hover:text-rose-600 hover:bg-rose-50 p-1.5 border border-transparent hover:border-rose-100/50 rounded-lg transition-all cursor-pointer"
                                  title="حذف هذا السجل نهائياً من السحاب"
                                >
                                  <Trash2 size={12} />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="bg-slate-50/50 border border-slate-100 rounded-xl p-6 text-center text-[11px] text-slate-400 flex flex-col items-center justify-center gap-2">
                        <History size={24} className="text-slate-350 animate-bounce" />
                        <p className="font-bold">سجل الأرشيف نظيف وفارغ.</p>
                        <p className="text-[10px] text-slate-400">عند التدقيق، اضغط على زر "حفظ بسجل السحاب" بالأعلى لتتم أرشفة النص وربطه بحسابك بشكل فوري دائم.</p>
                      </div>
                    )}
                  </motion.div>
                )}

              </div>

              {/* RIGHT STAGE (Rules Configs & Fast diagnostics) */}
              <div className="space-y-6">
                
                {/* Active settings switches panel */}
                <RulesPanel
                  rules={rules}
                  onToggleRule={handleToggleRule}
                  customRules={customRules}
                  onAddCustomRule={handleAddCustomRule}
                  onRemoveCustomRule={handleRemoveCustomRule}
                  isSignedIn={!!user}
                />

                {/* Live alerts banner */}
                <div className="bg-emerald-50/60 border border-emerald-100 rounded-2xl p-5 text-right space-y-3">
                  <h4 className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                    <Sparkles size={14} className="text-emerald-600" />
                    تحسين الإنتاجية والتصدير
                  </h4>
                  <p className="text-[11px] text-emerald-950 leading-relaxed font-medium">
                    جميع مرشحات التنظيف تجري بصورة محلية بالكامل فائقة السرعة. يمكنك لصق جداول القواميس الضخمة وإتاحة معالجة فورية وتوريد سليم تماماً خلال جزء من الثانية.
                  </p>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* TAB 2: GENERAL DICTIONARY CORPUS METRICS (ar.txt Analysis) */}
        {activeTab === 'explorer' && (
          <div className="space-y-6 md:p-1">
            
            {/* Quick Overview warning on ar.txt statistics */}
            <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1.5 z-10 text-right">
                <span className="inline-flex items-center gap-1 text-[11px] font-bold tracking-wider px-2 py-0.5 roundedbg bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase">
                  تنبيه تشوه الترميز
                </span>
                <h2 className="text-xl font-black font-sans leading-tight">
                  نظام التصفية وحقائق الحروف لملف الكلمات ar.txt
                </h2>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  يتضمن المعجم الإحصائي حرف <code className="bg-slate-800 text-rose-300 px-1 py-0.5 font-mono text-xs rounded">ى</code> بـ <strong className="text-rose-300">31 كلمة خام</strong>، بينما يضم الحرف المقارب <code className="bg-slate-800 text-emerald-300 px-1 py-0.5 font-mono text-xs rounded">ي</code> أكثر من <strong className="text-emerald-300">52,348 كلمة</strong>! يعود سبب تواجد الـ 31 كلمة لخلل لصق البادئة في بداية المفردات العربية.
                </p>
              </div>
              <div className="p-3 bg-white/10 rounded-xl border border-white/10 text-xs font-mono font-bold tracking-wider text-rose-300 flex-shrink-0 animate-pulse">
                ى-31 شائبة متناهية
              </div>
            </div>

            {/* Interactive Letters Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800">اضغط على أي حرف لعرض تفاصيله ومعاينة الكلمات القياسية:</h3>
                <span className="text-[10px] text-slate-400 font-semibold">المجموع: {INITIAL_LETTER_STATS.length} حرفاً مسجلاً</span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {INITIAL_LETTER_STATS.map((stats) => (
                  <LetterCard
                    key={stats.letter}
                    stats={stats}
                    isSelected={selectedLetter === stats.letter}
                    onSelect={() => setSelectedLetter(stats.letter)}
                  />
                ))}
              </div>
            </div>

            {/* LETTER PROFILE DETAIL & ANOMALIES INSPECTOR */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Detailed profile viewer */}
              <div className="bg-white border border-slate-205 rounded-2xl p-6 shadow-sm flex flex-col justify-between lg:col-span-1" dir="rtl">
                {(() => {
                  const letterProfile = INITIAL_LETTER_STATS.find(l => l.letter === selectedLetter) || INITIAL_LETTER_STATS[0];
                  return (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <span className="text-4xl font-extrabold text-slate-900 font-sans">« {letterProfile.letter} »</span>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                          letterProfile.isAnomalous ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
                        }`}>
                          {letterProfile.isAnomalous ? 'تحليل العيوب اللغوية' : 'بيانات إملائية قياسية'}
                        </span>
                      </div>

                      <div className="space-y-3 text-right">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-semibold">إجمالي الكلمات المتأصلة (الخام)</span>
                          <span className="text-lg font-extrabold text-slate-800 font-mono">
                            {letterProfile.rawCount.toLocaleString('ar-EG')}
                          </span>
                        </div>
                        
                        <div>
                          <span className="text-[10px] text-slate-400 block font-semibold">الكلمات الفريدة الإجمالية</span>
                          <span className="text-lg font-extrabold text-slate-800 font-mono">
                            {letterProfile.uniqueCount.toLocaleString('ar-EG')}
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 block font-semibold">معيار الإحصاء في الملف ar.txt</span>
                          <p className="text-xs text-slate-600 bg-slate-50 border border-slate-100 p-2.5 rounded-xl font-medium leading-relaxed leading-normal mt-1">
                            {letterProfile.rule}
                          </p>
                        </div>

                        {letterProfile.isAnomalous && (
                          <div className="p-3.5 bg-rose-50 border border-rose-100 rounded-xl text-rose-950 space-y-1">
                            <span className="text-xs font-bold block text-rose-700">دواعي الشذوذ والفساد الإملائي:</span>
                            <small className="text-[11px] leading-relaxed block leading-normal">{letterProfile.anomalyDetails}</small>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Comprehensive List of 31 anomalous Words (AnomalyInspector component) */}
              <div className="lg:col-span-2">
                <AnomalyInspector 
                  onInsertWord={handleInsertWordFromAnomalyTracker} 
                  currentUser={user}
                  annotations={dbAnnotations}
                  onAddAnnotation={handleAddAnnotation}
                  onDeleteAnnotation={handleDeleteAnnotation}
                />
              </div>

            </div>

          </div>
        )}

        {/* TAB 3: GRAMMATICAL RULES & TUTORIAL SECTION */}
        {activeTab === 'about' && (
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 md:p-8 shadow-sm space-y-6" dir="rtl">
            <div className="border-b border-slate-100 pb-4 text-right">
              <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
                <BookOpen size={20} className="text-emerald-600" />
                الدليل اللغوي لمعايير وتنقية قواعد البيانات العربية
              </h2>
              <p className="text-xs text-slate-500 mt-1">توجيهات فنيّة حول كيفية تنظيف نصوص المدونات العربية والمعاجم الإلكترونية.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-right">
              
              <div className="space-y-3.5 p-5 bg-slate-50 border border-slate-100/90 rounded-2xl relative">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest block">القاعدة الأولى</span>
                <h3 className="text-base font-bold text-slate-900">علاقة الهمزة ببدء الكلمة والمخرجات</h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  الهمزة في لغة العرب لا غنى لها عن كرسي الياء أو الواو أو الألف بحسب تشكيلها الإعرابي والتركيبي. يُستحب تتبُّع المخرجات المبتدئة بهمزة قطع فاشلة مثل "اكثر" أو "اهم" وتصحيحها لتصبح "أكثر" و"أهم" لمنع التداخل الإملائي مع كلمات أخرى غائبة أو مكسورة الهمزة مثل "إهمال".
                </p>
              </div>

              <div className="space-y-3.5 p-5 bg-slate-50 border border-slate-100/90 rounded-2xl">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest block">القاعدة الثانية</span>
                <h3 className="text-base font-bold text-slate-900">سر شذوذ حرف الألف المقصورة (ى)</h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  علم الصوتيات والخط العربي يُجمع على أن "الياء المقصورة" لا تكون عُرضة للنطق أو الابتداء مفرداً في بداية الكلمة لأنها تُمثل صوتاً ممدوداً يشبه الألف الطائرة، وصوت الألف الممدود لا يفتتح العرب به ألفاظهم إلا مسبوقاً بهمزة أو واصل. لذا فإن الألفاظ الـ 31 الفاسدة في معجم ar.txt تستجوب استبدالها بصورة فورية.
                </p>
              </div>

              <div className="space-y-3.5 p-5 bg-slate-50 border border-slate-100/90 rounded-2xl">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest block">القاعدة الثالثة</span>
                <h3 className="text-base font-bold text-slate-900">تشويه التطويل والتحوير البصري (الكشيدة)</h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  يستخدم الرمز (ـ - Kashida) بكثرة في المجموعات العربية الحرة بغرض ضبط التسطير والجاذبية في المطابع ومطوري البرامج. لكنه يحول بين خوارزميات البحث وتطابق المدخلات ومحركات البحث ويعد عبئاً في تحليل البيانات يستوجب التجريد.
                </p>
              </div>

              <div className="space-y-3.5 p-5 bg-slate-50 border border-slate-100/90 rounded-2xl">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest block">القاعدة الرابعة</span>
                <h3 className="text-base font-bold text-slate-900">توحيد الترميز القياسي للياء والهاء المتطرفة</h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  نتيجة للسرعة في الكتابة أو تنوع لوحات المفاتيح في الهواتف، يتكرر استبدال الياء المنقوطة "ي" بالألف المقصورة "ى" والعكس في حروف الجر مثل "في / فى" وحروف التقويم، إضافة للخلط بين ثنائيات الهاء "ه" والتاء المربوطة "ة". نقوم بتسوية هذه الهياكل لتقوية محتوى السيرفرات وجودة الاستبيان المعجمي.
                </p>
              </div>

            </div>

            <div className="bg-emerald-50 border border-emerald-100 p-5 rounded-2xl text-center space-y-2">
              <p className="text-xs font-bold text-emerald-800">تحقق دائماً من تطبيق المعايير لرفع جودة وكفاءة المعالجة الطبيعية اللغوية (NLP)</p>
              <button
                onClick={() => setActiveTab('correction')}
                className="inline-flex items-center gap-1 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 py-1.5 px-4 rounded-xl transition-all cursor-pointer shadow-sm"
              >
                شغل منصة التصحيح الآن
                <ChevronLeft size={14} />
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: SQLITE & EXCEL SEED DATABASE MANAGER */}
        {activeTab === 'db_manager' && (
          <DBManagerPanel />
        )}

        {/* TAB 5: UNIFIED SQL ENGINE ENGINE */}
        {activeTab === 'sql_engine' && (
          <SQLiteEngine />
        )}

        {/* TAB 6: MULTI-LANGUAGE PERFORMANCE & EVALUATION TOOL */}
        {activeTab === 'evaluation' && (
          <EvaluationPanel />
        )}

        {/* COMPREHENSIVE REFINED SLATE FOOTER */}
        <footer className="text-center py-6 border-t border-slate-200 mt-12 text-[11px] text-slate-400 font-medium">
          <p>مُصَفِّي وبوابة معالجة المعاجم والنصوص العربية (ar.txt) | مُقدَّم كبيانات متطابقة دقيقة لخدمة معالجات الذكاء الاصطناعي</p>
          <p className="mt-1 text-slate-400">© جميع الحقوق محفوظة لعام ٢٠٢٦ - تم التصميم بأسلوب مميز محكم</p>
        </footer>

      </div>
    </div>
  );
}
