export interface FloatingTestSpec {
  id: number;
  dtype: 'float32' | 'float64';
  inputHex: string;
  outputHex: string;
  ulpErrorTol: number;
  description: string;
}

export interface SeedSpec {
  step: number;
  value: string;
}

export interface DialogueSpec {
  id: number;
  dialect: string;
  character: string;
  gender: 'male' | 'female';
  intent: string;
  text: string;
  context: string;
}

export const FLOAT_TEST_CASES: FloatingTestSpec[] = [
  // Float32 Cases from Prompt
  { id: 1, dtype: 'float32', inputHex: '0xbdfe94b0', outputHex: '0x3f6adda6', ulpErrorTol: 2, description: 'تحقق التقريب العائم لعملية Elementary float32' },
  { id: 2, dtype: 'float32', inputHex: '0x3f20f8f8', outputHex: '0x3fc5ec69', ulpErrorTol: 2, description: 'حساب زوايا جيب تمام المثلثي ومطابقة ULP' },
  { id: 3, dtype: 'float32', inputHex: '0x007040b5', outputHex: '0x3f800000', ulpErrorTol: 2, description: 'معايرة القيم المتناهية في الصغر (Subnormals)' },
  { id: 4, dtype: 'float32', inputHex: '0x00030ec5', outputHex: '0x3f800000', ulpErrorTol: 2, description: 'التحويل بين النطاق الكسري والعائم المستقر' },
  { id: 5, dtype: 'float32', inputHex: '0x3eb63070', outputHex: '0x3fa3ce29', ulpErrorTol: 2, description: 'تحليل دقة جيب تمام الزاوية العائمة' },
  { id: 6, dtype: 'float32', inputHex: '0xff4dda3d', outputHex: '0x00000000', ulpErrorTol: 2, description: 'معالجة إشارات اللانهاية وقص المقاطع السفلية' },
  { id: 7, dtype: 'float32', inputHex: '0x805b832f', outputHex: '0x3f800000', ulpErrorTol: 2, description: 'موازنة أخطاء البتر العشري في العمليات الدورية' },
  { id: 8, dtype: 'float32', inputHex: '0x3e883fb7', outputHex: '0x3f99ed8c', ulpErrorTol: 2, description: 'التكامل الأسي لحوسبة الجذور التقريبية' },
  { id: 9, dtype: 'float32', inputHex: '0x3f14d71f', outputHex: '0x3fbf8708', ulpErrorTol: 2, description: 'كفاءة محاذاة العائم الفردي بنطاقات IEEE-754' },
  { id: 10, dtype: 'float32', inputHex: '0xff7b1e55', outputHex: '0x00000000', ulpErrorTol: 2, description: 'معايرة التقارب الصفري تحت الحد الأدنى للتمثيل' },
  { id: 11, dtype: 'float32', inputHex: '0xbf691ac6', outputHex: '0x3f082fa2', ulpErrorTol: 2, description: 'تأثير الإشارة السالبة لكسر المعالجة' },
  { id: 12, dtype: 'float32', inputHex: '0x7ee3e6ab', outputHex: '0x7f800000', ulpErrorTol: 2, description: 'عزل فيض اللانهاية الموجب (Positive Overflow)' },
  { id: 13, dtype: 'float32', inputHex: '0xbec6e2b4', outputHex: '0x3f439248', ulpErrorTol: 2, description: 'مكافحة فجوات التقريب العشري في حساب ULP' },
  { id: 14, dtype: 'float32', inputHex: '0xbf5f5ec2', outputHex: '0x3f0bd2c0', ulpErrorTol: 2, description: 'التحويل المعياري لدالة اللوغاريتم للأساس العائم' },
  { id: 15, dtype: 'float32', inputHex: '0xbe39a140', outputHex: '0x3f61c58e', ulpErrorTol: 3, description: 'تسامح خطأ الـ ULP الممتد لـ 3 بتات هكس' },
  { id: 16, dtype: 'float32', inputHex: '0xbeaaa418', outputHex: '0x3f4b31c4', ulpErrorTol: 3, description: 'قياس انحراف النقاط العائمة في المعالج الفردي' },
  { id: 17, dtype: 'float32', inputHex: '0xbf291394', outputHex: '0x3f21f73c', ulpErrorTol: 3, description: 'مكافحة فجوات الإشارة والحدود الخطية للبتات' },
  { id: 18, dtype: 'float32', inputHex: '0x3e5cc464', outputHex: '0x3f94a195', ulpErrorTol: 3, description: 'تصحيح خوارزمية المد لتمثيل الدقة المتناهية' },

  // Float64 Cases from Prompt
  { id: 101, dtype: 'float64', inputHex: '0x000de7e2fd9bcfc6', outputHex: '0x3ff0000000000000', ulpErrorTol: 2, description: 'دقة مضاعفة للحوسبة اللامتناهية Float64' },
  { id: 102, dtype: 'float64', inputHex: '0xbfd8cd88eb319b12', outputHex: '0x3fe876349efbfa2b', ulpErrorTol: 2, description: 'تأثير الكسور الدقيقة للبتات الطرفية العميقة' },
  { id: 103, dtype: 'float64', inputHex: '0x3fe4fa13ace9f428', outputHex: '0x3ff933fbb117d196', ulpErrorTol: 2, description: 'حساب زوايا جيب التمام المزدوج بنطاق ULP = 2' },
  { id: 104, dtype: 'float64', inputHex: '0x000475b3d048eb68', outputHex: '0x3ff0000000000000', ulpErrorTol: 2, description: 'تكامل حدود ريمان للتقريب العائم الفائق' },
  { id: 105, dtype: 'float64', inputHex: '0x7fef39ed07be73d9', outputHex: '0x7ff0000000000000', ulpErrorTol: 2, description: 'معالجة فيض دقة Float64 اللامتناهية' },
  { id: 106, dtype: 'float64', inputHex: '0xbfd7cbefdbaf97e0', outputHex: '0x3fe8bad30f6cf8e1', ulpErrorTol: 2, description: 'تعديل المعايرة للأبعاد الكسرية لتمثيل IEEE' },
  { id: 107, dtype: 'float64', inputHex: '0x3fc45cd60a28b9ac', outputHex: '0x3ff1dd8028ec3f41', ulpErrorTol: 2, description: 'أوزان الاستيفاء الخطي للدالتين الجيبية والأصية' },
  { id: 108, dtype: 'float64', inputHex: '0xbfeee429c0bdc854', outputHex: '0x3fe0638fa62bed9f', ulpErrorTol: 2, description: 'ضرب ضربات المصفوفات الرياضية المعقدة في الذاكرة' },
  { id: 109, dtype: 'float64', inputHex: '0x3fe128176a22502f', outputHex: '0x3ff73393301e5dc8', ulpErrorTol: 2, description: 'تحقق الحسابات المتقاطعة للغاريتمات المتكررة' },
  { id: 110, dtype: 'float64', inputHex: '0x3fe7dbc48aafb789', outputHex: '0x3ffad38989b5955c', ulpErrorTol: 2, description: 'كسر المد الطويل لدوال القوى الفائقة للتقريب' }
];

export const SEED_SEQUENCE_CASES: SeedSpec[] = [
  { step: 0, value: '0xdf1ddcf1e22521fe' },
  { step: 1, value: '0xc71b2f9c706cf151' },
  { step: 2, value: '0x6922a8cc24ad96b2' },
  { step: 3, value: '0x82738c549beccc30' },
  { step: 4, value: '0x5e8415cdb1f17580' },
  { step: 5, value: '0x064c54ad00c09cb4' },
  { step: 6, value: '0x361a17a607dce278' },
  { step: 7, value: '0x4346f6afb7acad68' },
  { step: 8, value: '0x6e9f14d4f6398d6b' },
  { step: 9, value: '0xf818d4343f8ed822' },
  { step: 10, value: '0x6327647daf508ed6' },
  { step: 11, value: '0xe1d1dbe5496a262a' },
  { step: 12, value: '0xfc081e619076b2e0' },
  { step: 13, value: '0x037126563a956ab1' },
  { step: 14, value: '0x08bb46e155db16b9' },
  { step: 15, value: '0x56449f006c9f3fb4' },
  { step: 16, value: '0x34a9273550941803' },
  { id: 17, step: 17, value: '0x5b4df62660f99462' },
  { id: 18, step: 18, value: '0xb8665cad532e3018' },
  { id: 19, step: 19, value: '0x72fc3e5f7f84216a' },
  { id: 20, step: 20, value: '0x71d3c47f6fd59939' }
] as any[];

export const AMAL_DIALOGUES: DialogueSpec[] = [
  { id: 1, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'greeting', text: 'يا هلا فيك! عن جد نورت.', context: 'ترحيب دافئ وودود باللبناني الصافي' },
  { id: 2, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'greeting', text: 'أهلين وسهلين، تفضل ارتاح.', context: 'استقبال مرحب بالزائرين والباحثين' },
  { id: 3, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'ask_clarify', text: 'شو قصدك تحديداً؟ فيك توضّحلي؟', context: 'طلب توضيح لغوي بكل رقي وأدب' },
  { id: 4, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'ask_clarify', text: 'مش واضحة معي… فيك تعيدها بطريقة أبسط؟', context: 'طلب تبسيط المفاهيم المعقدة' },
  { id: 5, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'thanks', text: 'كتر خيرك! عنجد شكراً.', context: 'شكر وامتنان خالص لتلقي المساعدة والتعليم' },
  { id: 6, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'thanks', text: 'يسلمو كتير، ما قصّرت.', context: 'امتنان فوري للتفاعل المثمر مع المعاجم' },
  { id: 7, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'request_send', text: 'فيني آخد التقرير هلّق؟ بليز ابعتلي ياه.', context: 'طلب إرسال مخرجات الفحص العلمي المعتمد' },
  { id: 8, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'request_send', text: 'إذا فيك، طرشلّي الملف على الإيميل.', context: 'طلب تسليم مستندات الذهب والاعتماد اللغوي' },
  { id: 9, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'summarize', text: 'بدّك إيّاها بخلاصة؟ حاضر، بختصرلك بنقطتين.', context: 'تقديم ملخص ذكي ومختصر للباحثين' },
  { id: 10, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'support', text: 'ما تقلق… أنا حدّك، ومنمشيها سوا.', context: 'دعم وتشجيع مستمر للارتقاء في الفحص اللغوي' },
  { id: 11, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'apology', text: 'حقك عليّ… ما كان قصدي أزعّلك.', context: 'اعتذار مهذب لتلافي أي سوء تفاهم' },
  { id: 12, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'confirm', text: 'تمام، ماشي… خلّينا نكمّل.', context: 'تأكيد السير في مراحل الجريان المعرفي' },
  { id: 13, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'refuse', text: 'ما بقدر جاوب بهالشي هلّق، بس فيني ساعدك بطريقة تانية.', context: 'رفض لطيف بأسلوب مهذب مبني على الاحترام' },
  { id: 14, dialect: 'lebanese', character: 'Amal', gender: 'female', intent: 'closing', text: 'تمام… إذا بدك شي تاني أنا جاهزة.', context: 'إنهاء المحادثة بشكل رصين ومنسجم' }
];

// Hex to Floating point IEEE-754 Decoder function
export function decodeIEEE754Hex(hexStr: string, is64Bit: boolean = false): {
  decimalValue: number;
  binaryString: string;
  signBit: string;
  exponentBits: string;
  mantissaBits: string;
  exponentUnbiased: number;
} {
  // Clean hex string
  let cleaned = hexStr.toLowerCase().replace(/^(0x)/, '');
  
  if (is64Bit) {
    // PAD to 16 hex digits (64 bits)
    cleaned = cleaned.padStart(16, '0');
    // We cannot do bitwise operations trivially in 32-bit JS, so use BigInt
    try {
      const num = BigInt('0x' + cleaned);
      const binary = num.toString(2).padStart(64, '0');
      const signBit = binary[0];
      const exponentBits = binary.slice(1, 12);
      const mantissaBits = binary.slice(12);
      
      const exponentInt = parseInt(exponentBits, 2);
      const exponentUnbiased = exponentInt - 1023;
      
      // Convert to actual double
      const buffer = new ArrayBuffer(8);
      const view = new DataView(buffer);
      const hexParts = cleaned.match(/.{1,2}/g) || [];
      for (let i = 0; i < 8; i++) {
        view.setUint8(i, parseInt(hexParts[i] || '0', 16));
      }
      const decimalValue = view.getFloat64(0);
      
      return {
        decimalValue,
        binaryString: binary,
        signBit,
        exponentBits,
        mantissaBits,
        exponentUnbiased
      };
    } catch {
      return { decimalValue: NaN, binaryString: '', signBit: '', exponentBits: '', mantissaBits: '', exponentUnbiased: 0 };
    }
  } else {
    // 32 Bit Float
    cleaned = cleaned.padStart(8, '0');
    const num = parseInt(cleaned, 16);
    const binary = num.toString(2).padStart(32, '0');
    const signBit = binary[0];
    const exponentBits = binary.slice(1, 9);
    const mantissaBits = binary.slice(9);
    
    const exponentInt = parseInt(exponentBits, 2);
    const exponentUnbiased = exponentInt - 127;
    
    // Convert to actual float32
    const buffer = new ArrayBuffer(4);
    const view = new DataView(buffer);
    view.setUint32(0, num);
    const decimalValue = view.getFloat32(0);
    
    return {
      decimalValue,
      binaryString: binary,
      signBit,
      exponentBits,
      mantissaBits,
      exponentUnbiased
    };
  }
}
