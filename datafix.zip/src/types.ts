export interface LetterStats {
  letter: string;
  rawCount: number;
  uniqueCount: number;
  topWords: string[];
  source: string;
  rule: string;
  isAnomalous?: boolean;
  anomalyDetails?: string;
  sampleWords?: string[];
}

export interface WordCorrection {
  original: string;
  corrected: string;
  explanation: string;
  category: 'prefix' | 'orthography' | 'encoding' | 'grammar';
}

export interface RuleConfig {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
  category: 'cleanup' | 'normalization' | 'dictionary' | 'advanced';
}

export interface CorrectionChange {
  id: string;
  index: number;
  original: string;
  replacement: string;
  type: string;
  context: string;
}

export interface AnalysisSummary {
  originalWordsCount: number;
  uniqueOriginalCount: number;
  correctedWordsCount: number;
  uniqueCorrectedCount: number;
  cleanlinessScore: number;
}
