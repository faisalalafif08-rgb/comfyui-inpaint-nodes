# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict
from modules.nlp.text_cleaning import clean_text

class KnowledgeEngine:
    def __init__(self, base_path: str = "data") -> None:
        self.base = Path(base_path)
        self.systems = self._load("systems.json")
        self.tasks = self._load("tasks.json")
        self.task_types = self._load("task_types.json")
        self.methods = self._load("method_map.json")
        self.linguistic = self._load("linguistic_levels.json")

    def _load(self, name: str) -> Any:
        path = self.base / name
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def analyze_text(self, text: str) -> Dict[str, Any]:
        cleaned = clean_text(text)
        return {
            "original": text,
            "cleaned": cleaned,
            "linguistic_level": self._infer_linguistic_level(cleaned),
            "keywords": self._extract_keywords(cleaned),
        }

    def _infer_linguistic_level(self, text: str) -> str:
        if len(text) < 20:
            return "simple"
        if len(text) < 100:
            return "medium"
        return "complex"

    def _extract_keywords(self, text: str) -> list[str]:
        words = [w for w in text.split() if len(w) >= 4]
        return list(dict.fromkeys(words[:8]))

    def map_task(self, analysis: Dict[str, Any]) -> str:
        text = analysis["cleaned"]
        if isinstance(self.tasks, list):
            for task in self.tasks:
                label = task.get("name", "")
                if label and label in text:
                    return label
        if "مشهد" in text or "سينمائي" in text:
            return "cinematic"
        if "خبر" in text or "اقتصاد" in text:
            return "news"
        return "general"

    def resolve_method(self, task: str) -> str:
        if isinstance(self.methods, dict):
            return self.methods.get(task, "default_method")
        return "default_method"

    def run(self, text: str) -> Dict[str, Any]:
        analysis = self.analyze_text(text)
        task = self.map_task(analysis)
        method = self.resolve_method(task)
        return {
            "analysis": analysis,
            "task": task,
            "method": method,
        }
