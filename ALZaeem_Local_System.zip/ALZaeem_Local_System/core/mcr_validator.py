# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict

class MCRValidator:
    def validate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        result = {"valid": True, "errors": [], "warnings": [], "score": 1.0}
        if not isinstance(data, dict):
            result["valid"] = False
            result["errors"].append("invalid_structure")
            result["score"] = 0.0
            return result

        if "direction" not in data:
            result["warnings"].append("missing_direction")
        if "duration" in data and data["duration"] <= 0:
            result["valid"] = False
            result["errors"].append("invalid_duration")

        if result["errors"]:
            result["score"] = 0.0
        elif result["warnings"]:
            result["score"] = 0.7
        return result
