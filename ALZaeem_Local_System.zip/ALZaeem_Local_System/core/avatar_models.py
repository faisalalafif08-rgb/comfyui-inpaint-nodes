# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict

@dataclass
class CharacterProfile:
    char_id: str
    name: str
    role: str
    visual_traits: Dict[str, Any]
    psychological_traits: Dict[str, Any]
    voice_profile: Dict[str, Any]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "char_id": self.char_id,
            "name": self.name,
            "role": self.role,
            "visual_traits": self.visual_traits,
            "psychological_traits": self.psychological_traits,
            "voice_profile": self.voice_profile,
            "metadata": self.metadata,
        }
