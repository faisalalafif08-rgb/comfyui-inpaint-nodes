# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict
import time
import uuid

@dataclass
class CameraEvent:
    direction: str
    speed: float
    duration: float
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    status: str = "created"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def start(self) -> None:
        self.status = "running"

    def complete(self) -> None:
        self.status = "completed"

    def fail(self, reason: str) -> None:
        self.status = "failed"
        self.metadata["error"] = reason

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "direction": self.direction,
            "speed": self.speed,
            "duration": self.duration,
            "timestamp": self.timestamp,
            "status": self.status,
            "metadata": self.metadata,
        }
