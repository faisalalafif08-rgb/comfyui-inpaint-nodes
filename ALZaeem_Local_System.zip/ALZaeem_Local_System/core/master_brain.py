# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict, Optional
from core.config import CONFIG
from core.knowledge_engine import KnowledgeEngine
from core.avatar_engine import AvatarEngine
from core.scene_builder import SceneBuilder
from core.camera_brain import CameraBrain
from core.camera_runtime import CameraRuntime
from modules.cinema.fno_studio import FnoStudio
from modules.voice.direct_tts import DirectTTS

class MasterBrain:
    def __init__(self) -> None:
        CONFIG.ensure_dirs()
        self.knowledge = KnowledgeEngine(base_path="data")
        self.avatar_engine = AvatarEngine()
        self.scene_builder = SceneBuilder()
        self.camera_brain = CameraBrain()
        self.camera_runtime = CameraRuntime()
        self.cinema = FnoStudio()
        self.tts = DirectTTS(engine="xtts")

    def run(
        self,
        text: str,
        avatar_name: str = "زايد",
        dialect: str = "saudi",
        style: str = "cinematic",
        mood: Optional[str] = None,
        output_audio_path: str = "output/audio_mock.txt",
    ) -> Dict[str, Any]:
        knowledge_result = self.knowledge.run(text)
        cleaned_text = knowledge_result["analysis"]["cleaned"]
        task = knowledge_result["task"]
        method = knowledge_result["method"]

        avatar = self.avatar_engine.create_avatar(
            name=avatar_name,
            dialect=dialect,
            style=style,
        )

        scene = self.scene_builder.build(cleaned_text, task=task)
        if mood:
            scene["mood"] = mood

        camera_plan = self.camera_brain.generate(scene)
        camera_results = self.camera_runtime.run(camera_plan)

        studio_scene = self.cinema.prepare_scene(
            character=avatar["name"],
            mood=scene["mood"],
        )

        voice = self.tts.synthesize(
            text=cleaned_text,
            voice_profile=avatar["voice_profile"],
            output_path=output_audio_path,
        )

        return {
            "ok": True,
            "analysis": knowledge_result["analysis"],
            "task": task,
            "method": method,
            "avatar": avatar,
            "scene": scene,
            "studio_scene": studio_scene,
            "camera_plan": camera_plan,
            "camera_results": camera_results,
            "voice": voice,
        }
