# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional
from core.config import CONFIG

class AvatarRegistry:
    def __init__(self) -> None:
        CONFIG.ensure_dirs()
        self.registry_path = CONFIG.characters_dir / "registry.json"
        if not self.registry_path.exists():
            self._save({"avatars": []})

    def _load(self) -> Dict[str, Any]:
        try:
            return json.loads(self.registry_path.read_text(encoding="utf-8"))
        except Exception:
            return {"avatars": []}

    def _save(self, payload: Dict[str, Any]) -> None:
        self.registry_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def save_avatar(self, profile: Dict[str, Any]) -> None:
        payload = self._load()
        avatars = [a for a in payload["avatars"] if a.get("char_id") != profile.get("char_id")]
        avatars.append(profile)
        payload["avatars"] = avatars
        self._save(payload)

    def get_avatar(self, name: str) -> Optional[Dict[str, Any]]:
        payload = self._load()
        for avatar in payload["avatars"]:
            if avatar.get("name") == name:
                return avatar
        return None

    def list_avatars(self) -> List[Dict[str, Any]]:
        return self._load().get("avatars", [])
