# -*- coding: utf-8 -*-
from __future__ import annotations

import time
from typing import Any, Dict, List
from core.camera_event import CameraEvent
from core.pattern_memory import PatternMemory
from core.mcr_validator import MCRValidator

class CameraRuntime:
    def __init__(self) -> None:
        self.pattern_memory = PatternMemory()
        self.validator = MCRValidator()

    def run(self, camera_plan: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []

        for step in camera_plan:
            event = CameraEvent(
                direction=step.get("direction", "forward"),
                speed=float(step.get("speed", 1.0)),
                duration=float(step.get("duration", 1.0)),
                metadata=step,
            )

            validation = self.validator.validate(event.to_dict())
            if not validation["valid"]:
                event.fail("validation_failed")
                results.append(event.to_dict())
                continue

            event.start()
            success = self._execute(event)
            self.pattern_memory.observe(event.to_dict())
            self.pattern_memory.register_outcome(event.to_dict(), success)

            if success:
                event.complete()
            else:
                event.fail("execution_failed")

            results.append(event.to_dict())

        return results

    def _execute(self, event: CameraEvent) -> bool:
        try:
            time.sleep(min(event.duration, 0.2))
            return True
        except Exception:
            return False
