# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict, List

class CameraBrain:
    def generate(self, scene: Dict[str, Any]) -> List[Dict[str, Any]]:
        mood = scene.get("mood", "cinematic")

        if mood == "tension":
            return [
                {"direction": "forward", "speed": 1.2, "duration": 1.5},
                {"direction": "left", "speed": 0.8, "duration": 1.0},
            ]
        if mood == "calm":
            return [
                {"direction": "slow_pan", "speed": 0.2, "duration": 3.0},
            ]
        if mood == "epic":
            return [
                {"direction": "rise", "speed": 1.0, "duration": 2.0},
                {"direction": "zoom_out", "speed": 1.1, "duration": 2.5},
            ]

        return [
            {"direction": "static", "speed": 0.1, "duration": 2.0},
            {"direction": "forward", "speed": 0.5, "duration": 1.5},
        ]
