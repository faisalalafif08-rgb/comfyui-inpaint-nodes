# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

@dataclass(frozen=True)
class Config:
    base_dir: Path = Path(".")
    data_dir: Path = field(init=False)
    output_dir: Path = field(init=False)
    characters_dir: Path = field(init=False)
    renders_dir: Path = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "data_dir", self.base_dir / "data")
        object.__setattr__(self, "output_dir", self.base_dir / "output")
        object.__setattr__(self, "characters_dir", self.output_dir / "characters")
        object.__setattr__(self, "renders_dir", self.output_dir / "renders")

    def ensure_dirs(self) -> None:
        for p in [self.data_dir, self.output_dir, self.characters_dir, self.renders_dir]:
            p.mkdir(parents=True, exist_ok=True)

CONFIG = Config()
