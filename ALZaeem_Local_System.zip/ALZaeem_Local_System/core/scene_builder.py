# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict

class SceneBuilder:
    def build(self, text: str, task: str = "general") -> Dict[str, Any]:
        mood = "cinematic"
        if any(w in text for w in ["خوف", "توتر", "رعب"]):
            mood = "tension"
        elif any(w in text for w in ["هادئ", "هدوء", "رومانسي"]):
            mood = "calm"
        elif any(w in text for w in ["ملحمي", "بطولي", "عظيم"]):
            mood = "epic"

        return {
            "text": text,
            "task": task,
            "mood": mood,
            "location": "studio_space",
            "camera_style": "cinematic",
        }
