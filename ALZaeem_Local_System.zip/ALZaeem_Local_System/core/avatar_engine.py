# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict
from core.avatar_models import CharacterProfile
from core.avatar_registry import AvatarRegistry

class AvatarEngine:
    def __init__(self) -> None:
        self.registry = AvatarRegistry()

    def create_avatar(self, name: str, dialect: str = "saudi", style: str = "cinematic") -> Dict[str, Any]:
        existing = self.registry.get_avatar(name)
        if existing:
            return existing

        profile = CharacterProfile(
            char_id=f"avatar_{name}",
            name=name,
            role="presenter",
            visual_traits={
                "style": style,
                "lighting": "dramatic" if style == "cinematic" else "neutral",
                "wardrobe": "formal",
            },
            psychological_traits={
                "confidence": "high",
                "warmth": "medium",
                "focus": "high",
            },
            voice_profile={
                "engine": "mock_xtts",
                "language": "ar",
                "dialect": dialect,
                "tone": "clear",
            },
            metadata={"version": "1.0"},
        )

        payload = profile.to_dict()
        self.registry.save_avatar(payload)
        return payload
