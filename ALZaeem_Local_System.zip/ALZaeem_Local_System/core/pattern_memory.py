# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

class PatternMemory:
    def __init__(self, store_path: str = "output/pattern_memory.json") -> None:
        self.path = Path(store_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.patterns: Dict[str, Dict[str, Any]] = {}
        self._load()

    def observe(self, scene: Dict[str, Any]) -> int:
        key = f"{scene.get('direction','unknown')}|{scene.get('speed','unknown')}|{scene.get('duration',0)}"
        if key not in self.patterns:
            self.patterns[key] = {"count": 0, "success_count": 0, "fail_count": 0}
        self.patterns[key]["count"] += 1
        self._save()
        return self.patterns[key]["count"]

    def register_outcome(self, scene: Dict[str, Any], success: bool) -> None:
        key = f"{scene.get('direction','unknown')}|{scene.get('speed','unknown')}|{scene.get('duration',0)}"
        if key not in self.patterns:
            self.observe(scene)
        if success:
            self.patterns[key]["success_count"] += 1
        else:
            self.patterns[key]["fail_count"] += 1
        self._save()

    def _load(self) -> None:
        if not self.path.exists():
            self.patterns = {}
            return
        try:
            self.patterns = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self.patterns = {}

    def _save(self) -> None:
        self.path.write_text(json.dumps(self.patterns, ensure_ascii=False, indent=2), encoding="utf-8")
