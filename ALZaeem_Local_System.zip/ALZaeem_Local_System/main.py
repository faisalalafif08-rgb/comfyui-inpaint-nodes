# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from core.master_brain import MasterBrain

def main() -> None:
    brain = MasterBrain()
    text = input("اكتب النص: ").strip()
    if not text:
        print("لا يوجد نص.")
        return

    result = brain.run(
        text=text,
        avatar_name="زايد",
        dialect="saudi",
        style="cinematic",
        output_audio_path="output/audio_mock.txt",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
