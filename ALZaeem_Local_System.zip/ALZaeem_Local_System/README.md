# ALZaeem System V1

نظام كود جاهز من الصفر:
- فهم النص
- إنشاء أفاتار
- بناء مشهد
- تخطيط كاميرا
- تنفيذ كاميرا mock
- توليد صوت mock

## التشغيل
```bash
python main.py
```

## المخرجات
- output/audio_mock.txt
- output/characters/registry.json
- output/pattern_memory.json
