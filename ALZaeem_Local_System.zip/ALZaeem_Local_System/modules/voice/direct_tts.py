# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

class DirectTTS:
    def __init__(self, engine: str = "xtts") -> None:
        self.engine = engine

    def synthesize(self, text: str, voice_profile: Dict[str, Any], output_path: str) -> Dict[str, Any]:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            f"[AUDIO MOCK]\nengine={self.engine}\nvoice={voice_profile}\ntext={text}\n",
            encoding="utf-8",
        )
        return {
            "ok": True,
            "engine": self.engine,
            "output": str(path),
            "voice_profile": voice_profile,
        }
