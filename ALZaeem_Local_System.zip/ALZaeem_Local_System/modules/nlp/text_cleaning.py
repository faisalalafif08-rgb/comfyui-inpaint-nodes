# -*- coding: utf-8 -*-
from __future__ import annotations

import re

def clean_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\w\s\u0600-\u06FF]", "", text)
    return text.strip()
