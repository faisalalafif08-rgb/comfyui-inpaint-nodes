#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "تشغيل نظام ALZaeem المحلي..."
python3 main.py
