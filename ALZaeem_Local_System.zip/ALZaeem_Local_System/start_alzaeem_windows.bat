@echo off
cd /d "%~dp0"
echo تشغيل نظام ALZaeem المحلي...
python main.py
pause
