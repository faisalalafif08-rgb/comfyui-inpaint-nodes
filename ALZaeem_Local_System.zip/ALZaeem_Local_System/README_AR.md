# ALZaeem Local System

هذا مجلد محلي جاهز يحتوي على:

1. **نظام ALZaeem** النصي المحلي (جاهز للتشغيل مباشرة).
2. **نسخة مصدر Fooocus** داخل المجلد:
   `optional_fooocus_source`
   وهي نسخة المصدر وليست النسخة المحمولة الجاهزة.

## التشغيل السريع

### ويندوز
- شغّل الملف: `start_alzaeem_windows.bat`

### لينكس / macOS
```bash
chmod +x start_alzaeem_linux_mac.sh
./start_alzaeem_linux_mac.sh
```

## ماذا يفعل النظام؟
عند التشغيل سيطلب منك إدخال نص عربي، ثم ينتج:
- تحليل للنص
- أفاتار افتراضي
- إعداد مشهد
- خطة كاميرا
- مخرج صوتي mock داخل:
  `output/audio_mock.txt`

## ملاحظات مهمة
- هذا النظام لا يحتاج مكتبات خارجية لتشغيل **ALZaeem**.
- ملف Fooocus الموجود هنا هو **source code** فقط.
- لتشغيل Fooocus من المصدر غالبًا تحتاج:
  - Python مناسب
  - تثبيت الاعتمادات من ملف `requirements_versions.txt`
  - وقد تحتاج كرت شاشة مناسب إذا رغبت بتوليد الصور فعليًا

## تشغيل Fooocus من المصدر
### ويندوز
افتح PowerShell داخل مجلد `optional_fooocus_source` ثم نفّذ:
```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements_versions.txt
python entry_with_update.py
```

### لينكس / macOS
```bash
cd optional_fooocus_source
python3 -m venv venv
source venv/bin/activate
pip install -r requirements_versions.txt
python entry_with_update.py
```

## ملفات التشغيل المرفقة
- `start_alzaeem_windows.bat`
- `start_alzaeem_linux_mac.sh`

## تجربة سريعة
مثال إدخال:
```text
أنشئ مشهد سينمائي هادئ لمقدمة شخصية عربية واثقة
```
